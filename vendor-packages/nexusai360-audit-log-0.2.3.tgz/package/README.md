# @nexusai360/audit-log

Fire-and-forget action logging — não bloqueia o caller, persiste async via callback.

## Setup

Configure UMA vez no startup (ex: instrumentation.ts ou layout root):

```typescript
import { configureAudit } from "@nexusai360/audit-log";
import { prisma } from "@/lib/prisma";

configureAudit(async (entry) => {
  await prisma.auditLog.create({ data: { ...entry, createdAt: new Date() } });
});
```

## Uso

```typescript
import { logAudit, withAudit } from "@nexusai360/audit-log";

// Direto
logAudit({
  actorType: "user",
  actorId: user.id,
  action: "user.login",
  resourceType: "user",
});

// Wrapper para server actions
export const updateUser = withAudit(
  async (id: string, data: UpdateData) => {
    return await prisma.user.update({ where: { id }, data });
  },
  {
    action: "user.update",
    resourceType: "user",
    getActor: ([id]) => ({ actorType: "user", actorId: getCurrentUserId() }),
    getResourceId: ([id]) => id,
    getBefore: async ([id]) => prisma.user.findUnique({ where: { id } }),
  }
);
```
