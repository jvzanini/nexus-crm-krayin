# @nexusai360/users-ui

Página CRUD de Usuários (admin platform). Exporta UI client + helpers (schemas Zod, asserções de permissão, tipos, interface adapter).

## Requisitos do consumer

1. **Sonner `<Toaster />`** montado no layout root (`app/layout.tsx`):
   ```tsx
   import { Toaster } from "sonner";
   <Toaster richColors position="top-right" />
   ```
2. **Server Actions próprias** — pacote NÃO exporta server actions (Next 16 não detecta `"use server"` em npm bundle). Consumer cria `app/users/_actions.ts` com `"use server"` no topo, importa schemas/permissions de `@nexusai360/users-ui/server-helpers`.
3. **Server Component pai** instancia `<UsersContent isSuperAdmin currentUserId actions={...} />`. As actions devem ser Server Actions (atravessam o boundary RSC).

Ver `docs/superpowers/specs/2026-04-14-ui-packages-design.md` §3.1 e §11 para wiring completo.
