# @nexusai360/companies-ui

Página CRUD de Empresas (admin platform). Exporta UI client + helpers (schemas Zod, asserções de permissão, tipos, interface adapter com `toggleActive`).

## Requisitos do consumer

1. **Sonner `<Toaster />`** montado no layout root (`app/layout.tsx`):
   ```tsx
   import { Toaster } from "sonner";
   <Toaster richColors position="top-right" />
   ```
2. **Server Actions próprias** — pacote NÃO exporta server actions (Next 16 não detecta `"use server"` em npm bundle). Consumer cria `app/companies/_actions.ts` com `"use server"` no topo, importa schemas/permissions de `@nexusai360/companies-ui/server-helpers`.
3. **Server Component pai** instancia `<CompaniesContent isSuperAdmin currentUserId actions={...} />`. As actions devem ser Server Actions (atravessam o boundary RSC). Inclua `toggleCompanyActive` no objeto `actions` para o toggle de status funcionar.

Ver `docs/superpowers/specs/2026-04-14-ui-packages-design.md` §3.1 e §11 para wiring completo.
