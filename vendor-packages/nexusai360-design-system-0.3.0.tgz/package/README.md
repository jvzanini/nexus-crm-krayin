# @nexusai360/design-system

Design system Nexus — componentes UI, tokens, theme system e animations para projetos Next.js.

## Instalação

```bash
pnpm add @nexusai360/design-system
pnpm add react react-dom @base-ui/react framer-motion lucide-react sonner tailwindcss tw-animate-css next
```

## Setup

### 1. Importar CSS

No `src/app/layout.tsx`:

```tsx
import "@nexusai360/design-system/styles.css";
```

### 2. Configurar Tailwind v4 para escanear o pacote

Adicione ao seu CSS principal:

```css
@source "./node_modules/@nexusai360/design-system/dist/**/*.{js,mjs}";
```

### 3. Envolver app com ThemeProvider

```tsx
import { getResolvedThemeFromCookie } from "@nexusai360/design-system/theme-server";
import { ThemeProvider } from "@nexusai360/design-system/theme-provider";
import { Toaster } from "@nexusai360/design-system";

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const resolvedTheme = await getResolvedThemeFromCookie();
  return (
    <html lang="pt-BR" className={resolvedTheme} style={{ colorScheme: resolvedTheme }}>
      <body>
        <ThemeProvider initialTheme={resolvedTheme}>
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
```

## Uso

```tsx
import { Button, Card, CardContent } from "@nexusai360/design-system";

<Card>
  <CardContent>
    <Button variant="default" size="default">Clique</Button>
  </CardContent>
</Card>
```

## Exports

- `@nexusai360/design-system` — Todos os componentes
- `@nexusai360/design-system/styles.css` — CSS global (variáveis + WCAG AA overrides)
- `@nexusai360/design-system/theme-provider` — ThemeProvider + useTheme (client)
- `@nexusai360/design-system/theme-server` — Helpers de cookie (server-only)
- `@nexusai360/design-system/tokens` — Constantes de tokens (cores, spacing, etc.)
- `@nexusai360/design-system/animations` — Variants do Framer Motion
- `@nexusai360/design-system/utils` — Utility cn()

## Componentes

**Server-safe (sem `"use client"`):**
- `Card`, `CardHeader`, `CardTitle`, `CardDescription`, `CardAction`, `CardContent`, `CardFooter`
- `Label`
- `Table`, `TableHeader`, `TableBody`, `TableFooter`, `TableRow`, `TableHead`, `TableCell`, `TableCaption`
- `TableSkeleton`
- `Button`
- `Input`
- `Badge`

**Client (com `"use client"`):**
- `Switch`
- `Dialog`, `DialogTrigger`, `DialogPortal`, `DialogClose`, `DialogOverlay`, `DialogContent`, `DialogHeader`, `DialogFooter`, `DialogTitle`, `DialogDescription`
- `AlertDialog`, `AlertDialogAction`, `AlertDialogCancel`, `AlertDialogContent`, `AlertDialogDescription`, `AlertDialogFooter`, `AlertDialogHeader`, `AlertDialogTitle`, `AlertDialogMedia`
- `CustomSelect`
- `BadgeSelect`
- `PasswordInput`
- `Toaster` (Sonner customizado)

## v0.3.0 — Foundation A (Fase 1a)

### Camadas

- **Primitives** (server-safe): `IconTile`, `Skeleton`, `LoadingSpinner`, `Separator`.
- **Compounds client** (base-ui/react): `Avatar`, `Tooltip`, `Tabs`, `DropdownMenu`, `ScrollArea`.
- **Compounds server-safe**: `EmptyState`, `ErrorState`, `Breadcrumb`, `PageHeader`.
- **Shell** (client): `AppShell`.

### Matriz de composição

| Primitive    | Usado em                                  |
|--------------|-------------------------------------------|
| `IconTile`   | `EmptyState.Icon`, `ErrorState.Icon`, `PageHeader.Icon` |
| `Breadcrumb` | `PageHeader.Breadcrumb`                   |
| `Dialog`     | `AppShell` (mobile sidebar — hook de uso) |

### Exemplos

```tsx
import { IconTile } from "@nexusai360/design-system";
import { Users } from "lucide-react";

<IconTile icon={Users} color="violet" size="md" />
```

```tsx
import { Skeleton } from "@nexusai360/design-system";

<div aria-busy="true">
  <Skeleton className="h-4 w-48" variant="text" />
  <Skeleton className="mt-2 h-24 w-full" />
</div>
```

```tsx
import { LoadingSpinner } from "@nexusai360/design-system";

<LoadingSpinner size="lg" label="Carregando lista..." />
```

```tsx
import { Separator } from "@nexusai360/design-system";
<Separator orientation="horizontal" />
```

```tsx
import { Avatar } from "@nexusai360/design-system";

<Avatar.Root size="md">
  <Avatar.Image src={user.avatar} alt={user.name} />
  <Avatar.Fallback>{initials}</Avatar.Fallback>
</Avatar.Root>
```

```tsx
import { Tooltip } from "@nexusai360/design-system";

<Tooltip.Provider>
  <Tooltip.Root>
    <Tooltip.Trigger>?</Tooltip.Trigger>
    <Tooltip.Content side="top">Ajuda</Tooltip.Content>
  </Tooltip.Root>
</Tooltip.Provider>
```

```tsx
import { Tabs } from "@nexusai360/design-system";

<Tabs.Root defaultValue="info">
  <Tabs.List>
    <Tabs.Trigger value="info">Info</Tabs.Trigger>
    <Tabs.Trigger value="activity">Atividades</Tabs.Trigger>
  </Tabs.List>
  <Tabs.Panel value="info">...</Tabs.Panel>
  <Tabs.Panel value="activity">...</Tabs.Panel>
</Tabs.Root>
```

```tsx
import { DropdownMenu } from "@nexusai360/design-system";

<DropdownMenu.Root>
  <DropdownMenu.Trigger>Ações</DropdownMenu.Trigger>
  <DropdownMenu.Content>
    <DropdownMenu.Item>Editar</DropdownMenu.Item>
    <DropdownMenu.Separator />
    <DropdownMenu.Item variant="destructive">Excluir</DropdownMenu.Item>
  </DropdownMenu.Content>
</DropdownMenu.Root>
```

```tsx
import { ScrollArea } from "@nexusai360/design-system";

<ScrollArea className="h-64">...</ScrollArea>
```

```tsx
import { EmptyState } from "@nexusai360/design-system";
import { Inbox } from "lucide-react";

<EmptyState.Root>
  <EmptyState.Icon icon={Inbox} />
  <EmptyState.Title>Nenhum contato</EmptyState.Title>
  <EmptyState.Description>Cadastre o primeiro contato.</EmptyState.Description>
  <EmptyState.Action><Button>Novo</Button></EmptyState.Action>
</EmptyState.Root>
```

```tsx
import { ErrorState } from "@nexusai360/design-system";

<ErrorState.Root>
  <ErrorState.Icon />
  <ErrorState.Title>Ops, algo deu errado</ErrorState.Title>
  <ErrorState.Description>Tente novamente em instantes.</ErrorState.Description>
  <ErrorState.Details error={err} />
  <ErrorState.Action><Button onClick={retry}>Tentar de novo</Button></ErrorState.Action>
</ErrorState.Root>
```

```tsx
import { Breadcrumb } from "@nexusai360/design-system";

<Breadcrumb.Root>
  <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
  <Breadcrumb.Separator />
  <Breadcrumb.Item href="/clientes">Clientes</Breadcrumb.Item>
  <Breadcrumb.Separator />
  <Breadcrumb.Item current>Detalhe</Breadcrumb.Item>
</Breadcrumb.Root>
```

```tsx
import { PageHeader } from "@nexusai360/design-system";
import { Users } from "lucide-react";

<PageHeader.Root>
  <PageHeader.Breadcrumb>...</PageHeader.Breadcrumb>
  <PageHeader.Row>
    <div className="flex items-center gap-3">
      <PageHeader.Icon icon={Users} color="violet" />
      <PageHeader.Heading>
        <PageHeader.Title>Clientes</PageHeader.Title>
        <PageHeader.Description>Gerencie contatos</PageHeader.Description>
      </PageHeader.Heading>
    </div>
    <PageHeader.Actions><Button>Novo</Button></PageHeader.Actions>
  </PageHeader.Row>
</PageHeader.Root>
```

```tsx
import { AppShell } from "@nexusai360/design-system";

<AppShell.Root>
  <AppShell.Sidebar>{/* nav */}</AppShell.Sidebar>
  <AppShell.Content>
    <AppShell.Header>{/* topbar */}</AppShell.Header>
    <AppShell.Main>{children}</AppShell.Main>
  </AppShell.Content>
</AppShell.Root>
```

### Políticas

- **Sem telemetria.** Nenhum componente emite dados.
- **Camadas:** primitives → compounds → shell. Compounds consomem primitives; shell consome compounds.
- **Versionamento:** bump *minor* quando adicionar componente; *patch* para bug fix; `deprecate` + patch para rollback.
- **Budget:** 60KB gz total no bundle; 15KB gz por subpath. `size-limit` valida.
- **a11y:** ver `docs/accessibility.md`.

## Documentação Completa

Anatomia detalhada de cada componente, padrões de uso e anti-padrões:
[core/design-system.md](https://github.com/nexusai360/nexus-blueprint/blob/main/core/design-system.md)
