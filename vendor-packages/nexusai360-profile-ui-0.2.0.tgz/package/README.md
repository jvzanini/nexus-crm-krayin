# @nexusai360/profile-ui

Página de Perfil self-service (avatar, nome, e-mail, senha, tema). Client component que recebe server actions via props — segue o padrão actions-as-props do ecossistema Nexus.

## Install

```bash
pnpm add @nexusai360/profile-ui
```

Peers: `@nexusai360/design-system ^0.3`, `@nexusai360/types ^0.2`, React 19, Next 16 (opcional), framer-motion, lucide-react, sonner, date-fns.

## Uso

```tsx
// app/(protected)/profile/page.tsx
import { ProfileContent } from "@nexusai360/profile-ui";
import { toProfileDTO } from "@nexusai360/profile-ui/server-helpers";
import {
  updateProfileAction,
  updateAvatarAction,
  requestEmailChangeAction,
  changePasswordAction,
  setThemeCookieAction,
} from "./actions";
import { getCurrentUser, getCurrentTheme } from "@/lib/auth";
import { profileAdapter } from "@/lib/adapters";

export default async function ProfilePage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const raw = await profileAdapter.getProfile(user.id);
  if (!raw) redirect("/login");

  return (
    <ProfileContent
      initialProfile={toProfileDTO(raw)}
      currentTheme={await getCurrentTheme()}
      canEdit
      onUpdateProfile={updateProfileAction}
      onUpdateAvatar={updateAvatarAction}
      onRequestEmailChange={requestEmailChangeAction}
      onChangePassword={changePasswordAction}
      onThemeChange={setThemeCookieAction}
    />
  );
}
```

## Server actions (exemplo)

```ts
"use server";
import { updateProfileSchema, changePasswordSchema } from "@nexusai360/profile-ui/server-helpers";
import { hashPassword } from "@nexusai360/core";
import { profileAdapter } from "@/lib/adapters";
import { getCurrentUser } from "@/lib/auth";

export async function updateProfileAction(input: unknown) {
  const user = await getCurrentUser();
  if (!user) return { success: false, error: "Não autenticado" };

  const parsed = updateProfileSchema.safeParse(input);
  if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message };

  await profileAdapter.updateProfile(user.id, parsed.data);
  return { success: true };
}

export async function changePasswordAction(input: unknown) {
  const user = await getCurrentUser();
  if (!user) return { success: false, error: "Não autenticado" };

  const parsed = changePasswordSchema.safeParse(input);
  if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message };

  const ok = await profileAdapter.verifyCurrentPassword(user.id, parsed.data.currentPassword);
  if (!ok) return { success: false, error: "Senha atual incorreta" };

  const hashed = await hashPassword(parsed.data.newPassword);
  await profileAdapter.updatePassword(user.id, hashed);
  return { success: true };
}
```

## Adapter

Implemente `ProfileAdapter` (geralmente com Prisma). O pacote **NÃO** faz hash de senha — hashie no server action antes de chamar `updatePassword`.

## Permissions

Default resolver libera `profile:view` e `profile:edit` para todos os roles (self-service). Use `setPermissionResolver` para lógica customizada — **chame UMA ÚNICA VEZ no boot** (e.g., Next `instrumentation.ts`).

## Util

`resizeAvatar(file, 128?)` — client-side, retorna data URL WebP com crop quadrado central.
