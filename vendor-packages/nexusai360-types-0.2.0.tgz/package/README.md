# @nexusai360/types

Tipos TypeScript compartilhados entre todos os pacotes @nexusai360/*.

## Instalação

```bash
pnpm add @nexusai360/types
```

## Tipos exportados

- `ActionResult<T>` — resultado padrão de Server Actions
- `PlatformRole`, `Theme` — enums centrais
- `CurrentUser` — sessão do usuário autenticado
- `Pagination`, `PaginatedResult<T>`, `SortOrder`, `SortBy<F>` — paginação offset
- `PLATFORM_ROLE_HIERARCHY`, `PLATFORM_ROLE_LABELS` — constantes (frozen)

## Uso

```typescript
import type { ActionResult, CurrentUser, PlatformRole } from "@nexusai360/types";
import { PLATFORM_ROLE_HIERARCHY } from "@nexusai360/types";

async function getUser(id: string): Promise<ActionResult<CurrentUser>> {
  // ...
}

const isAdmin = PLATFORM_ROLE_HIERARCHY[user.platformRole] >= PLATFORM_ROLE_HIERARCHY.admin;
```
