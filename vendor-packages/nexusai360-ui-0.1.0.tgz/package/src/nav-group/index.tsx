import * as React from "react";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface NavGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Group label */
  label: string;
  /** Whether the group can be collapsed */
  collapsible?: boolean;
  /** Default open state (only when collapsible) */
  defaultOpen?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const NavGroup = React.forwardRef<HTMLDivElement, NavGroupProps>(
  (
    {
      className,
      label,
      collapsible = false,
      defaultOpen = true,
      children,
      ...props
    },
    ref,
  ) => {
    const [open, setOpen] = React.useState(defaultOpen);
    const isOpen = collapsible ? open : true;

    return (
      <div ref={ref} className={cn("space-y-1", className)} {...props}>
        {collapsible ? (
          <button
            type="button"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={isOpen}
            className="flex w-full items-center justify-between px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-500 hover:text-zinc-300 transition-colors"
          >
            <span>{label}</span>
            <svg
              className={cn(
                "size-4 shrink-0 transition-transform duration-200",
                isOpen && "rotate-180",
              )}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <path d="m6 9 6 6 6-6" />
            </svg>
          </button>
        ) : (
          <span className="block px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-500">
            {label}
          </span>
        )}
        {isOpen && <div role="group" aria-label={label}>{children}</div>}
      </div>
    );
  },
);

NavGroup.displayName = "NavGroup";

export { NavGroup };
