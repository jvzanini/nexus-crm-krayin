import { describe, it, expect } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { createRef } from "react";
import { NavGroup } from "./index";

describe("NavGroup", () => {
  // --- Render ---
  it("renders label", () => {
    render(<NavGroup label="Main"><div>child</div></NavGroup>);
    expect(screen.getByText("Main")).toBeInTheDocument();
  });

  it("renders children", () => {
    render(<NavGroup label="Group"><div>content</div></NavGroup>);
    expect(screen.getByText("content")).toBeInTheDocument();
  });

  // --- Non-collapsible (default) ---
  it("shows children by default", () => {
    render(<NavGroup label="Static"><div>visible</div></NavGroup>);
    expect(screen.getByText("visible")).toBeInTheDocument();
  });

  it("renders label as span when not collapsible", () => {
    render(<NavGroup label="Static"><div>x</div></NavGroup>);
    expect(screen.getByText("Static").tagName).toBe("SPAN");
  });

  // --- Collapsible ---
  it("renders label as button when collapsible", () => {
    render(<NavGroup label="Collapsible" collapsible><div>x</div></NavGroup>);
    expect(screen.getByRole("button", { name: /Collapsible/i })).toBeInTheDocument();
  });

  it("shows children when defaultOpen=true", () => {
    render(<NavGroup label="Open" collapsible defaultOpen><div>visible</div></NavGroup>);
    expect(screen.getByText("visible")).toBeInTheDocument();
  });

  it("hides children when defaultOpen=false", () => {
    render(<NavGroup label="Closed" collapsible defaultOpen={false}><div>hidden</div></NavGroup>);
    expect(screen.queryByText("hidden")).not.toBeInTheDocument();
  });

  it("toggles children on click", () => {
    render(<NavGroup label="Toggle" collapsible defaultOpen><div>content</div></NavGroup>);
    expect(screen.getByText("content")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button"));
    expect(screen.queryByText("content")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button"));
    expect(screen.getByText("content")).toBeInTheDocument();
  });

  it("sets aria-expanded on button", () => {
    render(<NavGroup label="Expand" collapsible defaultOpen><div>x</div></NavGroup>);
    expect(screen.getByRole("button")).toHaveAttribute("aria-expanded", "true");
    fireEvent.click(screen.getByRole("button"));
    expect(screen.getByRole("button")).toHaveAttribute("aria-expanded", "false");
  });

  // --- Ref ---
  it("forwards ref", () => {
    const ref = createRef<HTMLDivElement>();
    render(<NavGroup ref={ref} label="Ref"><div>x</div></NavGroup>);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  // --- className ---
  it("merges custom className", () => {
    const { container } = render(<NavGroup label="Cls" className="extra"><div>x</div></NavGroup>);
    expect((container.firstChild as HTMLElement).className).toContain("extra");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(NavGroup.displayName).toBe("NavGroup");
  });
});
