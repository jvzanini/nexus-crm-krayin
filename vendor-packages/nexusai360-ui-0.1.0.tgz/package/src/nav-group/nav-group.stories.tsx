import { NavGroup } from "./index";

export default { title: "Navigation/NavGroup" };

export const Default = () => (
  <div className="w-60">
    <NavGroup label="Main Navigation">
      <div className="text-sm text-zinc-300 px-2 py-1">Dashboard</div>
      <div className="text-sm text-zinc-300 px-2 py-1">Contacts</div>
      <div className="text-sm text-zinc-300 px-2 py-1">Companies</div>
    </NavGroup>
  </div>
);

export const Collapsible = () => (
  <div className="w-60">
    <NavGroup label="Settings" collapsible defaultOpen>
      <div className="text-sm text-zinc-300 px-2 py-1">Profile</div>
      <div className="text-sm text-zinc-300 px-2 py-1">Team</div>
      <div className="text-sm text-zinc-300 px-2 py-1">Billing</div>
    </NavGroup>
  </div>
);

export const CollapsedByDefault = () => (
  <div className="w-60">
    <NavGroup label="Advanced" collapsible defaultOpen={false}>
      <div className="text-sm text-zinc-300 px-2 py-1">API Keys</div>
      <div className="text-sm text-zinc-300 px-2 py-1">Webhooks</div>
    </NavGroup>
  </div>
);
