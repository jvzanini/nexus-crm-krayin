import { Toast } from "./index";

export default { title: "Overlays/Toast" };

export const Default = () => (
  <Toast title="Event created" description="Your event has been saved." />
);

export const Success = () => (
  <Toast variant="success" title="Saved!" description="Changes saved successfully." />
);

export const Warning = () => (
  <Toast variant="warning" title="Warning" description="You are about to exceed your quota." />
);

export const Danger = () => (
  <Toast variant="danger" title="Error" description="Something went wrong." />
);

export const Info = () => (
  <Toast variant="info" title="Update available" description="A new version is ready." />
);

export const WithAction = () => (
  <Toast
    title="Item deleted"
    description="The item was removed."
    action={<button className="text-xs text-violet-400 hover:underline">Undo</button>}
  />
);
