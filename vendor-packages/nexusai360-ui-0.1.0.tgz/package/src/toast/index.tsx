import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  Toast variants                                                     */
/* ------------------------------------------------------------------ */
const toastVariants = cva(
  [
    "group pointer-events-auto relative flex w-full items-start gap-3 overflow-hidden",
    "rounded-xl border p-4 shadow-lg transition-all",
  ].join(" "),
  {
    variants: {
      variant: {
        default: "border-zinc-800 bg-zinc-950 text-zinc-50",
        success:
          "border-emerald-800 bg-emerald-950 text-emerald-50",
        warning:
          "border-amber-800 bg-amber-950 text-amber-50",
        danger:
          "border-red-800 bg-red-950 text-red-50",
        info:
          "border-sky-800 bg-sky-950 text-sky-50",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface ToastProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof toastVariants> {
  /** Toast title */
  title?: string;
  /** Toast description */
  description?: string;
  /** Optional action element (e.g. undo button) */
  action?: React.ReactNode;
  /** Duration in ms before auto-dismiss (0 = no auto-dismiss) */
  duration?: number;
  /** Callback when toast is dismissed */
  onDismiss?: () => void;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const Toast = React.forwardRef<HTMLDivElement, ToastProps>(
  (
    {
      className,
      variant,
      title,
      description,
      action,
      duration = 5000,
      onDismiss,
      children,
      ...props
    },
    ref,
  ) => {
    React.useEffect(() => {
      if (duration <= 0 || !onDismiss) return;
      const timer = setTimeout(onDismiss, duration);
      return () => clearTimeout(timer);
    }, [duration, onDismiss]);

    return (
      <div
        ref={ref}
        role="status"
        aria-live="polite"
        className={cn(toastVariants({ variant }), className)}
        data-variant={variant ?? "default"}
        {...props}
      >
        <div className="flex-1 space-y-1">
          {title && (
            <div className="text-sm font-semibold">{title}</div>
          )}
          {description && (
            <div className="text-sm opacity-90">{description}</div>
          )}
          {children}
        </div>
        {action && <div className="shrink-0">{action}</div>}
        {onDismiss && (
          <button
            type="button"
            aria-label="Dismiss"
            onClick={onDismiss}
            className={cn(
              "absolute right-2 top-2 rounded-md p-1 opacity-0 transition-opacity",
              "hover:opacity-100 group-hover:opacity-70 focus:opacity-100 focus:outline-none",
              "focus-visible:ring-2 focus-visible:ring-violet-500/50",
            )}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        )}
      </div>
    );
  },
);

Toast.displayName = "Toast";

export { Toast, toastVariants };
