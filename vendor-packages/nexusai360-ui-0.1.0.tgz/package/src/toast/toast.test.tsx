import { describe, it, expect, vi } from "vitest";
import { render, screen, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Toast } from "./index";

describe("Toast", () => {
  it("renders with default variant", () => {
    render(<Toast title="Hello" />);
    const toast = screen.getByRole("status");
    expect(toast).toBeInTheDocument();
    expect(toast).toHaveAttribute("data-variant", "default");
  });

  it("renders title", () => {
    render(<Toast title="My Title" />);
    expect(screen.getByText("My Title")).toBeInTheDocument();
  });

  it("renders description", () => {
    render(<Toast description="My Desc" />);
    expect(screen.getByText("My Desc")).toBeInTheDocument();
  });

  it("renders success variant", () => {
    render(<Toast variant="success" title="OK" />);
    const toast = screen.getByRole("status");
    expect(toast.className).toContain("border-emerald-800");
    expect(toast).toHaveAttribute("data-variant", "success");
  });

  it("renders warning variant", () => {
    render(<Toast variant="warning" title="Warn" />);
    const toast = screen.getByRole("status");
    expect(toast.className).toContain("border-amber-800");
  });

  it("renders danger variant", () => {
    render(<Toast variant="danger" title="Err" />);
    const toast = screen.getByRole("status");
    expect(toast.className).toContain("border-red-800");
  });

  it("renders info variant", () => {
    render(<Toast variant="info" title="Info" />);
    const toast = screen.getByRole("status");
    expect(toast.className).toContain("border-sky-800");
  });

  it("renders action element", () => {
    render(
      <Toast
        title="Undo?"
        action={<button data-testid="undo">Undo</button>}
      />,
    );
    expect(screen.getByTestId("undo")).toBeInTheDocument();
  });

  it("calls onDismiss when dismiss button clicked", async () => {
    const user = userEvent.setup();
    const onDismiss = vi.fn();
    render(<Toast title="Hi" onDismiss={onDismiss} duration={0} />);
    await user.click(screen.getByLabelText("Dismiss"));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });

  it("auto-dismisses after duration", () => {
    vi.useFakeTimers();
    const onDismiss = vi.fn();
    render(<Toast title="Auto" duration={3000} onDismiss={onDismiss} />);
    expect(onDismiss).not.toHaveBeenCalled();
    act(() => {
      vi.advanceTimersByTime(3000);
    });
    expect(onDismiss).toHaveBeenCalledTimes(1);
    vi.useRealTimers();
  });

  it("does not auto-dismiss when duration is 0", () => {
    vi.useFakeTimers();
    const onDismiss = vi.fn();
    render(<Toast title="Stay" duration={0} onDismiss={onDismiss} />);
    act(() => {
      vi.advanceTimersByTime(10000);
    });
    expect(onDismiss).not.toHaveBeenCalled();
    vi.useRealTimers();
  });

  it("does not show dismiss button when onDismiss is not provided", () => {
    render(<Toast title="No dismiss" />);
    expect(screen.queryByLabelText("Dismiss")).not.toBeInTheDocument();
  });

  it("has role=status and aria-live=polite", () => {
    render(<Toast title="A11y" />);
    const toast = screen.getByRole("status");
    expect(toast).toHaveAttribute("aria-live", "polite");
  });

  it("renders children", () => {
    render(<Toast><span data-testid="child">Custom</span></Toast>);
    expect(screen.getByTestId("child")).toBeInTheDocument();
  });

  it("merges custom className", () => {
    render(<Toast title="Cls" className="my-toast" />);
    expect(screen.getByRole("status").className).toContain("my-toast");
  });

  it("has displayName", () => {
    expect(Toast.displayName).toBe("Toast");
  });

  it("clears timer on unmount", () => {
    vi.useFakeTimers();
    const onDismiss = vi.fn();
    const { unmount } = render(
      <Toast title="Unmount" duration={5000} onDismiss={onDismiss} />,
    );
    unmount();
    act(() => {
      vi.advanceTimersByTime(5000);
    });
    expect(onDismiss).not.toHaveBeenCalled();
    vi.useRealTimers();
  });
});
