import { describe, it, expect, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
} from "./index";

function renderAlertDialog(props: { onOpenChange?: (open: boolean) => void } = {}) {
  return render(
    <AlertDialog {...props}>
      <AlertDialogTrigger>Delete</AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>
            This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction>Confirm</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>,
  );
}

describe("AlertDialog", () => {
  it("renders trigger", () => {
    renderAlertDialog();
    expect(screen.getByText("Delete")).toBeInTheDocument();
  });

  it("opens on trigger click", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    expect(screen.getByText("Are you sure?")).toBeInTheDocument();
  });

  it("shows description when open", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    expect(
      screen.getByText("This action cannot be undone."),
    ).toBeInTheDocument();
  });

  it("closes on cancel click", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    await user.click(screen.getByText("Cancel"));
    await waitFor(() =>
      expect(screen.queryByText("Are you sure?")).not.toBeInTheDocument(),
    );
  });

  it("closes on action click", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    await user.click(screen.getByText("Confirm"));
    await waitFor(() =>
      expect(screen.queryByText("Are you sure?")).not.toBeInTheDocument(),
    );
  });

  it("does NOT close on overlay click (no dismiss on outside)", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    // AlertDialog should not dismiss on outside click — Radix enforces this by default
    expect(screen.getByRole("alertdialog")).toBeInTheDocument();
  });

  it("renders confirm and cancel buttons when open", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    expect(screen.getByText("Confirm")).toBeInTheDocument();
    expect(screen.getByText("Cancel")).toBeInTheDocument();
  });

  it("calls onOpenChange", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    renderAlertDialog({ onOpenChange });
    await user.click(screen.getByText("Delete"));
    expect(onOpenChange).toHaveBeenCalledWith(true);
  });

  it("renders alertdialog role", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    expect(screen.getByRole("alertdialog")).toBeInTheDocument();
  });

  it("AlertDialogAction has danger styling", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    const action = screen.getByText("Confirm");
    expect(action.className).toContain("bg-red-600");
  });

  it("AlertDialogCancel has secondary styling", async () => {
    const user = userEvent.setup();
    renderAlertDialog();
    await user.click(screen.getByText("Delete"));
    const cancel = screen.getByText("Cancel");
    expect(cancel.className).toContain("bg-zinc-800");
  });

  it("AlertDialogHeader has displayName", () => {
    expect(AlertDialogHeader.displayName).toBe("AlertDialogHeader");
  });

  it("AlertDialogFooter has displayName", () => {
    expect(AlertDialogFooter.displayName).toBe("AlertDialogFooter");
  });

  it("AlertDialogTitle has displayName", () => {
    expect(AlertDialogTitle.displayName).toBe("AlertDialogTitle");
  });

  it("AlertDialogDescription has displayName", () => {
    expect(AlertDialogDescription.displayName).toBe("AlertDialogDescription");
  });

  it("AlertDialogContent has displayName", () => {
    expect(AlertDialogContent.displayName).toBe("AlertDialogContent");
  });

  it("AlertDialogAction has displayName", () => {
    expect(AlertDialogAction.displayName).toBe("AlertDialogAction");
  });

  it("AlertDialogCancel has displayName", () => {
    expect(AlertDialogCancel.displayName).toBe("AlertDialogCancel");
  });
});
