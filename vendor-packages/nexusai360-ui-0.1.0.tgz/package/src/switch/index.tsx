import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

const switchTrackVariants = cva(
  [
    "peer relative inline-flex shrink-0 cursor-pointer items-center rounded-full",
    "border-2 border-transparent transition-colors",
    "outline-none",
    "focus-visible:ring-2 focus-visible:ring-violet-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
    "disabled:cursor-not-allowed disabled:opacity-50",
  ].join(" "),
  {
    variants: {
      size: {
        sm: "h-5 w-9",
        md: "h-6 w-11",
      },
    },
    defaultVariants: {
      size: "md",
    },
  }
);

const thumbSizeMap = {
  sm: "size-4",
  md: "size-5",
} as const;

const thumbTranslateMap = {
  sm: "translate-x-4",
  md: "translate-x-5",
} as const;

export interface SwitchProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "onChange" | "value">,
    VariantProps<typeof switchTrackVariants> {
  /** Controlled checked state */
  checked?: boolean;
  /** Callback when state changes */
  onCheckedChange?: (checked: boolean) => void;
  /** Label displayed beside the switch */
  label?: string;
}

const Switch = React.forwardRef<HTMLButtonElement, SwitchProps>(
  (
    {
      className,
      size = "md",
      checked = false,
      onCheckedChange,
      disabled = false,
      label,
      id: providedId,
      ...props
    },
    ref
  ) => {
    const autoId = React.useId();
    const id = providedId ?? autoId;
    const sizeKey = size ?? "md";

    const handleClick = React.useCallback(() => {
      if (!disabled) {
        onCheckedChange?.(!checked);
      }
    }, [disabled, checked, onCheckedChange]);

    const handleKeyDown = React.useCallback(
      (e: React.KeyboardEvent<HTMLButtonElement>) => {
        if (e.key === " " || e.key === "Enter") {
          e.preventDefault();
          handleClick();
        }
      },
      [handleClick]
    );

    const track = (
      <button
        ref={ref}
        id={id}
        type="button"
        role="switch"
        aria-checked={checked}
        disabled={disabled}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        className={cn(
          switchTrackVariants({ size }),
          // Roteador matriz alignment — violet-600 em dark, violet-700 no hover light.
          checked ? "bg-violet-600 hover:bg-violet-500" : "bg-zinc-700 hover:bg-zinc-600",
          className
        )}
        {...props}
      >
        <span
          className={cn(
            "pointer-events-none block rounded-full bg-white shadow-sm transition-transform",
            thumbSizeMap[sizeKey],
            checked ? thumbTranslateMap[sizeKey] : "translate-x-0"
          )}
          aria-hidden="true"
        />
      </button>
    );

    if (label) {
      return (
        <div className="flex items-center gap-3">
          {track}
          <label
            htmlFor={id}
            className={cn(
              "text-sm font-medium text-zinc-200 select-none cursor-pointer",
              disabled && "opacity-50 cursor-not-allowed"
            )}
          >
            {label}
          </label>
        </div>
      );
    }

    return track;
  }
);

Switch.displayName = "Switch";

export { Switch, switchTrackVariants };
