import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Switch } from "./index";

describe("Switch", () => {
  it("renders a switch", () => {
    render(<Switch />);
    expect(screen.getByRole("switch")).toBeInTheDocument();
  });

  it("renders unchecked by default", () => {
    render(<Switch />);
    expect(screen.getByRole("switch")).toHaveAttribute("aria-checked", "false");
  });

  it("renders checked when checked=true", () => {
    render(<Switch checked />);
    expect(screen.getByRole("switch")).toHaveAttribute("aria-checked", "true");
  });

  it("toggles on click", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Switch checked={false} onCheckedChange={onCheckedChange} />);
    await user.click(screen.getByRole("switch"));
    expect(onCheckedChange).toHaveBeenCalledWith(true);
  });

  it("toggles off on click when checked", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Switch checked onCheckedChange={onCheckedChange} />);
    await user.click(screen.getByRole("switch"));
    expect(onCheckedChange).toHaveBeenCalledWith(false);
  });

  it("does not toggle when disabled", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Switch disabled onCheckedChange={onCheckedChange} />);
    await user.click(screen.getByRole("switch"));
    expect(onCheckedChange).not.toHaveBeenCalled();
  });

  it("renders with label", () => {
    render(<Switch label="Dark mode" />);
    expect(screen.getByText("Dark mode")).toBeInTheDocument();
  });

  it("associates label with switch", () => {
    render(<Switch label="Dark mode" id="dark" />);
    const label = screen.getByText("Dark mode");
    expect(label).toHaveAttribute("for", "dark");
  });

  it("applies sm size", () => {
    render(<Switch size="sm" />);
    expect(screen.getByRole("switch").className).toContain("h-5");
  });

  it("applies md size", () => {
    render(<Switch size="md" />);
    expect(screen.getByRole("switch").className).toContain("h-6");
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLButtonElement>();
    render(<Switch ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it("has correct displayName", () => {
    expect(Switch.displayName).toBe("Switch");
  });

  it("applies disabled styling", () => {
    render(<Switch disabled />);
    expect(screen.getByRole("switch")).toBeDisabled();
  });

  it("shows checked bg color", () => {
    render(<Switch checked />);
    expect(screen.getByRole("switch").className).toContain("bg-violet-600");
  });

  it("shows unchecked bg color", () => {
    render(<Switch checked={false} />);
    expect(screen.getByRole("switch").className).toContain("bg-zinc-700");
  });
});
