import { useState } from "react";
import { Switch } from "./index";

export default { title: "Primitives/Switch" };

export const Default = () => {
  const [checked, setChecked] = useState(false);
  return <Switch checked={checked} onCheckedChange={setChecked} />;
};

export const WithLabel = () => {
  const [checked, setChecked] = useState(false);
  return <Switch checked={checked} onCheckedChange={setChecked} label="Dark mode" />;
};

export const Small = () => {
  const [checked, setChecked] = useState(true);
  return <Switch size="sm" checked={checked} onCheckedChange={setChecked} label="Small" />;
};

export const Disabled = () => <Switch disabled label="Disabled" />;
export const CheckedDisabled = () => <Switch checked disabled label="Checked disabled" />;
