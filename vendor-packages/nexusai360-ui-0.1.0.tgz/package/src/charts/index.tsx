"use client";

import * as React from "react";
import {
  LineChart as RechartsLineChart,
  BarChart as RechartsBarChart,
  AreaChart as RechartsAreaChart,
  PieChart as RechartsPieChart,
  Line,
  Bar,
  Area,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  LineChart                                                          */
/* ------------------------------------------------------------------ */

export interface LineChartProps {
  data: Record<string, unknown>[];
  xKey: string;
  yKey: string;
  color?: string;
  height?: number;
  showGrid?: boolean;
  showTooltip?: boolean;
  className?: string;
}

export const LineChart = React.forwardRef<HTMLDivElement, LineChartProps>(
  (
    {
      data,
      xKey,
      yKey,
      color = "#8b5cf6",
      height = 300,
      showGrid = true,
      showTooltip = true,
      className,
    },
    ref,
  ) => (
    <div ref={ref} className={cn("w-full", className)} data-testid="line-chart">
      <ResponsiveContainer width="100%" height={height}>
        <RechartsLineChart data={data}>
          {showGrid && <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />}
          <XAxis dataKey={xKey} stroke="#71717a" fontSize={12} />
          <YAxis stroke="#71717a" fontSize={12} />
          {showTooltip && (
            <RechartsTooltip
              contentStyle={{
                backgroundColor: "#18181b",
                border: "1px solid #27272a",
                borderRadius: 8,
                color: "#fafafa",
              }}
            />
          )}
          <Line
            type="monotone"
            dataKey={yKey}
            stroke={color}
            strokeWidth={2}
            dot={false}
            activeDot={{ r: 4 }}
          />
        </RechartsLineChart>
      </ResponsiveContainer>
    </div>
  ),
);
LineChart.displayName = "LineChart";

/* ------------------------------------------------------------------ */
/*  BarChart                                                           */
/* ------------------------------------------------------------------ */

export interface BarChartProps {
  data: Record<string, unknown>[];
  xKey: string;
  yKey: string | string[];
  color?: string | string[];
  height?: number;
  stacked?: boolean;
  horizontal?: boolean;
  className?: string;
}

export const BarChart = React.forwardRef<HTMLDivElement, BarChartProps>(
  (
    {
      data,
      xKey,
      yKey,
      color = "#8b5cf6",
      height = 300,
      stacked = false,
      horizontal = false,
      className,
    },
    ref,
  ) => {
    const yKeys = Array.isArray(yKey) ? yKey : [yKey];
    const colors = Array.isArray(color) ? color : [color];
    const layout = horizontal ? "vertical" : "horizontal";

    return (
      <div ref={ref} className={cn("w-full", className)} data-testid="bar-chart">
        <ResponsiveContainer width="100%" height={height}>
          <RechartsBarChart data={data} layout={layout}>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
            {horizontal ? (
              <>
                <XAxis type="number" stroke="#71717a" fontSize={12} />
                <YAxis dataKey={xKey} type="category" stroke="#71717a" fontSize={12} />
              </>
            ) : (
              <>
                <XAxis dataKey={xKey} stroke="#71717a" fontSize={12} />
                <YAxis stroke="#71717a" fontSize={12} />
              </>
            )}
            <RechartsTooltip
              contentStyle={{
                backgroundColor: "#18181b",
                border: "1px solid #27272a",
                borderRadius: 8,
                color: "#fafafa",
              }}
            />
            {yKeys.map((key, i) => (
              <Bar
                key={key}
                dataKey={key}
                fill={colors[i % colors.length]}
                stackId={stacked ? "stack" : undefined}
                radius={[4, 4, 0, 0]}
              />
            ))}
          </RechartsBarChart>
        </ResponsiveContainer>
      </div>
    );
  },
);
BarChart.displayName = "BarChart";

/* ------------------------------------------------------------------ */
/*  AreaChart                                                          */
/* ------------------------------------------------------------------ */

export interface AreaChartProps {
  data: Record<string, unknown>[];
  xKey: string;
  yKey: string;
  color?: string;
  height?: number;
  className?: string;
}

export const AreaChart = React.forwardRef<HTMLDivElement, AreaChartProps>(
  (
    { data, xKey, yKey, color = "#8b5cf6", height = 300, className },
    ref,
  ) => {
    const gradientId = React.useId().replace(/:/g, "");
    return (
      <div ref={ref} className={cn("w-full", className)} data-testid="area-chart">
        <ResponsiveContainer width="100%" height={height}>
          <RechartsAreaChart data={data}>
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                <stop offset="95%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
            <XAxis dataKey={xKey} stroke="#71717a" fontSize={12} />
            <YAxis stroke="#71717a" fontSize={12} />
            <RechartsTooltip
              contentStyle={{
                backgroundColor: "#18181b",
                border: "1px solid #27272a",
                borderRadius: 8,
                color: "#fafafa",
              }}
            />
            <Area
              type="monotone"
              dataKey={yKey}
              stroke={color}
              strokeWidth={2}
              fill={`url(#${gradientId})`}
            />
          </RechartsAreaChart>
        </ResponsiveContainer>
      </div>
    );
  },
);
AreaChart.displayName = "AreaChart";

/* ------------------------------------------------------------------ */
/*  PieChart                                                           */
/* ------------------------------------------------------------------ */

export interface PieChartProps {
  data: Record<string, unknown>[];
  nameKey: string;
  valueKey: string;
  colors?: string[];
  donut?: boolean;
  showLabel?: boolean;
  height?: number;
  className?: string;
}

const DEFAULT_COLORS = [
  "#8b5cf6",
  "#6366f1",
  "#ec4899",
  "#f59e0b",
  "#10b981",
  "#3b82f6",
  "#f97316",
  "#14b8a6",
];

export const PieChart = React.forwardRef<HTMLDivElement, PieChartProps>(
  (
    {
      data,
      nameKey,
      valueKey,
      colors = DEFAULT_COLORS,
      donut = false,
      showLabel = false,
      height = 300,
      className,
    },
    ref,
  ) => (
    <div ref={ref} className={cn("w-full", className)} data-testid="pie-chart">
      <ResponsiveContainer width="100%" height={height}>
        <RechartsPieChart>
          <Pie
            data={data}
            dataKey={valueKey}
            nameKey={nameKey}
            cx="50%"
            cy="50%"
            innerRadius={donut ? "55%" : 0}
            outerRadius="80%"
            label={showLabel}
          >
            {data.map((_, index) => (
              <Cell
                key={`cell-${index}`}
                fill={colors[index % colors.length]}
              />
            ))}
          </Pie>
          <RechartsTooltip
            contentStyle={{
              backgroundColor: "#18181b",
              border: "1px solid #27272a",
              borderRadius: 8,
              color: "#fafafa",
            }}
          />
          <Legend />
        </RechartsPieChart>
      </ResponsiveContainer>
    </div>
  ),
);
PieChart.displayName = "PieChart";

/* ------------------------------------------------------------------ */
/*  SparklineChart                                                     */
/* ------------------------------------------------------------------ */

export interface SparklineChartProps {
  data: number[];
  color?: string;
  width?: number;
  height?: number;
  className?: string;
}

export const SparklineChart = React.forwardRef<
  HTMLDivElement,
  SparklineChartProps
>(
  (
    { data, color = "#8b5cf6", width = 120, height = 32, className },
    ref,
  ) => {
    const chartData = data.map((value, index) => ({ index, value }));
    return (
      <div
        ref={ref}
        className={cn("inline-block", className)}
        data-testid="sparkline-chart"
      >
        <ResponsiveContainer width={width} height={height}>
          <RechartsLineChart data={chartData}>
            <Line
              type="monotone"
              dataKey="value"
              stroke={color}
              strokeWidth={1.5}
              dot={false}
            />
          </RechartsLineChart>
        </ResponsiveContainer>
      </div>
    );
  },
);
SparklineChart.displayName = "SparklineChart";

/* ------------------------------------------------------------------ */
/*  KpiCard                                                            */
/* ------------------------------------------------------------------ */

export interface KpiCardProps {
  title: string;
  value: string | number;
  change?: number;
  changeLabel?: string;
  icon?: React.ReactNode;
  trend?: "up" | "down" | "neutral";
  className?: string;
}

const TrendArrow: React.FC<{ trend: "up" | "down" | "neutral" }> = ({
  trend,
}) => {
  if (trend === "up")
    return (
      <svg
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        aria-hidden="true"
        data-testid="trend-up"
      >
        <path
          d="M8 4L12 8H4L8 4Z"
          fill="currentColor"
        />
      </svg>
    );
  if (trend === "down")
    return (
      <svg
        width="16"
        height="16"
        viewBox="0 0 16 16"
        fill="none"
        aria-hidden="true"
        data-testid="trend-down"
      >
        <path
          d="M8 12L4 8H12L8 12Z"
          fill="currentColor"
        />
      </svg>
    );
  return null;
};

export const KpiCard = React.forwardRef<HTMLDivElement, KpiCardProps>(
  (
    { title, value, change, changeLabel, icon, trend = "neutral", className },
    ref,
  ) => {
    const trendColor =
      trend === "up"
        ? "text-emerald-400"
        : trend === "down"
          ? "text-red-400"
          : "text-zinc-400";

    return (
      <div
        ref={ref}
        className={cn(
          "rounded-2xl border border-zinc-800 bg-zinc-900 p-5",
          className,
        )}
        data-testid="kpi-card"
      >
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-zinc-400">{title}</span>
          {icon && (
            <span className="text-zinc-500" data-testid="kpi-icon">
              {icon}
            </span>
          )}
        </div>
        <div className="mt-2 text-2xl font-bold text-zinc-50">{value}</div>
        {change !== undefined && (
          <div className={cn("mt-1 flex items-center gap-1 text-sm", trendColor)}>
            <TrendArrow trend={trend} />
            <span>
              {change > 0 ? "+" : ""}
              {change}%
            </span>
            {changeLabel && (
              <span className="text-zinc-500">{changeLabel}</span>
            )}
          </div>
        )}
      </div>
    );
  },
);
KpiCard.displayName = "KpiCard";
