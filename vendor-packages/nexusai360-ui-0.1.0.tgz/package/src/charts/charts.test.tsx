import { describe, it, expect, vi, beforeAll } from "vitest";
import { render, screen } from "@testing-library/react";
import {
  LineChart,
  BarChart,
  AreaChart,
  PieChart,
  SparklineChart,
  KpiCard,
} from "./index";

/* ------------------------------------------------------------------ */
/*  Mock Recharts — ResponsiveContainer needs a real DOM width,        */
/*  which jsdom doesn't provide. We mock the container to just render  */
/*  children, and mock chart components to render simple divs.         */
/* ------------------------------------------------------------------ */

vi.mock("recharts", () => {
  const React = require("react");
  const createMock = (name: string) =>
    React.forwardRef(({ children, ...props }: any, ref: any) =>
      React.createElement("div", { "data-testid": `mock-${name}`, ref, ...filterProps(props) }, children),
    );
  const filterProps = (props: Record<string, unknown>) => {
    const safe: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(props)) {
      if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") {
        safe[`data-${k.toLowerCase()}`] = String(v);
      }
    }
    return safe;
  };
  return {
    ResponsiveContainer: ({ children }: any) =>
      React.createElement("div", { "data-testid": "responsive-container" }, children),
    LineChart: createMock("line-chart-inner"),
    BarChart: createMock("bar-chart-inner"),
    AreaChart: createMock("area-chart-inner"),
    PieChart: createMock("pie-chart-inner"),
    Line: createMock("line"),
    Bar: createMock("bar"),
    Area: createMock("area"),
    Pie: createMock("pie"),
    Cell: createMock("cell"),
    XAxis: createMock("xaxis"),
    YAxis: createMock("yaxis"),
    CartesianGrid: createMock("grid"),
    Tooltip: createMock("tooltip"),
    Legend: createMock("legend"),
  };
});

const sampleData = [
  { month: "Jan", value: 100, sales: 200 },
  { month: "Feb", value: 200, sales: 150 },
  { month: "Mar", value: 150, sales: 300 },
];

const pieData = [
  { name: "A", value: 30 },
  { name: "B", value: 70 },
];

/* ================================================================== */
/*  LineChart                                                          */
/* ================================================================== */

describe("LineChart", () => {
  it("renders with data-testid", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" />);
    expect(screen.getByTestId("line-chart")).toBeInTheDocument();
  });

  it("renders ResponsiveContainer", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" />);
    expect(screen.getByTestId("responsive-container")).toBeInTheDocument();
  });

  it("applies custom className", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" className="custom" />);
    expect(screen.getByTestId("line-chart")).toHaveClass("custom");
  });

  it("renders grid when showGrid=true (default)", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" />);
    expect(screen.getByTestId("mock-grid")).toBeInTheDocument();
  });

  it("hides grid when showGrid=false", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" showGrid={false} />);
    expect(screen.queryByTestId("mock-grid")).not.toBeInTheDocument();
  });

  it("renders tooltip when showTooltip=true (default)", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" />);
    expect(screen.getByTestId("mock-tooltip")).toBeInTheDocument();
  });

  it("hides tooltip when showTooltip=false", () => {
    render(<LineChart data={sampleData} xKey="month" yKey="value" showTooltip={false} />);
    expect(screen.queryByTestId("mock-tooltip")).not.toBeInTheDocument();
  });

  it("has correct displayName", () => {
    expect(LineChart.displayName).toBe("LineChart");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<LineChart ref={ref} data={sampleData} xKey="month" yKey="value" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });
});

/* ================================================================== */
/*  BarChart                                                           */
/* ================================================================== */

describe("BarChart", () => {
  it("renders with data-testid", () => {
    render(<BarChart data={sampleData} xKey="month" yKey="value" />);
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
  });

  it("renders with multiple yKeys", () => {
    render(<BarChart data={sampleData} xKey="month" yKey={["value", "sales"]} color={["#f00", "#0f0"]} />);
    const bars = screen.getAllByTestId("mock-bar");
    expect(bars.length).toBe(2);
  });

  it("applies custom className", () => {
    render(<BarChart data={sampleData} xKey="month" yKey="value" className="bar-cls" />);
    expect(screen.getByTestId("bar-chart")).toHaveClass("bar-cls");
  });

  it("has correct displayName", () => {
    expect(BarChart.displayName).toBe("BarChart");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<BarChart ref={ref} data={sampleData} xKey="month" yKey="value" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("renders horizontal layout", () => {
    render(<BarChart data={sampleData} xKey="month" yKey="value" horizontal />);
    expect(screen.getByTestId("bar-chart")).toBeInTheDocument();
  });

  it("renders stacked bars", () => {
    render(<BarChart data={sampleData} xKey="month" yKey={["value", "sales"]} stacked />);
    expect(screen.getAllByTestId("mock-bar").length).toBe(2);
  });
});

/* ================================================================== */
/*  AreaChart                                                          */
/* ================================================================== */

describe("AreaChart", () => {
  it("renders with data-testid", () => {
    render(<AreaChart data={sampleData} xKey="month" yKey="value" />);
    expect(screen.getByTestId("area-chart")).toBeInTheDocument();
  });

  it("applies custom className", () => {
    render(<AreaChart data={sampleData} xKey="month" yKey="value" className="area-cls" />);
    expect(screen.getByTestId("area-chart")).toHaveClass("area-cls");
  });

  it("has correct displayName", () => {
    expect(AreaChart.displayName).toBe("AreaChart");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<AreaChart ref={ref} data={sampleData} xKey="month" yKey="value" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("renders gradient defs", () => {
    const { container } = render(<AreaChart data={sampleData} xKey="month" yKey="value" />);
    expect(container.querySelector("linearGradient") || screen.getByTestId("responsive-container")).toBeTruthy();
  });
});

/* ================================================================== */
/*  PieChart                                                           */
/* ================================================================== */

describe("PieChart", () => {
  it("renders with data-testid", () => {
    render(<PieChart data={pieData} nameKey="name" valueKey="value" />);
    expect(screen.getByTestId("pie-chart")).toBeInTheDocument();
  });

  it("applies custom className", () => {
    render(<PieChart data={pieData} nameKey="name" valueKey="value" className="pie-cls" />);
    expect(screen.getByTestId("pie-chart")).toHaveClass("pie-cls");
  });

  it("has correct displayName", () => {
    expect(PieChart.displayName).toBe("PieChart");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<PieChart ref={ref} data={pieData} nameKey="name" valueKey="value" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("renders cells for each data point", () => {
    render(<PieChart data={pieData} nameKey="name" valueKey="value" />);
    const cells = screen.getAllByTestId("mock-cell");
    expect(cells.length).toBe(2);
  });

  it("renders legend", () => {
    render(<PieChart data={pieData} nameKey="name" valueKey="value" />);
    expect(screen.getByTestId("mock-legend")).toBeInTheDocument();
  });
});

/* ================================================================== */
/*  SparklineChart                                                     */
/* ================================================================== */

describe("SparklineChart", () => {
  it("renders with data-testid", () => {
    render(<SparklineChart data={[1, 2, 3, 4]} />);
    expect(screen.getByTestId("sparkline-chart")).toBeInTheDocument();
  });

  it("applies custom className", () => {
    render(<SparklineChart data={[1, 2]} className="spark-cls" />);
    expect(screen.getByTestId("sparkline-chart")).toHaveClass("spark-cls");
  });

  it("has correct displayName", () => {
    expect(SparklineChart.displayName).toBe("SparklineChart");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<SparklineChart ref={ref} data={[1, 2, 3]} />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("uses inline-block display", () => {
    render(<SparklineChart data={[1, 2, 3]} />);
    expect(screen.getByTestId("sparkline-chart")).toHaveClass("inline-block");
  });
});

/* ================================================================== */
/*  KpiCard                                                            */
/* ================================================================== */

describe("KpiCard", () => {
  it("renders title and value", () => {
    render(<KpiCard title="Revenue" value="$12,345" />);
    expect(screen.getByText("Revenue")).toBeInTheDocument();
    expect(screen.getByText("$12,345")).toBeInTheDocument();
  });

  it("renders change with positive sign", () => {
    render(<KpiCard title="T" value="1" change={12} />);
    expect(screen.getByText("+12%")).toBeInTheDocument();
  });

  it("renders change label", () => {
    render(<KpiCard title="T" value="1" change={5} changeLabel="vs last month" />);
    expect(screen.getByText("vs last month")).toBeInTheDocument();
  });

  it("renders icon slot", () => {
    render(<KpiCard title="T" value="1" icon={<span data-testid="my-icon">★</span>} />);
    expect(screen.getByTestId("my-icon")).toBeInTheDocument();
  });

  it("shows trend up arrow", () => {
    render(<KpiCard title="T" value="1" change={10} trend="up" />);
    expect(screen.getByTestId("trend-up")).toBeInTheDocument();
  });

  it("shows trend down arrow", () => {
    render(<KpiCard title="T" value="1" change={-5} trend="down" />);
    expect(screen.getByTestId("trend-down")).toBeInTheDocument();
  });

  it("no arrow for neutral trend", () => {
    render(<KpiCard title="T" value="1" change={0} trend="neutral" />);
    expect(screen.queryByTestId("trend-up")).not.toBeInTheDocument();
    expect(screen.queryByTestId("trend-down")).not.toBeInTheDocument();
  });

  it("applies custom className", () => {
    render(<KpiCard title="T" value="1" className="kpi-cls" />);
    expect(screen.getByTestId("kpi-card")).toHaveClass("kpi-cls");
  });

  it("has correct displayName", () => {
    expect(KpiCard.displayName).toBe("KpiCard");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<KpiCard ref={ref} title="T" value="1" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("hides change section when change is undefined", () => {
    render(<KpiCard title="T" value="1" />);
    expect(screen.queryByText("%")).not.toBeInTheDocument();
  });

  it("renders numeric value", () => {
    render(<KpiCard title="Count" value={42} />);
    expect(screen.getByText("42")).toBeInTheDocument();
  });
});
