import { LineChart, BarChart, AreaChart, PieChart, SparklineChart, KpiCard } from "./index";

export default { title: "Charts/Charts" };

const timeData = [
  { label: "Jan", value: 400 },
  { label: "Feb", value: 300 },
  { label: "Mar", value: 600 },
  { label: "Apr", value: 800 },
  { label: "May", value: 500 },
  { label: "Jun", value: 900 },
];

export const Line = () => (
  <div style={{ width: 500, height: 300 }}>
    <LineChart data={timeData} xKey="label" yKey="value" />
  </div>
);

export const Bar = () => (
  <div style={{ width: 500, height: 300 }}>
    <BarChart data={timeData} xKey="label" yKey="value" />
  </div>
);

export const Area = () => (
  <div style={{ width: 500, height: 300 }}>
    <AreaChart data={timeData} xKey="label" yKey="value" />
  </div>
);

const pieData = [
  { label: "Desktop", value: 60 },
  { label: "Mobile", value: 30 },
  { label: "Tablet", value: 10 },
];

export const Pie = () => (
  <div style={{ width: 300, height: 300 }}>
    <PieChart data={pieData} nameKey="label" valueKey="value" />
  </div>
);

export const Sparkline = () => (
  <SparklineChart data={[10, 20, 15, 30, 25, 40, 35]} className="w-32 h-8" />
);

export const Kpi = () => (
  <div style={{ display: "flex", gap: 16 }}>
    <KpiCard title="Revenue" value="$12,340" change={12.5} />
    <KpiCard title="Users" value="1,234" change={-3.2} />
    <KpiCard title="Orders" value="567" />
  </div>
);
