import { describe, it, expect } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { createRef } from "react";
import { Avatar } from "./index";

describe("Avatar", () => {
  // --- Render ---
  it("renders with default size", () => {
    render(<Avatar fallback="JZ" />);
    expect(screen.getByRole("img")).toBeInTheDocument();
  });

  it("renders image when src is provided", () => {
    render(<Avatar src="/photo.jpg" alt="User" />);
    const imgs = screen.getAllByRole("img");
    const img = imgs.find((el) => el.tagName === "IMG");
    expect(img).toBeInTheDocument();
    expect(img).toHaveAttribute("src", "/photo.jpg");
  });

  it("renders alt text on image", () => {
    render(<Avatar src="/photo.jpg" alt="John Doe" />);
    const imgs = screen.getAllByRole("img");
    const img = imgs.find((el) => el.tagName === "IMG");
    expect(img).toHaveAttribute("alt", "John Doe");
  });

  // --- Fallback ---
  it("renders fallback text when no src", () => {
    render(<Avatar fallback="AB" />);
    expect(screen.getByText("AB")).toBeInTheDocument();
  });

  it("renders fallback icon (ReactNode)", () => {
    render(<Avatar fallback={<span data-testid="icon">★</span>} />);
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  it("shows fallback on image error", () => {
    render(<Avatar src="/broken.jpg" fallback="FB" />);
    const img = screen.getByRole("img").querySelector("img")!;
    fireEvent.error(img);
    expect(screen.getByText("FB")).toBeInTheDocument();
  });

  // --- Sizes ---
  it("applies xs size", () => {
    render(<Avatar size="xs" fallback="X" />);
    expect(screen.getByRole("img").className).toContain("size-6");
  });

  it("applies sm size", () => {
    render(<Avatar size="sm" fallback="S" />);
    expect(screen.getByRole("img").className).toContain("size-8");
  });

  it("applies md size (default)", () => {
    render(<Avatar fallback="M" />);
    expect(screen.getByRole("img").className).toContain("size-10");
  });

  it("applies lg size", () => {
    render(<Avatar size="lg" fallback="L" />);
    expect(screen.getByRole("img").className).toContain("size-12");
  });

  it("applies xl size", () => {
    render(<Avatar size="xl" fallback="XL" />);
    expect(screen.getByRole("img").className).toContain("size-16");
  });

  // --- Ref ---
  it("forwards ref", () => {
    const ref = createRef<HTMLSpanElement>();
    render(<Avatar ref={ref} fallback="R" />);
    expect(ref.current).toBeInstanceOf(HTMLSpanElement);
  });

  // --- className ---
  it("merges custom className", () => {
    render(<Avatar fallback="C" className="custom-cls" />);
    expect(screen.getByRole("img").className).toContain("custom-cls");
  });

  // --- aria-label ---
  it("uses alt as aria-label", () => {
    render(<Avatar fallback="X" alt="Test user" />);
    expect(screen.getByRole("img")).toHaveAttribute("aria-label", "Test user");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(Avatar.displayName).toBe("Avatar");
  });
});
