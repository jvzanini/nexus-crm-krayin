import { Avatar } from "./index";

export default { title: "Navigation/Avatar" };

export const WithImage = () => (
  <Avatar src="https://i.pravatar.cc/150?u=nexus" alt="User" />
);

export const WithFallback = () => <Avatar fallback="JV" />;

export const Sizes = () => (
  <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
    <Avatar size="xs" fallback="XS" />
    <Avatar size="sm" fallback="SM" />
    <Avatar size="md" fallback="MD" />
    <Avatar size="lg" fallback="LG" />
    <Avatar size="xl" fallback="XL" />
  </div>
);

export const IconFallback = () => <Avatar fallback={<span>👤</span>} />;
