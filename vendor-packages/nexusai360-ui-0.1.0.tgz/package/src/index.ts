export { Button, buttonVariants } from "./button";
export type { ButtonProps } from "./button";

export { Input, inputVariants } from "./input";
export type { InputProps } from "./input";

export { Label } from "./label";
export type { LabelProps } from "./label";

export { Textarea, textareaVariants } from "./textarea";
export type { TextareaProps } from "./textarea";

export { Checkbox } from "./checkbox";
export type { CheckboxProps } from "./checkbox";

export { RadioGroup, RadioItem } from "./radio";
export type { RadioGroupProps, RadioItemProps } from "./radio";

export { Switch, switchTrackVariants } from "./switch";
export type { SwitchProps } from "./switch";

export { FormField } from "./form-field";
export type { FormFieldProps } from "./form-field";

export {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
  DialogOverlay,
  DialogPortal,
} from "./dialog";

export {
  AlertDialog,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogOverlay,
  AlertDialogPortal,
} from "./alert-dialog";

export {
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverArrow,
  PopoverAnchor,
} from "./popover";

export {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  TooltipProvider,
} from "./tooltip";

export {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose,
  SheetOverlay,
  SheetPortal,
  sheetContentVariants,
} from "./sheet";
export type { SheetContentProps } from "./sheet";

export { Toast, toastVariants } from "./toast";
export type { ToastProps } from "./toast";

export { Toaster, useToast } from "./toaster";
export type { ToastItem, ToasterProps } from "./toaster";

export { Select, selectTriggerVariants } from "./select";
export type { SelectProps, SelectOption } from "./select";

export { CustomSelect } from "./custom-select";
export type { CustomSelectProps, CustomSelectOption } from "./custom-select";

export { Combobox } from "./combobox";
export type { ComboboxProps, ComboboxOption } from "./combobox";

export { BadgeSelect } from "./badge-select";
export type { BadgeSelectProps, BadgeSelectOption } from "./badge-select";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "./dropdown-menu";
export type {
  DropdownMenuProps,
  DropdownMenuTriggerProps,
  DropdownMenuLabelProps,
  DropdownMenuItemProps,
  DropdownMenuSeparatorProps,
  DropdownMenuCheckboxItemProps,
  DropdownMenuRadioGroupProps,
  DropdownMenuRadioItemProps,
  DropdownMenuSubProps,
  DropdownMenuSubTriggerProps,
  DropdownMenuSubContentProps,
} from "./dropdown-menu";

export {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from "./command";
export type {
  CommandProps,
  CommandInputProps,
  CommandListProps,
  CommandEmptyProps,
  CommandGroupProps,
  CommandItemProps,
  CommandSeparatorProps,
} from "./command";

export {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarItem,
  SidebarSeparator,
  sidebarItemVariants,
  useSidebar,
} from "./sidebar";
export type {
  SidebarProps,
  SidebarHeaderProps,
  SidebarContentProps,
  SidebarFooterProps,
  SidebarGroupProps,
  SidebarGroupLabelProps,
  SidebarItemProps,
  SidebarSeparatorProps,
} from "./sidebar";

export {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "./breadcrumb";
export type {
  BreadcrumbProps,
  BreadcrumbListProps,
  BreadcrumbItemProps,
  BreadcrumbLinkProps,
  BreadcrumbSeparatorProps,
  BreadcrumbPageProps,
} from "./breadcrumb";

export { NavLink, navLinkVariants } from "./nav-link";
export type { NavLinkProps } from "./nav-link";

export { NavGroup } from "./nav-group";
export type { NavGroupProps } from "./nav-group";

export { DatePicker } from "./date-picker";
export type { DatePickerProps } from "./date-picker";

export { highlightJson } from "./json-highlight";

export { Avatar, avatarVariants } from "./avatar";
export type { AvatarProps } from "./avatar";

export { IconTile, iconTileVariants, ICON_TILE_COLORS } from "./icon-tile";
export type { IconTileProps, IconTileColor } from "./icon-tile";

export { Logo, logoVariants } from "./logo";
export type { LogoProps } from "./logo";

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableRow,
  TableHead,
  TableCell,
  TableCaption,
} from "./table";

export {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationLink,
  PaginationEllipsis,
} from "./pagination";
export type { PaginationProps, PaginationLinkProps } from "./pagination";

export { Tabs, TabsList, TabsTrigger, TabsContent } from "./tabs";

export {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "./accordion";

export { Badge, badgeVariants } from "./badge";
export type { BadgeProps } from "./badge";

export { Skeleton } from "./skeleton";
export type { SkeletonProps } from "./skeleton";

export { EmptyState } from "./empty-state";
export type { EmptyStateProps } from "./empty-state";

export { Banner, bannerVariants } from "./banner";
export type { BannerProps } from "./banner";

export { Alert, AlertTitle, AlertDescription, alertVariants } from "./alert";
export type { AlertProps } from "./alert";

// Phase 15 — Charts
export {
  LineChart,
  BarChart,
  AreaChart,
  PieChart,
  SparklineChart,
  KpiCard,
} from "./charts";
export type {
  LineChartProps,
  BarChartProps,
  AreaChartProps,
  PieChartProps,
  SparklineChartProps,
  KpiCardProps,
} from "./charts";

// Phase 16 — Theme
export { ThemeProvider, ThemeToggle, useTheme } from "./theme";
export type {
  Theme,
  ThemeProviderProps,
  ThemeContextValue,
  ThemeToggleProps,
} from "./theme";

// Phase 17 — Motion
export {
  fadeInUp,
  scaleIn,
  slideInRight,
  slideInLeft,
  glowPulse,
  fadeIn,
  collapseVertical,
  AnimatePresence,
  MotionDiv,
} from "./motion";
export type { MotionDivProps } from "./motion";
