import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { Label } from "./index";

describe("Label", () => {
  it("renders label text", () => {
    render(<Label>Email</Label>);
    expect(screen.getByText("Email")).toBeInTheDocument();
  });

  it("renders as a label element", () => {
    render(<Label>Email</Label>);
    expect(screen.getByText("Email").tagName).toBe("LABEL");
  });

  it("associates with input via htmlFor", () => {
    render(<Label htmlFor="email-input">Email</Label>);
    expect(screen.getByText("Email")).toHaveAttribute("for", "email-input");
  });

  it("shows required asterisk", () => {
    render(<Label required>Name</Label>);
    expect(screen.getByText("*")).toBeInTheDocument();
  });

  it("hides asterisk from screen readers", () => {
    render(<Label required>Name</Label>);
    expect(screen.getByText("*")).toHaveAttribute("aria-hidden", "true");
  });

  it("does not show asterisk when not required", () => {
    render(<Label>Name</Label>);
    expect(screen.queryByText("*")).not.toBeInTheDocument();
  });

  it("applies disabled styling", () => {
    render(<Label disabled>Disabled</Label>);
    expect(screen.getByText("Disabled").className).toContain("opacity-50");
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLLabelElement>();
    render(<Label ref={ref}>Ref</Label>);
    expect(ref.current).toBeInstanceOf(HTMLLabelElement);
  });

  it("merges custom className", () => {
    render(<Label className="custom">Custom</Label>);
    expect(screen.getByText("Custom").className).toContain("custom");
  });

  it("has correct displayName", () => {
    expect(Label.displayName).toBe("Label");
  });
});
