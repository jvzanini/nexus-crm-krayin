import { Label } from "./index";

export default { title: "Primitives/Label" };

export const Default = () => <Label>Email address</Label>;
export const Required = () => <Label required>Full name</Label>;
export const Disabled = () => <Label disabled>Disabled label</Label>;
export const WithHtmlFor = () => (
  <div>
    <Label htmlFor="demo">Label for input</Label>
    <input id="demo" type="text" />
  </div>
);
