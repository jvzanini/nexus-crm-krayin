import { useState } from "react";
import { RadioGroup, RadioItem } from "./index";

export default { title: "Primitives/Radio" };

export const Vertical = () => {
  const [value, setValue] = useState("a");
  return (
    <RadioGroup value={value} onValueChange={setValue}>
      <RadioItem value="a" label="Option A" />
      <RadioItem value="b" label="Option B" />
      <RadioItem value="c" label="Option C" />
    </RadioGroup>
  );
};

export const Horizontal = () => {
  const [value, setValue] = useState("a");
  return (
    <RadioGroup value={value} onValueChange={setValue} orientation="horizontal">
      <RadioItem value="a" label="Left" />
      <RadioItem value="b" label="Center" />
      <RadioItem value="c" label="Right" />
    </RadioGroup>
  );
};

export const WithDescriptions = () => (
  <RadioGroup value="free">
    <RadioItem value="free" label="Free" description="Basic features" />
    <RadioItem value="pro" label="Pro" description="All features + support" />
  </RadioGroup>
);

export const Disabled = () => (
  <RadioGroup disabled value="a">
    <RadioItem value="a" label="Disabled A" />
    <RadioItem value="b" label="Disabled B" />
  </RadioGroup>
);
