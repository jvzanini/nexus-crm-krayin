import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { RadioGroup, RadioItem } from "./index";

describe("RadioGroup", () => {
  it("renders a radiogroup", () => {
    render(
      <RadioGroup>
        <RadioItem value="a" label="Option A" />
      </RadioGroup>
    );
    expect(screen.getByRole("radiogroup")).toBeInTheDocument();
  });

  it("renders radio items", () => {
    render(
      <RadioGroup>
        <RadioItem value="a" label="A" />
        <RadioItem value="b" label="B" />
      </RadioGroup>
    );
    expect(screen.getAllByRole("radio")).toHaveLength(2);
  });

  it("selects value via controlled prop", () => {
    render(
      <RadioGroup value="b">
        <RadioItem value="a" label="A" />
        <RadioItem value="b" label="B" />
      </RadioGroup>
    );
    const radios = screen.getAllByRole("radio");
    expect(radios[1]).toBeChecked();
    expect(radios[0]).not.toBeChecked();
  });

  it("calls onValueChange when item clicked", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <RadioGroup value="a" onValueChange={onValueChange}>
        <RadioItem value="a" label="A" />
        <RadioItem value="b" label="B" />
      </RadioGroup>
    );
    await user.click(screen.getByLabelText("B"));
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("disables all items when group is disabled", () => {
    render(
      <RadioGroup disabled>
        <RadioItem value="a" label="A" />
        <RadioItem value="b" label="B" />
      </RadioGroup>
    );
    screen.getAllByRole("radio").forEach((radio) => {
      expect(radio).toBeDisabled();
    });
  });

  it("disables individual item", () => {
    render(
      <RadioGroup>
        <RadioItem value="a" label="A" />
        <RadioItem value="b" label="B" disabled />
      </RadioGroup>
    );
    const radios = screen.getAllByRole("radio");
    expect(radios[0]).not.toBeDisabled();
    expect(radios[1]).toBeDisabled();
  });

  it("renders horizontal orientation", () => {
    render(
      <RadioGroup orientation="horizontal">
        <RadioItem value="a" label="A" />
      </RadioGroup>
    );
    expect(screen.getByRole("radiogroup")).toHaveAttribute("aria-orientation", "horizontal");
  });

  it("renders vertical orientation by default", () => {
    render(
      <RadioGroup>
        <RadioItem value="a" label="A" />
      </RadioGroup>
    );
    expect(screen.getByRole("radiogroup")).toHaveAttribute("aria-orientation", "vertical");
  });

  it("renders description on RadioItem", () => {
    render(
      <RadioGroup>
        <RadioItem value="a" label="A" description="First option" />
      </RadioGroup>
    );
    expect(screen.getByText("First option")).toBeInTheDocument();
  });

  it("forwards ref on RadioGroup", () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <RadioGroup ref={ref}>
        <RadioItem value="a" label="A" />
      </RadioGroup>
    );
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("forwards ref on RadioItem", () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <RadioGroup>
        <RadioItem ref={ref} value="a" label="A" />
      </RadioGroup>
    );
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("does not call onValueChange when disabled item clicked", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <RadioGroup onValueChange={onValueChange}>
        <RadioItem value="a" label="A" disabled />
      </RadioGroup>
    );
    await user.click(screen.getByRole("radio"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("has correct displayName on RadioGroup", () => {
    expect(RadioGroup.displayName).toBe("RadioGroup");
  });

  it("has correct displayName on RadioItem", () => {
    expect(RadioItem.displayName).toBe("RadioItem");
  });
});
