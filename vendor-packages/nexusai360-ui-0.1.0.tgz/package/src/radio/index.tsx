import * as React from "react";
import { cn } from "../lib/cn";

// ---------- Context ----------
interface RadioGroupContextValue {
  name: string;
  value?: string;
  disabled?: boolean;
  onValueChange?: (value: string) => void;
}

const RadioGroupContext = React.createContext<RadioGroupContextValue | null>(null);

function useRadioGroupContext() {
  const ctx = React.useContext(RadioGroupContext);
  if (!ctx) throw new Error("RadioItem must be used within a RadioGroup");
  return ctx;
}

// ---------- RadioGroup ----------
export interface RadioGroupProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  /** Currently selected value */
  value?: string;
  /** Callback when value changes */
  onValueChange?: (value: string) => void;
  /** Layout orientation */
  orientation?: "vertical" | "horizontal";
  /** Disable all items */
  disabled?: boolean;
  /** Name attribute for all radio inputs */
  name?: string;
}

const RadioGroup = React.forwardRef<HTMLDivElement, RadioGroupProps>(
  (
    {
      className,
      value,
      onValueChange,
      orientation = "vertical",
      disabled = false,
      name: providedName,
      children,
      ...props
    },
    ref
  ) => {
    const autoId = React.useId();
    const name = providedName ?? autoId;

    return (
      <RadioGroupContext.Provider value={{ name, value, disabled, onValueChange }}>
        <div
          ref={ref}
          role="radiogroup"
          aria-orientation={orientation}
          className={cn(
            "flex",
            orientation === "vertical" ? "flex-col gap-3" : "flex-row gap-4",
            className
          )}
          {...props}
        >
          {children}
        </div>
      </RadioGroupContext.Provider>
    );
  }
);

RadioGroup.displayName = "RadioGroup";

// ---------- RadioItem ----------
export interface RadioItemProps extends Omit<React.HTMLAttributes<HTMLDivElement>, "onChange"> {
  /** Value of this radio option */
  value: string;
  /** Label text */
  label?: string;
  /** Description below label */
  description?: string;
  /** Disable this item */
  disabled?: boolean;
}

const RadioItem = React.forwardRef<HTMLDivElement, RadioItemProps>(
  ({ className, value, label, description, disabled: itemDisabled, ...props }, ref) => {
    const group = useRadioGroupContext();
    const isDisabled = group.disabled || itemDisabled;
    const isChecked = group.value === value;
    const autoId = React.useId();
    const inputId = `${autoId}-radio`;
    const descriptionId = description ? `${autoId}-desc` : undefined;

    const handleChange = React.useCallback(() => {
      if (!isDisabled) {
        group.onValueChange?.(value);
      }
    }, [isDisabled, group, value]);

    return (
      <div ref={ref} className={cn("flex items-start gap-3", className)} {...props}>
        <div className="relative flex items-center justify-center">
          <input
            id={inputId}
            type="radio"
            name={group.name}
            value={value}
            checked={isChecked}
            disabled={isDisabled}
            onChange={handleChange}
            className="peer sr-only"
            aria-describedby={descriptionId}
          />
          <div
            className={cn(
              "flex size-5 items-center justify-center rounded-full border-2 transition-colors",
              "peer-focus-visible:ring-2 peer-focus-visible:ring-violet-500/50 peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-zinc-950",
              isChecked
                ? "border-violet-600"
                : "border-zinc-600",
              isDisabled && "opacity-50 cursor-not-allowed"
            )}
            aria-hidden="true"
          >
            {isChecked && (
              <div className="size-2.5 rounded-full bg-violet-600" />
            )}
          </div>
        </div>
        {(label || description) && (
          <div className="flex flex-col gap-0.5">
            {label && (
              <label
                htmlFor={inputId}
                className={cn(
                  "text-sm font-medium text-zinc-200 select-none cursor-pointer",
                  isDisabled && "opacity-50 cursor-not-allowed"
                )}
              >
                {label}
              </label>
            )}
            {description && (
              <p
                id={descriptionId}
                className={cn("text-xs text-zinc-500", isDisabled && "opacity-50")}
              >
                {description}
              </p>
            )}
          </div>
        )}
      </div>
    );
  }
);

RadioItem.displayName = "RadioItem";

export { RadioGroup, RadioItem };
