import * as React from "react";
import { cn } from "../lib/cn";

// --- Icons ---
const ChevronDown: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M4 6L8 10L12 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const SearchIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <circle cx="7" cy="7" r="4.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M10.5 10.5L14 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

// --- Types ---
export interface ComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ComboboxProps {
  /** List of options */
  options: ComboboxOption[];
  /** Selected value(s) — string for single, string[] for multiple */
  value?: string | string[];
  /** Callback on change */
  onValueChange?: (value: string | string[]) => void;
  /** Trigger placeholder */
  placeholder?: string;
  /** Search input placeholder */
  searchPlaceholder?: string;
  /** Message when no results */
  emptyMessage?: string;
  /** Enable multi-select */
  multiple?: boolean;
  /** Disable the combobox */
  disabled?: boolean;
  /** Additional class names */
  className?: string;
  /** Accessible name */
  "aria-label"?: string;
}

const Combobox = React.forwardRef<HTMLButtonElement, ComboboxProps>(
  (
    {
      options,
      value,
      onValueChange,
      placeholder = "Select...",
      searchPlaceholder = "Search...",
      emptyMessage = "No results found.",
      multiple = false,
      disabled = false,
      className,
      "aria-label": ariaLabel,
    },
    ref
  ) => {
    const [open, setOpen] = React.useState(false);
    const [search, setSearch] = React.useState("");
    const triggerRef = React.useRef<HTMLButtonElement | null>(null);
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    const listRef = React.useRef<HTMLDivElement | null>(null);
    const listboxId = React.useId();

    const setTriggerRefs = React.useCallback(
      (node: HTMLButtonElement | null) => {
        triggerRef.current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) (ref as React.MutableRefObject<HTMLButtonElement | null>).current = node;
      },
      [ref]
    );

    // Normalize value to array for processing
    const selectedValues: string[] = React.useMemo(() => {
      if (!value) return [];
      return Array.isArray(value) ? value : [value];
    }, [value]);

    const filteredOptions = React.useMemo(() => {
      if (!search) return options;
      const lower = search.toLowerCase();
      return options.filter((o) => o.label.toLowerCase().includes(lower));
    }, [options, search]);

    const displayText = React.useMemo(() => {
      if (selectedValues.length === 0) return null;
      if (!multiple) {
        return options.find((o) => o.value === selectedValues[0])?.label;
      }
      const labels = selectedValues
        .map((v) => options.find((o) => o.value === v)?.label)
        .filter(Boolean);
      return labels.join(", ");
    }, [selectedValues, options, multiple]);

    const handleOpen = React.useCallback(() => {
      if (disabled) return;
      setOpen(true);
      setSearch("");
      // Focus search input after render
      requestAnimationFrame(() => inputRef.current?.focus());
    }, [disabled]);

    const handleClose = React.useCallback(() => {
      setOpen(false);
      setSearch("");
      triggerRef.current?.focus();
    }, []);

    const handleSelect = React.useCallback(
      (option: ComboboxOption) => {
        if (option.disabled) return;
        if (multiple) {
          const current = selectedValues;
          const next = current.includes(option.value)
            ? current.filter((v) => v !== option.value)
            : [...current, option.value];
          onValueChange?.(next);
        } else {
          onValueChange?.(option.value);
          handleClose();
        }
      },
      [multiple, selectedValues, onValueChange, handleClose]
    );

    const isSelected = React.useCallback(
      (val: string) => selectedValues.includes(val),
      [selectedValues]
    );

    // Close on outside click
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: MouseEvent) => {
        if (
          !triggerRef.current?.contains(e.target as Node) &&
          !listRef.current?.contains(e.target as Node)
        ) {
          handleClose();
        }
      };
      document.addEventListener("mousedown", handler);
      return () => document.removeEventListener("mousedown", handler);
    }, [open, handleClose]);

    // Close on Escape
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: KeyboardEvent) => {
        if (e.key === "Escape") handleClose();
      };
      document.addEventListener("keydown", handler);
      return () => document.removeEventListener("keydown", handler);
    }, [open, handleClose]);

    return (
      <div className={cn("relative w-full", className)}>
        <button
          ref={setTriggerRefs}
          type="button"
          role="combobox"
          aria-expanded={open}
          aria-haspopup="listbox"
          aria-controls={open ? listboxId : undefined}
          aria-label={ariaLabel}
          disabled={disabled}
          className={cn(
            "inline-flex items-center justify-between gap-2 w-full",
            "rounded-lg border transition-colors duration-150",
            "bg-zinc-900 border-zinc-700 text-zinc-100",
            "h-10 px-3 text-base outline-none",
            "focus-visible:ring-2 focus-visible:ring-violet-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
            "disabled:pointer-events-none disabled:opacity-50"
          )}
          onClick={() => (open ? handleClose() : handleOpen())}
        >
          <span className={cn("truncate", !displayText && "text-zinc-500")}>
            {displayText || placeholder}
          </span>
          <ChevronDown
            className={cn(
              "size-4 text-zinc-400 shrink-0 transition-transform",
              open && "rotate-180"
            )}
          />
        </button>

        {open && (
          <div
            ref={listRef}
            className={cn(
              "absolute z-50 mt-1 w-full overflow-hidden rounded-lg border",
              "bg-zinc-900 border-zinc-700 shadow-lg shadow-black/40"
            )}
          >
            <div className="flex items-center gap-2 border-b border-zinc-700 px-3">
              <SearchIcon className="size-4 text-zinc-400 shrink-0" />
              <input
                ref={inputRef}
                type="text"
                role="searchbox"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={searchPlaceholder}
                className={cn(
                  "flex-1 h-9 bg-transparent text-sm text-zinc-100 placeholder:text-zinc-500",
                  "outline-none border-none"
                )}
                autoComplete="off"
                autoCorrect="off"
                spellCheck={false}
              />
            </div>
            <div
              id={listboxId}
              role="listbox"
              aria-multiselectable={multiple || undefined}
              aria-label={ariaLabel}
              className="overflow-y-auto max-h-60 p-1"
            >
              {filteredOptions.length === 0 ? (
                <div role="status" className="py-6 text-center text-sm text-zinc-500">
                  {emptyMessage}
                </div>
              ) : (
                filteredOptions.map((option) => (
                  <div
                    key={option.value}
                    role="option"
                    aria-selected={isSelected(option.value)}
                    aria-disabled={option.disabled || undefined}
                    className={cn(
                      "flex items-center gap-2 rounded-md px-2 h-8 text-sm cursor-pointer select-none",
                      "text-zinc-100",
                      "hover:bg-zinc-800",
                      isSelected(option.value) && "text-violet-400",
                      option.disabled && "opacity-50 cursor-not-allowed"
                    )}
                    onClick={() => handleSelect(option)}
                  >
                    {multiple && (
                      <div
                        className={cn(
                          "flex size-4 items-center justify-center rounded border",
                          isSelected(option.value)
                            ? "border-violet-600 bg-violet-600 text-white"
                            : "border-zinc-600"
                        )}
                        aria-hidden="true"
                      >
                        {isSelected(option.value) && <CheckIcon className="size-2.5" />}
                      </div>
                    )}
                    <span className="flex-1 truncate">{option.label}</span>
                    {!multiple && isSelected(option.value) && (
                      <CheckIcon className="size-3 text-violet-400 shrink-0" />
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    );
  }
);

Combobox.displayName = "Combobox";

export { Combobox };
