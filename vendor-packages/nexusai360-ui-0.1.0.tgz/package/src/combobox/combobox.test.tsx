import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Combobox } from "./index";

const options = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry" },
  { value: "date", label: "Date" },
];

const optionsWithDisabled = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
];

describe("Combobox", () => {
  it("renders a combobox trigger", () => {
    render(<Combobox options={options} aria-label="Fruit" />);
    expect(screen.getByRole("combobox")).toBeInTheDocument();
  });

  it("shows placeholder when no value", () => {
    render(<Combobox options={options} placeholder="Pick fruit" aria-label="Fruit" />);
    expect(screen.getByText("Pick fruit")).toBeInTheDocument();
  });

  it("shows selected value label", () => {
    render(<Combobox options={options} value="banana" aria-label="Fruit" />);
    expect(screen.getByText("Banana")).toBeInTheDocument();
  });

  it("opens dropdown on click", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    expect(screen.getAllByRole("option")).toHaveLength(4);
  });

  it("shows search input when open", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("searchbox")).toBeInTheDocument();
  });

  it("filters options by search", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.type(screen.getByRole("searchbox"), "che");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(screen.getByText("Cherry")).toBeInTheDocument();
  });

  it("shows empty message when no match", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} emptyMessage="Nothing found" aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.type(screen.getByRole("searchbox"), "zzz");
    expect(screen.getByText("Nothing found")).toBeInTheDocument();
  });

  it("shows default empty message", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.type(screen.getByRole("searchbox"), "zzz");
    expect(screen.getByText("No results found.")).toBeInTheDocument();
  });

  it("selects an option (single mode)", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Combobox options={options} onValueChange={onValueChange} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Cherry"));
    expect(onValueChange).toHaveBeenCalledWith("cherry");
  });

  it("closes after single select", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} onValueChange={vi.fn()} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Apple"));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("supports multiple selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Combobox options={options} multiple value={["apple"]} onValueChange={onValueChange} aria-label="Fruit" />
    );
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Cherry"));
    expect(onValueChange).toHaveBeenCalledWith(["apple", "cherry"]);
  });

  it("deselects in multiple mode", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <Combobox options={options} multiple value={["apple", "banana"]} onValueChange={onValueChange} aria-label="Fruit" />
    );
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Apple"));
    expect(onValueChange).toHaveBeenCalledWith(["banana"]);
  });

  it("stays open after selecting in multiple mode", async () => {
    const user = userEvent.setup();
    render(
      <Combobox options={options} multiple value={[]} onValueChange={vi.fn()} aria-label="Fruit" />
    );
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Cherry"));
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("shows comma-separated labels for multiple", () => {
    render(
      <Combobox options={options} multiple value={["apple", "cherry"]} aria-label="Fruit" />
    );
    expect(screen.getByText("Apple, Cherry")).toBeInTheDocument();
  });

  it("disables the trigger", () => {
    render(<Combobox options={options} disabled aria-label="Fruit" />);
    expect(screen.getByRole("combobox")).toBeDisabled();
  });

  it("does not open when disabled", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} disabled aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("does not select disabled option", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Combobox options={optionsWithDisabled} onValueChange={onValueChange} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Banana"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("has aria-expanded false when closed", () => {
    render(<Combobox options={options} aria-label="Fruit" />);
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "false");
  });

  it("has aria-expanded true when open", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "true");
  });

  it("marks selected option with aria-selected", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} value="banana" aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    const opts = screen.getAllByRole("option");
    const selected = opts.find((o) => o.getAttribute("aria-selected") === "true");
    expect(selected).toHaveTextContent("Banana");
  });

  it("has aria-multiselectable in multiple mode", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} multiple value={[]} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("listbox")).toHaveAttribute("aria-multiselectable", "true");
  });

  it("closes on Escape", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLButtonElement>();
    render(<Combobox ref={ref} options={options} aria-label="Fruit" />);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it("has correct displayName", () => {
    expect(Combobox.displayName).toBe("Combobox");
  });

  it("custom search placeholder", async () => {
    const user = userEvent.setup();
    render(<Combobox options={options} searchPlaceholder="Type here..." aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByPlaceholderText("Type here...")).toBeInTheDocument();
  });
});
