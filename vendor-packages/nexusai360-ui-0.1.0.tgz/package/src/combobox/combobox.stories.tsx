import { useState } from "react";
import { Combobox } from "./index";

export default { title: "Primitives/Combobox" };

const options = [
  { value: "react", label: "React" },
  { value: "vue", label: "Vue" },
  { value: "angular", label: "Angular" },
  { value: "svelte", label: "Svelte" },
  { value: "solid", label: "SolidJS", disabled: true },
];

export const Default = () => {
  const [v, setV] = useState<string | string[]>("");
  return <Combobox options={options} value={v} onValueChange={setV} />;
};

export const Multiple = () => {
  const [v, setV] = useState<string[]>([]);
  return <Combobox options={options} value={v} onValueChange={(val) => setV(val as string[])} multiple />;
};

export const Disabled = () => <Combobox options={options} disabled placeholder="Disabled" />;
