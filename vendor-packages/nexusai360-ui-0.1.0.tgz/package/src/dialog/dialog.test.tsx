import { describe, it, expect, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "./index";

/* Helper: renders a full dialog and opens it */
function renderDialog(props: { onOpenChange?: (open: boolean) => void } = {}) {
  return render(
    <Dialog {...props}>
      <DialogTrigger>Open</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Title</DialogTitle>
          <DialogDescription>Description</DialogDescription>
        </DialogHeader>
        <p>Body</p>
        <DialogFooter>
          <DialogClose>Close</DialogClose>
        </DialogFooter>
      </DialogContent>
    </Dialog>,
  );
}

describe("Dialog", () => {
  it("renders trigger button", () => {
    renderDialog();
    expect(screen.getByText("Open")).toBeInTheDocument();
  });

  it("opens on trigger click", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Title")).toBeInTheDocument();
    expect(screen.getByText("Description")).toBeInTheDocument();
    expect(screen.getByText("Body")).toBeInTheDocument();
  });

  it("closes on close button click", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Title")).toBeInTheDocument();
    await user.click(screen.getByText("Close"));
    await waitFor(() =>
      expect(screen.queryByText("Title")).not.toBeInTheDocument(),
    );
  });

  it("closes on Escape key", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Title")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    await waitFor(() =>
      expect(screen.queryByText("Title")).not.toBeInTheDocument(),
    );
  });

  it("calls onOpenChange when opened/closed", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    renderDialog({ onOpenChange });
    await user.click(screen.getByText("Open"));
    expect(onOpenChange).toHaveBeenCalledWith(true);
  });

  it("renders title with correct a11y role", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    const dialog = screen.getByRole("dialog");
    expect(dialog).toBeInTheDocument();
  });

  it("renders description text", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Description")).toBeInTheDocument();
  });

  it("focuses content on open (focus trap)", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    const dialog = screen.getByRole("dialog");
    expect(dialog).toBeInTheDocument();
    // Radix traps focus inside the dialog
    expect(document.activeElement).not.toBe(document.body);
  });

  it("DialogHeader has displayName", () => {
    expect(DialogHeader.displayName).toBe("DialogHeader");
  });

  it("DialogFooter has displayName", () => {
    expect(DialogFooter.displayName).toBe("DialogFooter");
  });

  it("DialogTitle has displayName", () => {
    expect(DialogTitle.displayName).toBe("DialogTitle");
  });

  it("DialogDescription has displayName", () => {
    expect(DialogDescription.displayName).toBe("DialogDescription");
  });

  it("DialogContent has displayName", () => {
    expect(DialogContent.displayName).toBe("DialogContent");
  });

  it("merges custom className on content", async () => {
    const user = userEvent.setup();
    render(
      <Dialog>
        <DialogTrigger>Open</DialogTrigger>
        <DialogContent className="my-custom">Content</DialogContent>
      </Dialog>,
    );
    await user.click(screen.getByText("Open"));
    const dialog = screen.getByRole("dialog");
    expect(dialog.className).toContain("my-custom");
  });

  it("renders footer content", async () => {
    const user = userEvent.setup();
    renderDialog();
    await user.click(screen.getByText("Open"));
    expect(screen.getByText("Close")).toBeInTheDocument();
  });
});
