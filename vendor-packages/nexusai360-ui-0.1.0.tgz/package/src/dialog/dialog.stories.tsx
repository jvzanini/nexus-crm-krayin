import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "./index";

export default { title: "Overlays/Dialog" };

export const Default = () => (
  <Dialog>
    <DialogTrigger asChild>
      <button className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm">Open Dialog</button>
    </DialogTrigger>
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Edit Profile</DialogTitle>
        <DialogDescription>Make changes to your profile here.</DialogDescription>
      </DialogHeader>
      <div className="py-4 text-zinc-300 text-sm">Dialog body content goes here.</div>
      <DialogFooter>
        <DialogClose asChild>
          <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Cancel</button>
        </DialogClose>
        <button className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm">Save</button>
      </DialogFooter>
    </DialogContent>
  </Dialog>
);
