import { useState } from "react";
import { Select } from "./index";

export default { title: "Primitives/Select" };

const options = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry" },
  { value: "dragonfruit", label: "Dragonfruit", disabled: true },
];

export const Default = () => {
  const [v, setV] = useState("");
  return <Select options={options} value={v} onValueChange={setV} />;
};

export const Small = () => <Select options={options} size="sm" placeholder="Small" />;
export const Large = () => <Select options={options} size="lg" placeholder="Large" />;
export const WithError = () => <Select options={options} error placeholder="With error" />;
export const Disabled = () => <Select options={options} disabled placeholder="Disabled" />;
