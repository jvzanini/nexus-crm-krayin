import { describe, it, expect, vi } from "vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Select } from "./index";

const options = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana" },
  { value: "cherry", label: "Cherry" },
];

const optionsWithDisabled = [
  { value: "apple", label: "Apple" },
  { value: "banana", label: "Banana", disabled: true },
  { value: "cherry", label: "Cherry" },
];

describe("Select", () => {
  it("renders a combobox trigger", () => {
    render(<Select options={options} aria-label="Fruit" />);
    expect(screen.getByRole("combobox")).toBeInTheDocument();
  });

  it("shows placeholder when no value", () => {
    render(<Select options={options} placeholder="Pick a fruit" aria-label="Fruit" />);
    expect(screen.getByText("Pick a fruit")).toBeInTheDocument();
  });

  it("shows default placeholder", () => {
    render(<Select options={options} aria-label="Fruit" />);
    expect(screen.getByText("Select an option")).toBeInTheDocument();
  });

  it("shows selected value label", () => {
    render(<Select options={options} value="banana" aria-label="Fruit" />);
    expect(screen.getByText("Banana")).toBeInTheDocument();
  });

  it("opens dropdown on click", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    expect(screen.getAllByRole("option")).toHaveLength(3);
  });

  it("closes dropdown on second click", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    const trigger = screen.getByRole("combobox");
    await user.click(trigger);
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    await user.click(trigger);
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("selects an option on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Select options={options} onValueChange={onValueChange} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Cherry"));
    expect(onValueChange).toHaveBeenCalledWith("cherry");
  });

  it("closes after selection", async () => {
    const user = userEvent.setup();
    render(<Select options={options} onValueChange={vi.fn()} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Apple"));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("marks selected option with aria-selected", async () => {
    const user = userEvent.setup();
    render(<Select options={options} value="banana" aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    const listbox = screen.getByRole("listbox");
    const selected = within(listbox).getAllByRole("option").find(
      (o) => o.getAttribute("aria-selected") === "true"
    );
    expect(selected).toHaveTextContent("Banana");
  });

  it("disables the trigger", () => {
    render(<Select options={options} disabled aria-label="Fruit" />);
    expect(screen.getByRole("combobox")).toBeDisabled();
  });

  it("does not open when disabled", async () => {
    const user = userEvent.setup();
    render(<Select options={options} disabled aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("shows error styling", () => {
    render(<Select options={options} error aria-label="Fruit" />);
    expect(screen.getByRole("combobox").className).toContain("border-red");
  });

  it("does not select disabled option", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<Select options={optionsWithDisabled} onValueChange={onValueChange} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Banana"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("has aria-expanded false when closed", () => {
    render(<Select options={options} aria-label="Fruit" />);
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "false");
  });

  it("has aria-expanded true when open", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "true");
  });

  it("opens on Enter key", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    screen.getByRole("combobox").focus();
    await user.keyboard("{Enter}");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("opens on Space key", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    screen.getByRole("combobox").focus();
    await user.keyboard(" ");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("opens on ArrowDown key", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    screen.getByRole("combobox").focus();
    await user.keyboard("{ArrowDown}");
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });

  it("closes on Escape key", async () => {
    const user = userEvent.setup();
    render(<Select options={options} aria-label="Fruit" />);
    await user.click(screen.getByRole("combobox"));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLButtonElement>();
    render(<Select ref={ref} options={options} aria-label="Fruit" />);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it("has correct displayName", () => {
    expect(Select.displayName).toBe("Select");
  });

  it("applies size sm variant", () => {
    render(<Select options={options} size="sm" aria-label="Fruit" />);
    expect(screen.getByRole("combobox").className).toContain("h-8");
  });

  it("applies size lg variant", () => {
    render(<Select options={options} size="lg" aria-label="Fruit" />);
    expect(screen.getByRole("combobox").className).toContain("h-12");
  });
});
