import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

// --- Chevron icon ---
const ChevronDown: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path
      d="M4 6L8 10L12 6"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path
      d="M2.5 6L5 8.5L9.5 3.5"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

// --- Variants ---
const selectTriggerVariants = cva(
  [
    "inline-flex items-center justify-between gap-2 w-full",
    "rounded-lg border transition-colors duration-150",
    "bg-zinc-900 border-zinc-700 text-zinc-100",
    "outline-none",
    "focus-visible:ring-2 focus-visible:ring-violet-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
    "disabled:pointer-events-none disabled:opacity-50",
  ].join(" "),
  {
    variants: {
      size: {
        sm: "h-8 px-3 text-sm",
        md: "h-10 px-3 text-base",
        lg: "h-12 px-4 text-lg",
      },
    },
    defaultVariants: {
      size: "md",
    },
  }
);

// --- Types ---
export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface SelectProps extends VariantProps<typeof selectTriggerVariants> {
  /** List of options */
  options: SelectOption[];
  /** Currently selected value */
  value?: string;
  /** Callback on value change */
  onValueChange?: (value: string) => void;
  /** Placeholder text when nothing selected */
  placeholder?: string;
  /** Show error styling */
  error?: boolean;
  /** Disable the select */
  disabled?: boolean;
  /** Additional class names */
  className?: string;
  /** Accessible name */
  "aria-label"?: string;
}

const Select = React.forwardRef<HTMLButtonElement, SelectProps>(
  (
    {
      options,
      value,
      onValueChange,
      placeholder = "Select an option",
      size,
      error = false,
      disabled = false,
      className,
      "aria-label": ariaLabel,
      ...props
    },
    ref
  ) => {
    const [open, setOpen] = React.useState(false);
    const [highlightIndex, setHighlightIndex] = React.useState(-1);
    const triggerRef = React.useRef<HTMLButtonElement | null>(null);
    const listRef = React.useRef<HTMLUListElement | null>(null);
    const listboxId = React.useId();

    const setRefs = React.useCallback(
      (node: HTMLButtonElement | null) => {
        triggerRef.current = node;
        if (typeof ref === "function") {
          ref(node);
        } else if (ref) {
          (ref as React.MutableRefObject<HTMLButtonElement | null>).current = node;
        }
      },
      [ref]
    );

    const selectedOption = options.find((o) => o.value === value);
    const enabledOptions = options.filter((o) => !o.disabled);

    const handleOpen = React.useCallback(() => {
      if (disabled) return;
      setOpen(true);
      const idx = enabledOptions.findIndex((o) => o.value === value);
      setHighlightIndex(idx >= 0 ? options.indexOf(enabledOptions[idx]) : 0);
    }, [disabled, enabledOptions, value, options]);

    const handleClose = React.useCallback(() => {
      setOpen(false);
      setHighlightIndex(-1);
      triggerRef.current?.focus();
    }, []);

    const handleSelect = React.useCallback(
      (option: SelectOption) => {
        if (option.disabled) return;
        onValueChange?.(option.value);
        handleClose();
      },
      [onValueChange, handleClose]
    );

    // Close on outside click
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: MouseEvent) => {
        if (
          !triggerRef.current?.contains(e.target as Node) &&
          !listRef.current?.contains(e.target as Node)
        ) {
          handleClose();
        }
      };
      document.addEventListener("mousedown", handler);
      return () => document.removeEventListener("mousedown", handler);
    }, [open, handleClose]);

    // Close on Escape
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          handleClose();
        }
      };
      document.addEventListener("keydown", handler);
      return () => document.removeEventListener("keydown", handler);
    }, [open, handleClose]);

    const handleTriggerKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown" || e.key === "ArrowUp") {
          e.preventDefault();
          if (!open) {
            handleOpen();
          }
        }
      },
      [open, handleOpen]
    );

    const handleListKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        switch (e.key) {
          case "ArrowDown": {
            e.preventDefault();
            setHighlightIndex((prev) => {
              let next = prev + 1;
              while (next < options.length && options[next].disabled) next++;
              return next < options.length ? next : prev;
            });
            break;
          }
          case "ArrowUp": {
            e.preventDefault();
            setHighlightIndex((prev) => {
              let next = prev - 1;
              while (next >= 0 && options[next].disabled) next--;
              return next >= 0 ? next : prev;
            });
            break;
          }
          case "Enter":
          case " ": {
            e.preventDefault();
            if (highlightIndex >= 0 && highlightIndex < options.length) {
              handleSelect(options[highlightIndex]);
            }
            break;
          }
          case "Escape": {
            e.preventDefault();
            handleClose();
            break;
          }
          case "Home": {
            e.preventDefault();
            const first = options.findIndex((o) => !o.disabled);
            if (first >= 0) setHighlightIndex(first);
            break;
          }
          case "End": {
            e.preventDefault();
            let last = options.length - 1;
            while (last >= 0 && options[last].disabled) last--;
            if (last >= 0) setHighlightIndex(last);
            break;
          }
        }
      },
      [options, highlightIndex, handleSelect, handleClose]
    );

    // Scroll highlighted item into view
    React.useEffect(() => {
      if (!open || highlightIndex < 0) return;
      const list = listRef.current;
      if (!list) return;
      const item = list.children[highlightIndex] as HTMLElement | undefined;
      item?.scrollIntoView({ block: "nearest" });
    }, [open, highlightIndex]);

    return (
      <div className="relative w-full" {...props}>
        <button
          ref={setRefs}
          type="button"
          role="combobox"
          aria-expanded={open}
          aria-haspopup="listbox"
          aria-controls={open ? listboxId : undefined}
          aria-label={ariaLabel}
          disabled={disabled}
          className={cn(
            selectTriggerVariants({ size }),
            error && "border-red-500 focus-visible:ring-red-500/50",
            className
          )}
          onClick={() => (open ? handleClose() : handleOpen())}
          onKeyDown={handleTriggerKeyDown}
        >
          <span
            className={cn(
              "min-w-0 flex-1 truncate text-left",
              !selectedOption && "text-zinc-500"
            )}
          >
            {selectedOption ? selectedOption.label : placeholder}
          </span>
          <ChevronDown
            className={cn(
              "w-4 h-4 text-zinc-400 shrink-0 transition-transform",
              open && "rotate-180"
            )}
          />
        </button>

        {open && (
          <ul
            ref={listRef}
            id={listboxId}
            role="listbox"
            aria-label={ariaLabel}
            className={cn(
              "absolute z-50 mt-1 w-full overflow-auto rounded-lg border",
              "bg-zinc-900 border-zinc-700 shadow-lg shadow-black/40",
              "max-h-60 p-1"
            )}
            tabIndex={-1}
            onKeyDown={handleListKeyDown}
          >
            {options.map((option, index) => (
              <li
                key={option.value}
                role="option"
                aria-selected={option.value === value}
                aria-disabled={option.disabled || undefined}
                data-highlighted={index === highlightIndex || undefined}
                className={cn(
                  "flex items-center gap-2 rounded-md px-2 h-8 text-sm cursor-pointer select-none",
                  "text-zinc-100",
                  index === highlightIndex && "bg-zinc-800",
                  option.value === value && "text-violet-400",
                  option.disabled && "opacity-50 cursor-not-allowed"
                )}
                onClick={() => handleSelect(option)}
                onMouseEnter={() => !option.disabled && setHighlightIndex(index)}
              >
                <span className="flex-1 truncate">{option.label}</span>
                {option.value === value && (
                  <CheckIcon className="size-3 text-violet-400 shrink-0" />
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  }
);

Select.displayName = "Select";

export { Select, selectTriggerVariants };
