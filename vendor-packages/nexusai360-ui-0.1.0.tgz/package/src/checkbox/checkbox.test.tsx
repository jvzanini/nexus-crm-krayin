import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Checkbox } from "./index";

describe("Checkbox", () => {
  it("renders a checkbox", () => {
    render(<Checkbox />);
    expect(screen.getByRole("checkbox")).toBeInTheDocument();
  });

  it("renders with label", () => {
    render(<Checkbox label="Accept terms" />);
    expect(screen.getByText("Accept terms")).toBeInTheDocument();
  });

  it("renders with description", () => {
    render(<Checkbox label="Terms" description="Read carefully" />);
    expect(screen.getByText("Read carefully")).toBeInTheDocument();
  });

  it("checks when clicked", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Checkbox checked={false} onCheckedChange={onCheckedChange} label="Check" />);
    await user.click(screen.getByLabelText("Check"));
    expect(onCheckedChange).toHaveBeenCalledWith(true);
  });

  it("unchecks when clicked while checked", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Checkbox checked={true} onCheckedChange={onCheckedChange} label="Check" />);
    await user.click(screen.getByLabelText("Check"));
    expect(onCheckedChange).toHaveBeenCalledWith(false);
  });

  it("shows indeterminate state via aria-checked mixed", () => {
    render(<Checkbox indeterminate />);
    expect(screen.getByRole("checkbox")).toHaveAttribute("aria-checked", "mixed");
  });

  it("sets indeterminate property on DOM element", () => {
    const ref = createRef<HTMLInputElement>();
    render(<Checkbox ref={ref} indeterminate />);
    expect(ref.current?.indeterminate).toBe(true);
  });

  it("disables the checkbox", () => {
    render(<Checkbox disabled />);
    expect(screen.getByRole("checkbox")).toBeDisabled();
  });

  it("does not fire onCheckedChange when disabled", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Checkbox disabled onCheckedChange={onCheckedChange} label="No" />);
    await user.click(screen.getByRole("checkbox"));
    expect(onCheckedChange).not.toHaveBeenCalled();
  });

  it("toggles when label is clicked", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(<Checkbox checked={false} onCheckedChange={onCheckedChange} label="Toggle me" />);
    await user.click(screen.getByText("Toggle me"));
    expect(onCheckedChange).toHaveBeenCalledWith(true);
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLInputElement>();
    render(<Checkbox ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLInputElement);
  });

  it("links description via aria-describedby", () => {
    render(<Checkbox id="cb1" description="Help text" />);
    const cb = screen.getByRole("checkbox");
    expect(cb).toHaveAttribute("aria-describedby", expect.stringContaining("description"));
  });

  it("has correct displayName", () => {
    expect(Checkbox.displayName).toBe("Checkbox");
  });
});
