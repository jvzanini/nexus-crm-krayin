import { useState } from "react";
import { Checkbox } from "./index";

export default { title: "Primitives/Checkbox" };

export const Default = () => {
  const [checked, setChecked] = useState(false);
  return <Checkbox checked={checked} onCheckedChange={setChecked} label="Accept terms" />;
};

export const WithDescription = () => (
  <Checkbox label="Newsletter" description="Receive weekly updates" />
);

export const Indeterminate = () => <Checkbox indeterminate label="Select all" />;
export const Disabled = () => <Checkbox disabled label="Disabled" />;
export const CheckedDisabled = () => <Checkbox checked disabled label="Checked + disabled" />;
