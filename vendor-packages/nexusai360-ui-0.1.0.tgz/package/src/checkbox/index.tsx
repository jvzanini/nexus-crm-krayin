import * as React from "react";
import { cn } from "../lib/cn";

export interface CheckboxProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "type" | "onChange"> {
  /** Controlled checked state */
  checked?: boolean;
  /** Callback when checked state changes */
  onCheckedChange?: (checked: boolean) => void;
  /** Indeterminate visual state */
  indeterminate?: boolean;
  /** Label text */
  label?: string;
  /** Description text below label */
  description?: string;
}

// --- Icons ---
const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const MinusIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path d="M2.5 6H9.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>(
  (
    {
      className,
      checked,
      onCheckedChange,
      indeterminate = false,
      disabled = false,
      label,
      description,
      id: providedId,
      "aria-describedby": ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    const autoId = React.useId();
    const id = providedId ?? autoId;
    const descriptionId = description ? `${id}-description` : undefined;
    const describedBy =
      [ariaDescribedBy, descriptionId].filter(Boolean).join(" ") || undefined;

    const internalRef = React.useRef<HTMLInputElement | null>(null);

    const setRefs = React.useCallback(
      (node: HTMLInputElement | null) => {
        internalRef.current = node;
        if (typeof ref === "function") {
          ref(node);
        } else if (ref) {
          (ref as React.MutableRefObject<HTMLInputElement | null>).current = node;
        }
      },
      [ref]
    );

    React.useEffect(() => {
      if (internalRef.current) {
        internalRef.current.indeterminate = indeterminate;
      }
    }, [indeterminate]);

    const handleChange = React.useCallback(
      (e: React.ChangeEvent<HTMLInputElement>) => {
        onCheckedChange?.(e.target.checked);
      },
      [onCheckedChange]
    );

    const isChecked = checked === true;

    return (
      <div className={cn("flex items-start gap-3", className)}>
        <div className="relative flex items-center justify-center">
          <input
            ref={setRefs}
            id={id}
            type="checkbox"
            role="checkbox"
            className="peer sr-only"
            checked={checked}
            disabled={disabled}
            onChange={handleChange}
            aria-checked={indeterminate ? "mixed" : checked}
            aria-describedby={describedBy}
            {...props}
          />
          <div
            className={cn(
              "flex size-5 items-center justify-center rounded-md border-2 transition-colors",
              "peer-focus-visible:ring-2 peer-focus-visible:ring-violet-500/50 peer-focus-visible:ring-offset-2 peer-focus-visible:ring-offset-zinc-950",
              isChecked || indeterminate
                ? "border-violet-600 bg-violet-600 text-white"
                : "border-zinc-600 bg-transparent",
              disabled && "opacity-50 cursor-not-allowed"
            )}
            aria-hidden="true"
          >
            {indeterminate ? (
              <MinusIcon className="size-3" />
            ) : isChecked ? (
              <CheckIcon className="size-3" />
            ) : null}
          </div>
        </div>
        {(label || description) && (
          <div className="flex flex-col gap-0.5">
            {label && (
              <label
                htmlFor={id}
                className={cn(
                  "text-sm font-medium text-zinc-200 select-none",
                  disabled && "opacity-50 cursor-not-allowed"
                )}
              >
                {label}
              </label>
            )}
            {description && (
              <p
                id={descriptionId}
                className={cn("text-xs text-zinc-500", disabled && "opacity-50")}
              >
                {description}
              </p>
            )}
          </div>
        )}
      </div>
    );
  }
);

Checkbox.displayName = "Checkbox";

export { Checkbox };
