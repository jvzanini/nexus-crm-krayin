import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  8 Canonical Colors (ADR-0018)                                      */
/* ------------------------------------------------------------------ */
const ICON_TILE_COLORS = [
  "violet",
  "emerald",
  "red",
  "amber",
  "blue",
  "cyan",
  "zinc",
  "purple",
] as const;

export type IconTileColor = (typeof ICON_TILE_COLORS)[number];

/* ------------------------------------------------------------------ */
/*  Variants                                                           */
/* ------------------------------------------------------------------ */
const iconTileVariants = cva(
  "inline-flex items-center justify-center rounded-xl shrink-0",
  {
    variants: {
      size: {
        sm: "size-8 [&_svg]:size-4",
        md: "size-10 [&_svg]:size-5",
        lg: "size-12 [&_svg]:size-6",
      },
    },
    defaultVariants: { size: "md" },
  },
);

/* ------------------------------------------------------------------ */
/*  Color map (bg + text via data-color)                               */
/* ------------------------------------------------------------------ */
const colorClasses: Record<IconTileColor, string> = {
  violet: "bg-violet-500/15 text-violet-400",
  emerald: "bg-emerald-500/15 text-emerald-400",
  red: "bg-red-500/15 text-red-400",
  amber: "bg-amber-500/15 text-amber-400",
  blue: "bg-blue-500/15 text-blue-400",
  cyan: "bg-cyan-500/15 text-cyan-400",
  zinc: "bg-zinc-500/15 text-zinc-400",
  purple: "bg-purple-500/15 text-purple-400",
};

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface IconTileProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof iconTileVariants> {
  /** Icon element or string emoji */
  icon: React.ReactNode;
  /** One of 8 canonical colors (ADR-0018) */
  color?: IconTileColor;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const IconTile = React.forwardRef<HTMLSpanElement, IconTileProps>(
  ({ className, size, icon, color = "violet", ...props }, ref) => (
    <span
      ref={ref}
      data-color={color}
      className={cn(iconTileVariants({ size }), colorClasses[color], className)}
      aria-hidden="true"
      {...props}
    >
      {icon}
    </span>
  ),
);

IconTile.displayName = "IconTile";

export { IconTile, iconTileVariants, ICON_TILE_COLORS };
