import { IconTile, ICON_TILE_COLORS } from "./index";

export default { title: "Navigation/IconTile" };

export const Default = () => <IconTile icon={<span>📊</span>} />;

export const AllColors = () => (
  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
    {ICON_TILE_COLORS.map((color) => (
      <IconTile key={color} icon={<span>★</span>} color={color} />
    ))}
  </div>
);

export const Sizes = () => (
  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
    <IconTile icon={<span>🔧</span>} size="sm" color="blue" />
    <IconTile icon={<span>🔧</span>} size="md" color="blue" />
    <IconTile icon={<span>🔧</span>} size="lg" color="blue" />
  </div>
);
