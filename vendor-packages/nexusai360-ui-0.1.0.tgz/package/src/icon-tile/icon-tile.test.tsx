import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { IconTile, ICON_TILE_COLORS } from "./index";

describe("IconTile", () => {
  // --- Render ---
  it("renders with an icon element", () => {
    render(<IconTile icon={<svg data-testid="svg" />} />);
    expect(screen.getByTestId("svg")).toBeInTheDocument();
  });

  it("renders with a string emoji", () => {
    render(<IconTile icon="🔥" />);
    expect(screen.getByText("🔥")).toBeInTheDocument();
  });

  it("is aria-hidden", () => {
    const { container } = render(<IconTile icon="X" />);
    expect(container.firstChild).toHaveAttribute("aria-hidden", "true");
  });

  // --- 8 Canonical Colors (ADR-0018) ---
  it.each([
    ["violet", "bg-violet-500/15"],
    ["emerald", "bg-emerald-500/15"],
    ["red", "bg-red-500/15"],
    ["amber", "bg-amber-500/15"],
    ["blue", "bg-blue-500/15"],
    ["cyan", "bg-cyan-500/15"],
    ["zinc", "bg-zinc-500/15"],
    ["purple", "bg-purple-500/15"],
  ] as const)("applies %s color", (color, expectedClass) => {
    const { container } = render(<IconTile icon="X" color={color} />);
    const el = container.firstChild as HTMLElement;
    expect(el.className).toContain(expectedClass);
    expect(el).toHaveAttribute("data-color", color);
  });

  it("has exactly 8 canonical colors", () => {
    expect(ICON_TILE_COLORS).toHaveLength(8);
  });

  it("defaults to violet color", () => {
    const { container } = render(<IconTile icon="X" />);
    expect((container.firstChild as HTMLElement)).toHaveAttribute("data-color", "violet");
  });

  // --- Sizes ---
  it("applies sm size", () => {
    const { container } = render(<IconTile icon="X" size="sm" />);
    expect((container.firstChild as HTMLElement).className).toContain("size-8");
  });

  it("applies md size (default)", () => {
    const { container } = render(<IconTile icon="X" />);
    expect((container.firstChild as HTMLElement).className).toContain("size-10");
  });

  it("applies lg size", () => {
    const { container } = render(<IconTile icon="X" size="lg" />);
    expect((container.firstChild as HTMLElement).className).toContain("size-12");
  });

  // --- Ref ---
  it("forwards ref", () => {
    const ref = createRef<HTMLSpanElement>();
    render(<IconTile ref={ref} icon="X" />);
    expect(ref.current).toBeInstanceOf(HTMLSpanElement);
  });

  // --- className ---
  it("merges custom className", () => {
    const { container } = render(<IconTile icon="X" className="extra" />);
    expect((container.firstChild as HTMLElement).className).toContain("extra");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(IconTile.displayName).toBe("IconTile");
  });
});
