import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
} from "./index";

describe("Breadcrumb", () => {
  const renderFull = () =>
    render(
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/products">Products</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage>Current</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>,
    );

  // --- Render ---
  it("renders nav with aria-label", () => {
    renderFull();
    expect(screen.getByLabelText("Breadcrumb")).toBeInTheDocument();
  });

  it("renders as semantic nav element", () => {
    renderFull();
    expect(screen.getByLabelText("Breadcrumb").tagName).toBe("NAV");
  });

  it("renders ordered list", () => {
    const { container } = renderFull();
    expect(container.querySelector("ol")).toBeInTheDocument();
  });

  // --- Links ---
  it("renders links with href", () => {
    renderFull();
    const link = screen.getByText("Home");
    expect(link.tagName).toBe("A");
    expect(link).toHaveAttribute("href", "/");
  });

  it("renders multiple links", () => {
    renderFull();
    expect(screen.getByText("Products")).toHaveAttribute("href", "/products");
  });

  // --- Current page ---
  it("marks current page with aria-current", () => {
    renderFull();
    expect(screen.getByText("Current")).toHaveAttribute("aria-current", "page");
  });

  it("current page is aria-disabled", () => {
    renderFull();
    expect(screen.getByText("Current")).toHaveAttribute("aria-disabled", "true");
  });

  // --- Separator ---
  it("renders default separator /", () => {
    renderFull();
    const seps = screen.getAllByText("/");
    expect(seps.length).toBeGreaterThanOrEqual(2);
  });

  it("separator is aria-hidden", () => {
    renderFull();
    const seps = screen.getAllByText("/");
    expect(seps[0]).toHaveAttribute("aria-hidden", "true");
  });

  it("renders custom separator", () => {
    render(
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/">Home</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>→</BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbPage>Page</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>,
    );
    expect(screen.getByText("→")).toBeInTheDocument();
  });

  // --- Refs ---
  it("forwards ref on Breadcrumb", () => {
    const ref = createRef<HTMLElement>();
    render(<Breadcrumb ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLElement);
  });

  it("forwards ref on BreadcrumbList", () => {
    const ref = createRef<HTMLOListElement>();
    render(<BreadcrumbList ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLOListElement);
  });

  // --- displayNames ---
  it("has correct displayNames", () => {
    expect(Breadcrumb.displayName).toBe("Breadcrumb");
    expect(BreadcrumbList.displayName).toBe("BreadcrumbList");
    expect(BreadcrumbItem.displayName).toBe("BreadcrumbItem");
    expect(BreadcrumbLink.displayName).toBe("BreadcrumbLink");
    expect(BreadcrumbSeparator.displayName).toBe("BreadcrumbSeparator");
    expect(BreadcrumbPage.displayName).toBe("BreadcrumbPage");
  });

  // --- className ---
  it("merges custom className on BreadcrumbLink", () => {
    render(<BreadcrumbLink href="/" className="custom">Link</BreadcrumbLink>);
    expect(screen.getByText("Link").className).toContain("custom");
  });
});
