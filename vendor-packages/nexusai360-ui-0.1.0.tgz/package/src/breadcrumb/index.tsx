import * as React from "react";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  Breadcrumb (nav wrapper)                                           */
/* ------------------------------------------------------------------ */
export interface BreadcrumbProps extends React.ComponentPropsWithoutRef<"nav"> {}

const Breadcrumb = React.forwardRef<HTMLElement, BreadcrumbProps>(
  ({ className, ...props }, ref) => (
    <nav ref={ref} aria-label="Breadcrumb" className={className} {...props} />
  ),
);
Breadcrumb.displayName = "Breadcrumb";

/* ------------------------------------------------------------------ */
/*  BreadcrumbList (ol)                                                */
/* ------------------------------------------------------------------ */
export interface BreadcrumbListProps
  extends React.ComponentPropsWithoutRef<"ol"> {}

const BreadcrumbList = React.forwardRef<HTMLOListElement, BreadcrumbListProps>(
  ({ className, ...props }, ref) => (
    <ol
      ref={ref}
      className={cn(
        "flex flex-wrap items-center gap-1.5 text-sm text-zinc-400",
        className,
      )}
      {...props}
    />
  ),
);
BreadcrumbList.displayName = "BreadcrumbList";

/* ------------------------------------------------------------------ */
/*  BreadcrumbItem (li)                                                */
/* ------------------------------------------------------------------ */
export interface BreadcrumbItemProps
  extends React.ComponentPropsWithoutRef<"li"> {}

const BreadcrumbItem = React.forwardRef<HTMLLIElement, BreadcrumbItemProps>(
  ({ className, ...props }, ref) => (
    <li
      ref={ref}
      className={cn("inline-flex items-center gap-1.5", className)}
      {...props}
    />
  ),
);
BreadcrumbItem.displayName = "BreadcrumbItem";

/* ------------------------------------------------------------------ */
/*  BreadcrumbLink (a)                                                 */
/* ------------------------------------------------------------------ */
export interface BreadcrumbLinkProps
  extends React.ComponentPropsWithoutRef<"a"> {}

const BreadcrumbLink = React.forwardRef<HTMLAnchorElement, BreadcrumbLinkProps>(
  ({ className, ...props }, ref) => (
    <a
      ref={ref}
      className={cn(
        "text-zinc-400 transition-colors hover:text-zinc-100",
        className,
      )}
      {...props}
    />
  ),
);
BreadcrumbLink.displayName = "BreadcrumbLink";

/* ------------------------------------------------------------------ */
/*  BreadcrumbSeparator                                                */
/* ------------------------------------------------------------------ */
export interface BreadcrumbSeparatorProps
  extends React.ComponentPropsWithoutRef<"li"> {
  children?: React.ReactNode;
}

const BreadcrumbSeparator = React.forwardRef<
  HTMLLIElement,
  BreadcrumbSeparatorProps
>(({ className, children, ...props }, ref) => (
  <li
    ref={ref}
    role="presentation"
    aria-hidden="true"
    className={cn("text-zinc-600", className)}
    {...props}
  >
    {children ?? "/"}
  </li>
));
BreadcrumbSeparator.displayName = "BreadcrumbSeparator";

/* ------------------------------------------------------------------ */
/*  BreadcrumbPage (current page — no link)                            */
/* ------------------------------------------------------------------ */
export interface BreadcrumbPageProps
  extends React.ComponentPropsWithoutRef<"span"> {}

const BreadcrumbPage = React.forwardRef<HTMLSpanElement, BreadcrumbPageProps>(
  ({ className, ...props }, ref) => (
    <span
      ref={ref}
      role="link"
      aria-current="page"
      aria-disabled="true"
      className={cn("text-zinc-100 font-medium", className)}
      {...props}
    />
  ),
);
BreadcrumbPage.displayName = "BreadcrumbPage";

/* ------------------------------------------------------------------ */
/*  Exports                                                            */
/* ------------------------------------------------------------------ */
export {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
};
