import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

const alertVariants = cva(
  "relative flex gap-3 rounded-xl border px-4 py-3 text-sm [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        info: "border-blue-700/50 bg-blue-950/30 text-blue-400 [&>svg]:text-blue-400",
        warning:
          "border-amber-700/50 bg-amber-950/30 text-amber-400 [&>svg]:text-amber-400",
        danger:
          "border-red-700/50 bg-red-950/30 text-red-400 [&>svg]:text-red-400",
        success:
          "border-emerald-700/50 bg-emerald-950/30 text-emerald-400 [&>svg]:text-emerald-400",
      },
    },
    defaultVariants: {
      variant: "info",
    },
  }
);

// --- Alert ---
export interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {}

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ className, variant, ...props }, ref) => (
    <div
      ref={ref}
      role="alert"
      className={cn(alertVariants({ variant }), className)}
      {...props}
    />
  )
);
Alert.displayName = "Alert";

// --- AlertTitle ---
const AlertTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h5
    ref={ref}
    className={cn("font-semibold text-zinc-100 leading-none tracking-tight", className)}
    {...props}
  />
));
AlertTitle.displayName = "AlertTitle";

// --- AlertDescription ---
const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    className={cn("mt-1 text-sm opacity-90", className)}
    {...props}
  />
));
AlertDescription.displayName = "AlertDescription";

export { Alert, AlertTitle, AlertDescription, alertVariants };
