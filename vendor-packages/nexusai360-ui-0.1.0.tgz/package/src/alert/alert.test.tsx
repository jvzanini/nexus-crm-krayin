import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { Alert, AlertTitle, AlertDescription } from "./index";

describe("Alert", () => {
  it("renders with default info variant", () => {
    render(<Alert>Alert content</Alert>);
    expect(screen.getByRole("alert")).toBeInTheDocument();
  });

  it("renders info variant", () => {
    render(<Alert variant="info">Info</Alert>);
    expect(screen.getByRole("alert").className).toContain("text-blue-400");
  });

  it("renders warning variant", () => {
    render(<Alert variant="warning">Warning</Alert>);
    expect(screen.getByRole("alert").className).toContain("text-amber-400");
  });

  it("renders danger variant", () => {
    render(<Alert variant="danger">Danger</Alert>);
    expect(screen.getByRole("alert").className).toContain("text-red-400");
  });

  it("renders success variant", () => {
    render(<Alert variant="success">Success</Alert>);
    expect(screen.getByRole("alert").className).toContain("text-emerald-400");
  });

  it("renders with title", () => {
    render(
      <Alert>
        <div>
          <AlertTitle>Error occurred</AlertTitle>
        </div>
      </Alert>
    );
    expect(screen.getByText("Error occurred")).toBeInTheDocument();
  });

  it("renders with description", () => {
    render(
      <Alert>
        <div>
          <AlertDescription>Something went wrong</AlertDescription>
        </div>
      </Alert>
    );
    expect(screen.getByText("Something went wrong")).toBeInTheDocument();
  });

  it("renders with title and description together", () => {
    render(
      <Alert>
        <div>
          <AlertTitle>Heads up</AlertTitle>
          <AlertDescription>This is a description</AlertDescription>
        </div>
      </Alert>
    );
    expect(screen.getByText("Heads up")).toBeInTheDocument();
    expect(screen.getByText("This is a description")).toBeInTheDocument();
  });

  it("has alert role", () => {
    render(<Alert>Test</Alert>);
    expect(screen.getByRole("alert")).toBeInTheDocument();
  });

  it("forwards ref on Alert", () => {
    const ref = createRef<HTMLDivElement>();
    render(<Alert ref={ref}>Ref</Alert>);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("forwards ref on AlertTitle", () => {
    const ref = createRef<HTMLParagraphElement>();
    render(
      <Alert>
        <AlertTitle ref={ref}>T</AlertTitle>
      </Alert>
    );
    expect(ref.current).toBeInstanceOf(HTMLElement);
  });

  it("forwards ref on AlertDescription", () => {
    const ref = createRef<HTMLParagraphElement>();
    render(
      <Alert>
        <AlertDescription ref={ref}>D</AlertDescription>
      </Alert>
    );
    expect(ref.current).toBeInstanceOf(HTMLParagraphElement);
  });

  it("merges custom className on Alert", () => {
    render(<Alert className="my-alert">Custom</Alert>);
    expect(screen.getByRole("alert").className).toContain("my-alert");
  });

  it("has correct displayNames", () => {
    expect(Alert.displayName).toBe("Alert");
    expect(AlertTitle.displayName).toBe("AlertTitle");
    expect(AlertDescription.displayName).toBe("AlertDescription");
  });
});
