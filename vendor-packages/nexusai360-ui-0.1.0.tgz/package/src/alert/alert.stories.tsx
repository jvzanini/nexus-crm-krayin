import { Alert, AlertTitle, AlertDescription } from "./index";

export default { title: "DataDisplay/Alert" };

export const Info = () => (
  <Alert variant="info">
    <AlertTitle>Heads up!</AlertTitle>
    <AlertDescription>You can add components to your app using the CLI.</AlertDescription>
  </Alert>
);

export const Warning = () => (
  <Alert variant="warning">
    <AlertTitle>Warning</AlertTitle>
    <AlertDescription>Your session is about to expire.</AlertDescription>
  </Alert>
);

export const Danger = () => (
  <Alert variant="danger">
    <AlertTitle>Error</AlertTitle>
    <AlertDescription>Failed to save your changes.</AlertDescription>
  </Alert>
);

export const Success = () => (
  <Alert variant="success">
    <AlertTitle>Done!</AlertTitle>
    <AlertDescription>Your changes have been saved successfully.</AlertDescription>
  </Alert>
);
