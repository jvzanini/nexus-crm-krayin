import { useState } from "react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationLink,
  PaginationEllipsis,
} from "./index";

export default { title: "DataDisplay/Pagination" };

export const Default = () => {
  const [page, setPage] = useState(3);
  return (
    <Pagination currentPage={page} totalPages={10} onPageChange={setPage}>
      <PaginationContent>
        <PaginationItem><PaginationPrevious /></PaginationItem>
        <PaginationItem><PaginationLink page={1} isActive={page === 1}>1</PaginationLink></PaginationItem>
        <PaginationItem><PaginationLink page={2} isActive={page === 2}>2</PaginationLink></PaginationItem>
        <PaginationItem><PaginationLink page={3} isActive={page === 3}>3</PaginationLink></PaginationItem>
        <PaginationItem><PaginationEllipsis /></PaginationItem>
        <PaginationItem><PaginationLink page={10} isActive={page === 10}>10</PaginationLink></PaginationItem>
        <PaginationItem><PaginationNext /></PaginationItem>
      </PaginationContent>
    </Pagination>
  );
};
