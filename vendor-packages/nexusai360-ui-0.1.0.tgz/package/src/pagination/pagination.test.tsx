import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationLink,
  PaginationEllipsis,
} from "./index";

const renderPagination = (
  currentPage = 1,
  totalPages = 5,
  onPageChange = vi.fn()
) =>
  render(
    <Pagination
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={onPageChange}
    >
      <PaginationContent>
        <PaginationItem>
          <PaginationPrevious />
        </PaginationItem>
        <PaginationItem>
          <PaginationLink page={1} isActive={currentPage === 1} />
        </PaginationItem>
        <PaginationItem>
          <PaginationLink page={2} isActive={currentPage === 2} />
        </PaginationItem>
        <PaginationItem>
          <PaginationEllipsis />
        </PaginationItem>
        <PaginationItem>
          <PaginationLink page={5} isActive={currentPage === 5} />
        </PaginationItem>
        <PaginationItem>
          <PaginationNext />
        </PaginationItem>
      </PaginationContent>
    </Pagination>
  );

describe("Pagination", () => {
  it("renders navigation element", () => {
    renderPagination();
    expect(screen.getByRole("navigation")).toBeInTheDocument();
  });

  it("has aria-label for pagination", () => {
    renderPagination();
    expect(screen.getByRole("navigation")).toHaveAttribute(
      "aria-label",
      "pagination"
    );
  });

  it("renders page links", () => {
    renderPagination();
    expect(screen.getByText("1")).toBeInTheDocument();
    expect(screen.getByText("2")).toBeInTheDocument();
    expect(screen.getByText("5")).toBeInTheDocument();
  });

  it("renders previous button", () => {
    renderPagination();
    expect(screen.getByLabelText("Go to previous page")).toBeInTheDocument();
  });

  it("renders next button", () => {
    renderPagination();
    expect(screen.getByLabelText("Go to next page")).toBeInTheDocument();
  });

  it("disables previous button on first page", () => {
    renderPagination(1, 5);
    expect(screen.getByLabelText("Go to previous page")).toBeDisabled();
  });

  it("disables next button on last page", () => {
    renderPagination(5, 5);
    expect(screen.getByLabelText("Go to next page")).toBeDisabled();
  });

  it("enables previous button when not on first page", () => {
    renderPagination(3, 5);
    expect(screen.getByLabelText("Go to previous page")).not.toBeDisabled();
  });

  it("enables next button when not on last page", () => {
    renderPagination(3, 5);
    expect(screen.getByLabelText("Go to next page")).not.toBeDisabled();
  });

  it("calls onPageChange when clicking a page link", async () => {
    const user = userEvent.setup();
    const onPageChange = vi.fn();
    renderPagination(1, 5, onPageChange);
    await user.click(screen.getByText("2"));
    expect(onPageChange).toHaveBeenCalledWith(2);
  });

  it("calls onPageChange with previous page", async () => {
    const user = userEvent.setup();
    const onPageChange = vi.fn();
    renderPagination(3, 5, onPageChange);
    await user.click(screen.getByLabelText("Go to previous page"));
    expect(onPageChange).toHaveBeenCalledWith(2);
  });

  it("calls onPageChange with next page", async () => {
    const user = userEvent.setup();
    const onPageChange = vi.fn();
    renderPagination(3, 5, onPageChange);
    await user.click(screen.getByLabelText("Go to next page"));
    expect(onPageChange).toHaveBeenCalledWith(4);
  });

  it("marks active page with aria-current", () => {
    renderPagination(1, 5);
    const activeLink = screen.getByText("1");
    expect(activeLink).toHaveAttribute("aria-current", "page");
  });

  it("does not mark inactive pages with aria-current", () => {
    renderPagination(1, 5);
    const inactiveLink = screen.getByText("2");
    expect(inactiveLink).not.toHaveAttribute("aria-current");
  });

  it("renders ellipsis", () => {
    renderPagination();
    expect(screen.getByText("More pages")).toBeInTheDocument();
  });

  it("forwards ref on Pagination", () => {
    const ref = createRef<HTMLElement>();
    render(
      <Pagination ref={ref} currentPage={1} totalPages={1} onPageChange={() => {}}>
        <PaginationContent />
      </Pagination>
    );
    expect(ref.current).toBeInstanceOf(HTMLElement);
  });

  it("has correct displayNames", () => {
    expect(Pagination.displayName).toBe("Pagination");
    expect(PaginationContent.displayName).toBe("PaginationContent");
    expect(PaginationItem.displayName).toBe("PaginationItem");
    expect(PaginationPrevious.displayName).toBe("PaginationPrevious");
    expect(PaginationNext.displayName).toBe("PaginationNext");
    expect(PaginationLink.displayName).toBe("PaginationLink");
    expect(PaginationEllipsis.displayName).toBe("PaginationEllipsis");
  });

  it("merges custom className", () => {
    render(
      <Pagination className="my-nav" currentPage={1} totalPages={1} onPageChange={() => {}}>
        <PaginationContent />
      </Pagination>
    );
    expect(screen.getByRole("navigation").className).toContain("my-nav");
  });
});
