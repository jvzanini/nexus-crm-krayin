import * as React from "react";
import { cn } from "../lib/cn";

// --- Context ---
interface PaginationContextValue {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const PaginationContext = React.createContext<PaginationContextValue>({
  currentPage: 1,
  totalPages: 1,
  onPageChange: () => {},
});

// --- Pagination ---
export interface PaginationProps extends React.HTMLAttributes<HTMLElement> {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const Pagination = React.forwardRef<HTMLElement, PaginationProps>(
  ({ className, currentPage, totalPages, onPageChange, children, ...props }, ref) => (
    <PaginationContext.Provider value={{ currentPage, totalPages, onPageChange }}>
      <nav
        ref={ref}
        role="navigation"
        aria-label="pagination"
        className={cn("mx-auto flex w-full justify-center", className)}
        {...props}
      >
        {children}
      </nav>
    </PaginationContext.Provider>
  )
);
Pagination.displayName = "Pagination";

// --- PaginationContent ---
const PaginationContent = React.forwardRef<
  HTMLUListElement,
  React.HTMLAttributes<HTMLUListElement>
>(({ className, ...props }, ref) => (
  <ul
    ref={ref}
    className={cn("flex flex-row items-center gap-1", className)}
    {...props}
  />
));
PaginationContent.displayName = "PaginationContent";

// --- PaginationItem ---
const PaginationItem = React.forwardRef<
  HTMLLIElement,
  React.LiHTMLAttributes<HTMLLIElement>
>(({ className, ...props }, ref) => (
  <li ref={ref} className={cn("", className)} {...props} />
));
PaginationItem.displayName = "PaginationItem";

// --- PaginationLink ---
export interface PaginationLinkProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  page: number;
  isActive?: boolean;
}

const PaginationLink = React.forwardRef<HTMLButtonElement, PaginationLinkProps>(
  ({ className, page, isActive, children, ...props }, ref) => {
    const { onPageChange } = React.useContext(PaginationContext);
    return (
      <button
        ref={ref}
        type="button"
        aria-current={isActive ? "page" : undefined}
        className={cn(
          "inline-flex h-9 w-9 items-center justify-center rounded-lg text-sm font-medium transition-colors",
          isActive
            ? "bg-violet-600 text-white"
            : "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100",
          className
        )}
        onClick={() => onPageChange(page)}
        {...props}
      >
        {children ?? page}
      </button>
    );
  }
);
PaginationLink.displayName = "PaginationLink";

// --- PaginationPrevious ---
const PaginationPrevious = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement>
>(({ className, ...props }, ref) => {
  const { currentPage, onPageChange } = React.useContext(PaginationContext);
  const isDisabled = currentPage <= 1;
  return (
    <button
      ref={ref}
      type="button"
      aria-label="Go to previous page"
      disabled={isDisabled}
      className={cn(
        "inline-flex h-9 items-center justify-center gap-1 rounded-lg px-3 text-sm font-medium transition-colors",
        "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100",
        "disabled:pointer-events-none disabled:opacity-50",
        className
      )}
      onClick={() => onPageChange(currentPage - 1)}
      {...props}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="m15 18-6-6 6-6" />
      </svg>
      <span>Previous</span>
    </button>
  );
});
PaginationPrevious.displayName = "PaginationPrevious";

// --- PaginationNext ---
const PaginationNext = React.forwardRef<
  HTMLButtonElement,
  React.ButtonHTMLAttributes<HTMLButtonElement>
>(({ className, ...props }, ref) => {
  const { currentPage, totalPages, onPageChange } =
    React.useContext(PaginationContext);
  const isDisabled = currentPage >= totalPages;
  return (
    <button
      ref={ref}
      type="button"
      aria-label="Go to next page"
      disabled={isDisabled}
      className={cn(
        "inline-flex h-9 items-center justify-center gap-1 rounded-lg px-3 text-sm font-medium transition-colors",
        "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100",
        "disabled:pointer-events-none disabled:opacity-50",
        className
      )}
      onClick={() => onPageChange(currentPage + 1)}
      {...props}
    >
      <span>Next</span>
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden="true"
      >
        <path d="m9 18 6-6-6-6" />
      </svg>
    </button>
  );
});
PaginationNext.displayName = "PaginationNext";

// --- PaginationEllipsis ---
const PaginationEllipsis = React.forwardRef<
  HTMLSpanElement,
  React.HTMLAttributes<HTMLSpanElement>
>(({ className, ...props }, ref) => (
  <span
    ref={ref}
    aria-hidden="true"
    className={cn(
      "flex h-9 w-9 items-center justify-center text-zinc-400",
      className
    )}
    {...props}
  >
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
      <circle cx="5" cy="12" r="1" />
    </svg>
    <span className="sr-only">More pages</span>
  </span>
));
PaginationEllipsis.displayName = "PaginationEllipsis";

export {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationLink,
  PaginationEllipsis,
};
