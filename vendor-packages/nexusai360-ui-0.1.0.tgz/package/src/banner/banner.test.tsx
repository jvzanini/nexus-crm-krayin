import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Banner } from "./index";

describe("Banner", () => {
  it("renders with default info variant", () => {
    render(<Banner title="Info" />);
    expect(screen.getByRole("alert")).toBeInTheDocument();
    expect(screen.getByText("Info")).toBeInTheDocument();
  });

  it("renders warning variant", () => {
    render(<Banner variant="warning" title="Warning" />);
    expect(screen.getByRole("alert").className).toContain("text-amber-400");
  });

  it("renders danger variant", () => {
    render(<Banner variant="danger" title="Error" />);
    expect(screen.getByRole("alert").className).toContain("text-red-400");
  });

  it("renders success variant", () => {
    render(<Banner variant="success" title="Done" />);
    expect(screen.getByRole("alert").className).toContain("text-emerald-400");
  });

  it("renders info variant", () => {
    render(<Banner variant="info" title="Note" />);
    expect(screen.getByRole("alert").className).toContain("text-blue-400");
  });

  it("renders title", () => {
    render(<Banner title="Banner title" />);
    expect(screen.getByText("Banner title")).toBeInTheDocument();
  });

  it("renders description", () => {
    render(<Banner title="T" description="Banner description" />);
    expect(screen.getByText("Banner description")).toBeInTheDocument();
  });

  it("renders dismissible button", () => {
    render(<Banner title="T" dismissible />);
    expect(screen.getByLabelText("Dismiss")).toBeInTheDocument();
  });

  it("calls onDismiss when dismiss button clicked", async () => {
    const user = userEvent.setup();
    const onDismiss = vi.fn();
    render(<Banner title="T" dismissible onDismiss={onDismiss} />);
    await user.click(screen.getByLabelText("Dismiss"));
    expect(onDismiss).toHaveBeenCalledTimes(1);
  });

  it("does not show dismiss button when dismissible is false", () => {
    render(<Banner title="T" />);
    expect(screen.queryByLabelText("Dismiss")).not.toBeInTheDocument();
  });

  it("has alert role", () => {
    render(<Banner title="T" />);
    expect(screen.getByRole("alert")).toBeInTheDocument();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLDivElement>();
    render(<Banner ref={ref} title="Ref" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("merges custom className", () => {
    render(<Banner title="T" className="my-banner" />);
    expect(screen.getByRole("alert").className).toContain("my-banner");
  });

  it("has correct displayName", () => {
    expect(Banner.displayName).toBe("Banner");
  });
});
