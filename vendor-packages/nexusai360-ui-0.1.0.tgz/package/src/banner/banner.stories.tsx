import { Banner } from "./index";

export default { title: "DataDisplay/Banner" };

export const Info = () => (
  <Banner variant="info" title="Update available" description="A new version of the app is ready." />
);

export const Warning = () => (
  <Banner variant="warning" title="Approaching limit" description="You have used 90% of your quota." />
);

export const Danger = () => (
  <Banner variant="danger" title="Service outage" description="Some features may be unavailable." />
);

export const Success = () => (
  <Banner variant="success" title="All systems operational" description="Everything is running smoothly." />
);

export const Dismissible = () => (
  <Banner variant="info" title="Tip" description="You can customize this later." dismissible onDismiss={() => {}} />
);
