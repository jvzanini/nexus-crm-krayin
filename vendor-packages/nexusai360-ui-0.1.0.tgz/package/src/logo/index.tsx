import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  Variants                                                           */
/* ------------------------------------------------------------------ */
const logoVariants = cva("inline-flex items-center shrink-0", {
  variants: {
    size: {
      sm: "h-6",
      md: "h-8",
      lg: "h-10",
    },
  },
  defaultVariants: { size: "md" },
});

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface LogoProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof logoVariants> {
  /** full = logo + wordmark, icon-only = just the icon */
  variant?: "full" | "icon-only";
}

/* ------------------------------------------------------------------ */
/*  SVG pieces                                                         */
/* ------------------------------------------------------------------ */
const NexusIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    viewBox="0 0 32 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={cn("h-full w-auto", className)}
    aria-hidden="true"
  >
    <rect width="32" height="32" rx="8" className="fill-violet-600" />
    <path
      d="M8 22V10l8 12V10"
      stroke="white"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="24" cy="16" r="3" className="fill-purple-300" />
  </svg>
);

const NexusWordmark: React.FC<{ className?: string }> = ({ className }) => (
  <span
    className={cn(
      "ml-2 font-bold tracking-tight text-zinc-100",
      className,
    )}
    aria-hidden="true"
  >
    Nexus
  </span>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const Logo = React.forwardRef<HTMLSpanElement, LogoProps>(
  ({ className, variant = "full", size, ...props }, ref) => (
    <span
      ref={ref}
      role="img"
      aria-label="Nexus logo"
      className={cn(logoVariants({ size }), className)}
      {...props}
    >
      <NexusIcon />
      {variant === "full" && <NexusWordmark />}
    </span>
  ),
);

Logo.displayName = "Logo";

export { Logo, logoVariants };
