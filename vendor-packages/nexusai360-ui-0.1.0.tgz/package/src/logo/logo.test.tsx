import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { Logo } from "./index";

describe("Logo", () => {
  // --- Render ---
  it("renders with default variant (full)", () => {
    render(<Logo />);
    expect(screen.getByRole("img", { name: "Nexus logo" })).toBeInTheDocument();
  });

  it("renders wordmark in full variant", () => {
    render(<Logo variant="full" />);
    expect(screen.getByText("Nexus")).toBeInTheDocument();
  });

  it("hides wordmark in icon-only variant", () => {
    render(<Logo variant="icon-only" />);
    expect(screen.queryByText("Nexus")).not.toBeInTheDocument();
  });

  // --- Sizes ---
  it("applies sm size", () => {
    render(<Logo size="sm" />);
    expect(screen.getByRole("img").className).toContain("h-6");
  });

  it("applies md size (default)", () => {
    render(<Logo />);
    expect(screen.getByRole("img").className).toContain("h-8");
  });

  it("applies lg size", () => {
    render(<Logo size="lg" />);
    expect(screen.getByRole("img").className).toContain("h-10");
  });

  // --- SVG ---
  it("renders SVG element", () => {
    const { container } = render(<Logo />);
    expect(container.querySelector("svg")).toBeInTheDocument();
  });

  // --- Ref ---
  it("forwards ref", () => {
    const ref = createRef<HTMLSpanElement>();
    render(<Logo ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLSpanElement);
  });

  // --- className ---
  it("merges custom className", () => {
    render(<Logo className="my-logo" />);
    expect(screen.getByRole("img").className).toContain("my-logo");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(Logo.displayName).toBe("Logo");
  });
});
