import { Logo } from "./index";

export default { title: "Navigation/Logo" };

export const Full = () => <Logo variant="full" />;
export const IconOnly = () => <Logo variant="icon-only" />;

export const Sizes = () => (
  <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
    <Logo size="sm" />
    <Logo size="md" />
    <Logo size="lg" />
  </div>
);
