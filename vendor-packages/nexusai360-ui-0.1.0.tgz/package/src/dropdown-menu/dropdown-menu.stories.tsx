import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "./index";

export default { title: "Primitives/DropdownMenu" };

export const Default = () => (
  <DropdownMenu>
    <DropdownMenuTrigger className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">
      Open Menu
    </DropdownMenuTrigger>
    <DropdownMenuContent>
      <DropdownMenuLabel>Actions</DropdownMenuLabel>
      <DropdownMenuItem onSelect={() => {}}>Edit</DropdownMenuItem>
      <DropdownMenuItem onSelect={() => {}}>Duplicate</DropdownMenuItem>
      <DropdownMenuSeparator />
      <DropdownMenuItem onSelect={() => {}} disabled>Delete</DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>
);

export const WithCheckbox = () => {
  const [checked, setChecked] = useState(true);
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">
        Options
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuCheckboxItem checked={checked} onCheckedChange={setChecked}>
          Show hidden files
        </DropdownMenuCheckboxItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export const WithRadio = () => {
  const [value, setValue] = useState("comfortable");
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">
        Density
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuRadioGroup value={value} onValueChange={setValue}>
          <DropdownMenuRadioItem value="compact">Compact</DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="comfortable">Comfortable</DropdownMenuRadioItem>
          <DropdownMenuRadioItem value="spacious">Spacious</DropdownMenuRadioItem>
        </DropdownMenuRadioGroup>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export const WithSubmenu = () => (
  <DropdownMenu>
    <DropdownMenuTrigger className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">
      Menu
    </DropdownMenuTrigger>
    <DropdownMenuContent>
      <DropdownMenuItem onSelect={() => {}}>New File</DropdownMenuItem>
      <DropdownMenuSub>
        <DropdownMenuSubTrigger>More</DropdownMenuSubTrigger>
        <DropdownMenuSubContent>
          <DropdownMenuItem onSelect={() => {}}>Import</DropdownMenuItem>
          <DropdownMenuItem onSelect={() => {}}>Export</DropdownMenuItem>
        </DropdownMenuSubContent>
      </DropdownMenuSub>
    </DropdownMenuContent>
  </DropdownMenu>
);
