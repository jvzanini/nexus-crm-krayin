import * as React from "react";
import { cn } from "../lib/cn";

// --- Icons ---
const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const DotIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <circle cx="6" cy="6" r="3" fill="currentColor" />
  </svg>
);

const ChevronRight: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M4.5 2.5L8 6L4.5 9.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// --- Context ---
interface DropdownMenuContextValue {
  open: boolean;
  setOpen: (open: boolean) => void;
  triggerRef: React.RefObject<HTMLButtonElement | null>;
}

const DropdownMenuContext = React.createContext<DropdownMenuContextValue | null>(null);

function useDropdownMenu() {
  const ctx = React.useContext(DropdownMenuContext);
  if (!ctx) throw new Error("DropdownMenu components must be used within <DropdownMenu>");
  return ctx;
}

// --- DropdownMenu (root) ---
export interface DropdownMenuProps {
  children: React.ReactNode;
  /** Controlled open state */
  open?: boolean;
  /** Callback on open change */
  onOpenChange?: (open: boolean) => void;
}

const DropdownMenu: React.FC<DropdownMenuProps> = ({
  children,
  open: controlledOpen,
  onOpenChange,
}) => {
  const [internalOpen, setInternalOpen] = React.useState(false);
  const open = controlledOpen ?? internalOpen;
  const setOpen = React.useCallback(
    (v: boolean) => {
      setInternalOpen(v);
      onOpenChange?.(v);
    },
    [onOpenChange]
  );
  const triggerRef = React.useRef<HTMLButtonElement | null>(null);

  const ctx = React.useMemo(
    () => ({ open, setOpen, triggerRef }),
    [open, setOpen]
  );

  return (
    <DropdownMenuContext.Provider value={ctx}>
      <div className="relative inline-block">{children}</div>
    </DropdownMenuContext.Provider>
  );
};

DropdownMenu.displayName = "DropdownMenu";

// --- DropdownMenuTrigger ---
export interface DropdownMenuTriggerProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

const DropdownMenuTrigger = React.forwardRef<HTMLButtonElement, DropdownMenuTriggerProps>(
  ({ children, className, onClick, ...props }, ref) => {
    const { open, setOpen, triggerRef } = useDropdownMenu();

    const setRefs = React.useCallback(
      (node: HTMLButtonElement | null) => {
        (triggerRef as React.MutableRefObject<HTMLButtonElement | null>).current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) (ref as React.MutableRefObject<HTMLButtonElement | null>).current = node;
      },
      [ref, triggerRef]
    );

    const handleClick = React.useCallback(
      (e: React.MouseEvent<HTMLButtonElement>) => {
        setOpen(!open);
        onClick?.(e);
      },
      [open, setOpen, onClick]
    );

    const handleKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          if (!open) setOpen(true);
        }
      },
      [open, setOpen]
    );

    return (
      <button
        ref={setRefs}
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        className={className}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        {...props}
      >
        {children}
      </button>
    );
  }
);

DropdownMenuTrigger.displayName = "DropdownMenuTrigger";

// --- DropdownMenuContent (the actual menu) ---
interface DropdownMenuContentProps {
  children: React.ReactNode;
  className?: string;
  align?: "start" | "center" | "end";
}

const DropdownMenuContent = React.forwardRef<HTMLDivElement, DropdownMenuContentProps>(
  ({ children, className, align = "start", ...props }, ref) => {
    const { open, setOpen, triggerRef } = useDropdownMenu();
    const menuRef = React.useRef<HTMLDivElement | null>(null);

    const setRefs = React.useCallback(
      (node: HTMLDivElement | null) => {
        menuRef.current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) (ref as React.MutableRefObject<HTMLDivElement | null>).current = node;
      },
      [ref]
    );

    // Close on outside click
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: MouseEvent) => {
        if (
          !menuRef.current?.contains(e.target as Node) &&
          !triggerRef.current?.contains(e.target as Node)
        ) {
          setOpen(false);
        }
      };
      document.addEventListener("mousedown", handler);
      return () => document.removeEventListener("mousedown", handler);
    }, [open, setOpen, triggerRef]);

    // Close on Escape
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          setOpen(false);
          triggerRef.current?.focus();
        }
      };
      document.addEventListener("keydown", handler);
      return () => document.removeEventListener("keydown", handler);
    }, [open, setOpen, triggerRef]);

    if (!open) return null;

    return (
      <div
        ref={setRefs}
        role="menu"
        className={cn(
          "absolute z-50 mt-1 min-w-[8rem] overflow-hidden rounded-lg border p-1",
          "bg-zinc-900 border-zinc-700 shadow-lg shadow-black/40",
          "animate-in fade-in-0 zoom-in-95",
          align === "start" && "left-0",
          align === "center" && "left-1/2 -translate-x-1/2",
          align === "end" && "right-0",
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

DropdownMenuContent.displayName = "DropdownMenuContent";

// --- DropdownMenuLabel ---
export interface DropdownMenuLabelProps {
  children: React.ReactNode;
  className?: string;
  inset?: boolean;
}

const DropdownMenuLabel = React.forwardRef<HTMLDivElement, DropdownMenuLabelProps>(
  ({ children, className, inset, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={cn(
          "px-2 py-1.5 text-xs font-medium text-zinc-500",
          inset && "pl-8",
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

DropdownMenuLabel.displayName = "DropdownMenuLabel";

// --- DropdownMenuItem ---
export interface DropdownMenuItemProps {
  children: React.ReactNode;
  disabled?: boolean;
  onSelect?: () => void;
  className?: string;
  inset?: boolean;
}

const DropdownMenuItem = React.forwardRef<HTMLDivElement, DropdownMenuItemProps>(
  ({ children, disabled = false, onSelect, className, inset, ...props }, ref) => {
    const { setOpen } = useDropdownMenu();

    const handleClick = React.useCallback(() => {
      if (disabled) return;
      onSelect?.();
      setOpen(false);
    }, [disabled, onSelect, setOpen]);

    const handleKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleClick();
        }
      },
      [handleClick]
    );

    return (
      <div
        ref={ref}
        role="menuitem"
        tabIndex={disabled ? -1 : 0}
        aria-disabled={disabled || undefined}
        className={cn(
          "flex items-center gap-2 rounded-md px-2 h-8 text-sm cursor-pointer select-none outline-none",
          "text-zinc-100 hover:bg-zinc-800 focus-visible:bg-zinc-800",
          disabled && "opacity-50 cursor-not-allowed",
          inset && "pl-8",
          className
        )}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        {...props}
      >
        {children}
      </div>
    );
  }
);

DropdownMenuItem.displayName = "DropdownMenuItem";

// --- DropdownMenuSeparator ---
export interface DropdownMenuSeparatorProps {
  className?: string;
}

const DropdownMenuSeparator = React.forwardRef<HTMLDivElement, DropdownMenuSeparatorProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        role="separator"
        className={cn("-mx-1 my-1 h-px bg-zinc-700", className)}
        {...props}
      />
    );
  }
);

DropdownMenuSeparator.displayName = "DropdownMenuSeparator";

// --- DropdownMenuCheckboxItem ---
export interface DropdownMenuCheckboxItemProps {
  children: React.ReactNode;
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
  disabled?: boolean;
  className?: string;
}

const DropdownMenuCheckboxItem = React.forwardRef<HTMLDivElement, DropdownMenuCheckboxItemProps>(
  ({ children, checked = false, onCheckedChange, disabled = false, className, ...props }, ref) => {
    const handleClick = React.useCallback(() => {
      if (disabled) return;
      onCheckedChange?.(!checked);
    }, [disabled, checked, onCheckedChange]);

    const handleKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleClick();
        }
      },
      [handleClick]
    );

    return (
      <div
        ref={ref}
        role="menuitemcheckbox"
        aria-checked={checked}
        aria-disabled={disabled || undefined}
        tabIndex={disabled ? -1 : 0}
        className={cn(
          "flex items-center gap-2 rounded-md px-2 pl-8 h-8 text-sm cursor-pointer select-none outline-none relative",
          "text-zinc-100 hover:bg-zinc-800 focus-visible:bg-zinc-800",
          disabled && "opacity-50 cursor-not-allowed",
          className
        )}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        {...props}
      >
        <span className="absolute left-2 flex size-4 items-center justify-center">
          {checked && <CheckIcon className="size-3 text-violet-400" />}
        </span>
        {children}
      </div>
    );
  }
);

DropdownMenuCheckboxItem.displayName = "DropdownMenuCheckboxItem";

// --- DropdownMenuRadioGroup ---
interface DropdownMenuRadioContextValue {
  value: string;
  onValueChange: (value: string) => void;
}

const DropdownMenuRadioContext = React.createContext<DropdownMenuRadioContextValue | null>(null);

export interface DropdownMenuRadioGroupProps {
  children: React.ReactNode;
  value: string;
  onValueChange: (value: string) => void;
}

const DropdownMenuRadioGroup = React.forwardRef<HTMLDivElement, DropdownMenuRadioGroupProps>(
  ({ children, value, onValueChange, ...props }, ref) => {
    const ctx = React.useMemo(() => ({ value, onValueChange }), [value, onValueChange]);
    return (
      <DropdownMenuRadioContext.Provider value={ctx}>
        <div ref={ref} role="group" {...props}>
          {children}
        </div>
      </DropdownMenuRadioContext.Provider>
    );
  }
);

DropdownMenuRadioGroup.displayName = "DropdownMenuRadioGroup";

// --- DropdownMenuRadioItem ---
export interface DropdownMenuRadioItemProps {
  children: React.ReactNode;
  value: string;
  disabled?: boolean;
  className?: string;
}

const DropdownMenuRadioItem = React.forwardRef<HTMLDivElement, DropdownMenuRadioItemProps>(
  ({ children, value, disabled = false, className, ...props }, ref) => {
    const radioCtx = React.useContext(DropdownMenuRadioContext);
    if (!radioCtx) throw new Error("DropdownMenuRadioItem must be used within DropdownMenuRadioGroup");

    const isSelected = radioCtx.value === value;

    const handleClick = React.useCallback(() => {
      if (disabled) return;
      radioCtx.onValueChange(value);
    }, [disabled, radioCtx, value]);

    const handleKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          handleClick();
        }
      },
      [handleClick]
    );

    return (
      <div
        ref={ref}
        role="menuitemradio"
        aria-checked={isSelected}
        aria-disabled={disabled || undefined}
        tabIndex={disabled ? -1 : 0}
        className={cn(
          "flex items-center gap-2 rounded-md px-2 pl-8 h-8 text-sm cursor-pointer select-none outline-none relative",
          "text-zinc-100 hover:bg-zinc-800 focus-visible:bg-zinc-800",
          disabled && "opacity-50 cursor-not-allowed",
          className
        )}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        {...props}
      >
        <span className="absolute left-2 flex size-4 items-center justify-center">
          {isSelected && <DotIcon className="size-3 text-violet-400" />}
        </span>
        {children}
      </div>
    );
  }
);

DropdownMenuRadioItem.displayName = "DropdownMenuRadioItem";

// --- DropdownMenuSub ---
interface DropdownMenuSubContextValue {
  subOpen: boolean;
  setSubOpen: (open: boolean) => void;
}

const DropdownMenuSubContext = React.createContext<DropdownMenuSubContextValue | null>(null);

export interface DropdownMenuSubProps {
  children: React.ReactNode;
}

const DropdownMenuSub: React.FC<DropdownMenuSubProps> = ({ children }) => {
  const [subOpen, setSubOpen] = React.useState(false);
  const ctx = React.useMemo(() => ({ subOpen, setSubOpen }), [subOpen]);
  return (
    <DropdownMenuSubContext.Provider value={ctx}>
      <div
        className="relative"
        onMouseEnter={() => setSubOpen(true)}
        onMouseLeave={() => setSubOpen(false)}
      >
        {children}
      </div>
    </DropdownMenuSubContext.Provider>
  );
};

DropdownMenuSub.displayName = "DropdownMenuSub";

// --- DropdownMenuSubTrigger ---
export interface DropdownMenuSubTriggerProps {
  children: React.ReactNode;
  className?: string;
}

const DropdownMenuSubTrigger = React.forwardRef<HTMLDivElement, DropdownMenuSubTriggerProps>(
  ({ children, className, ...props }, ref) => {
    const subCtx = React.useContext(DropdownMenuSubContext);
    return (
      <div
        ref={ref}
        role="menuitem"
        aria-haspopup="menu"
        aria-expanded={subCtx?.subOpen}
        tabIndex={0}
        className={cn(
          "flex items-center justify-between gap-2 rounded-md px-2 h-8 text-sm cursor-pointer select-none outline-none",
          "text-zinc-100 hover:bg-zinc-800 focus-visible:bg-zinc-800",
          className
        )}
        onClick={() => subCtx?.setSubOpen(!subCtx.subOpen)}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight" || e.key === "Enter") {
            e.preventDefault();
            subCtx?.setSubOpen(true);
          }
          if (e.key === "ArrowLeft" || e.key === "Escape") {
            e.preventDefault();
            subCtx?.setSubOpen(false);
          }
        }}
        {...props}
      >
        {children}
        <ChevronRight className="size-3 text-zinc-400" />
      </div>
    );
  }
);

DropdownMenuSubTrigger.displayName = "DropdownMenuSubTrigger";

// --- DropdownMenuSubContent ---
export interface DropdownMenuSubContentProps {
  children: React.ReactNode;
  className?: string;
}

const DropdownMenuSubContent = React.forwardRef<HTMLDivElement, DropdownMenuSubContentProps>(
  ({ children, className, ...props }, ref) => {
    const subCtx = React.useContext(DropdownMenuSubContext);
    if (!subCtx?.subOpen) return null;

    return (
      <div
        ref={ref}
        role="menu"
        className={cn(
          "absolute left-full top-0 z-50 ml-1 min-w-[8rem] overflow-hidden rounded-lg border p-1",
          "bg-zinc-900 border-zinc-700 shadow-lg shadow-black/40",
          className
        )}
        {...props}
      >
        {children}
      </div>
    );
  }
);

DropdownMenuSubContent.displayName = "DropdownMenuSubContent";

export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
};
