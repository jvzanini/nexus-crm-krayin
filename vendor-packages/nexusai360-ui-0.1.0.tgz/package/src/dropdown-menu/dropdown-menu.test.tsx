import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
} from "./index";

function renderBasicMenu(opts?: { onSelect?: () => void }) {
  return render(
    <DropdownMenu>
      <DropdownMenuTrigger>Open Menu</DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuLabel>Actions</DropdownMenuLabel>
        <DropdownMenuItem onSelect={opts?.onSelect}>Edit</DropdownMenuItem>
        <DropdownMenuItem>Duplicate</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem disabled>Delete</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

describe("DropdownMenu", () => {
  it("renders the trigger", () => {
    renderBasicMenu();
    expect(screen.getByText("Open Menu")).toBeInTheDocument();
  });

  it("trigger has aria-haspopup", () => {
    renderBasicMenu();
    expect(screen.getByText("Open Menu")).toHaveAttribute("aria-haspopup", "menu");
  });

  it("trigger has aria-expanded false initially", () => {
    renderBasicMenu();
    expect(screen.getByText("Open Menu")).toHaveAttribute("aria-expanded", "false");
  });

  it("does not show content initially", () => {
    renderBasicMenu();
    expect(screen.queryByRole("menu")).not.toBeInTheDocument();
  });

  it("opens on trigger click", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    expect(screen.getByRole("menu")).toBeInTheDocument();
  });

  it("trigger has aria-expanded true when open", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    expect(screen.getByText("Open Menu")).toHaveAttribute("aria-expanded", "true");
  });

  it("shows menu items when open", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    expect(screen.getAllByRole("menuitem")).toHaveLength(3);
  });

  it("shows label", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    expect(screen.getByText("Actions")).toBeInTheDocument();
  });

  it("shows separator", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    expect(screen.getByRole("separator")).toBeInTheDocument();
  });

  it("calls onSelect when item clicked", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    renderBasicMenu({ onSelect });
    await user.click(screen.getByText("Open Menu"));
    await user.click(screen.getByText("Edit"));
    expect(onSelect).toHaveBeenCalledTimes(1);
  });

  it("closes after item selection", async () => {
    const user = userEvent.setup();
    renderBasicMenu({ onSelect: vi.fn() });
    await user.click(screen.getByText("Open Menu"));
    await user.click(screen.getByText("Edit"));
    expect(screen.queryByRole("menu")).not.toBeInTheDocument();
  });

  it("disabled item has aria-disabled", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    expect(screen.getByText("Delete")).toHaveAttribute("aria-disabled", "true");
  });

  it("disabled item does not fire onSelect", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem disabled onSelect={onSelect}>
            No
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    await user.click(screen.getByText("No"));
    expect(onSelect).not.toHaveBeenCalled();
  });

  it("closes on Escape", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    await user.click(screen.getByText("Open Menu"));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("menu")).not.toBeInTheDocument();
  });

  it("toggles on trigger click", async () => {
    const user = userEvent.setup();
    renderBasicMenu();
    const trigger = screen.getByText("Open Menu");
    await user.click(trigger);
    expect(screen.getByRole("menu")).toBeInTheDocument();
    await user.click(trigger);
    expect(screen.queryByRole("menu")).not.toBeInTheDocument();
  });

  it("item responds to Enter key", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    renderBasicMenu({ onSelect });
    await user.click(screen.getByText("Open Menu"));
    const item = screen.getByText("Edit");
    item.focus();
    await user.keyboard("{Enter}");
    expect(onSelect).toHaveBeenCalledTimes(1);
  });

  it("controlled open state", async () => {
    const user = userEvent.setup();
    const onOpenChange = vi.fn();
    render(
      <DropdownMenu open={false} onOpenChange={onOpenChange}>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem>Item</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    expect(screen.queryByRole("menu")).not.toBeInTheDocument();
    await user.click(screen.getByText("Menu"));
    expect(onOpenChange).toHaveBeenCalledWith(true);
  });
});

describe("DropdownMenuCheckboxItem", () => {
  it("renders with role menuitemcheckbox", async () => {
    const user = userEvent.setup();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuCheckboxItem checked={false}>Show Line Numbers</DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    expect(screen.getByRole("menuitemcheckbox")).toBeInTheDocument();
  });

  it("has aria-checked false when unchecked", async () => {
    const user = userEvent.setup();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuCheckboxItem checked={false}>CB</DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    expect(screen.getByRole("menuitemcheckbox")).toHaveAttribute("aria-checked", "false");
  });

  it("has aria-checked true when checked", async () => {
    const user = userEvent.setup();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuCheckboxItem checked={true}>CB</DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    expect(screen.getByRole("menuitemcheckbox")).toHaveAttribute("aria-checked", "true");
  });

  it("calls onCheckedChange on click", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuCheckboxItem checked={false} onCheckedChange={onCheckedChange}>
            CB
          </DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    await user.click(screen.getByText("CB"));
    expect(onCheckedChange).toHaveBeenCalledWith(true);
  });

  it("does not fire when disabled", async () => {
    const user = userEvent.setup();
    const onCheckedChange = vi.fn();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuCheckboxItem disabled onCheckedChange={onCheckedChange}>
            CB
          </DropdownMenuCheckboxItem>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    await user.click(screen.getByText("CB"));
    expect(onCheckedChange).not.toHaveBeenCalled();
  });
});

describe("DropdownMenuRadioGroup", () => {
  function renderRadio(value: string, onValueChange = vi.fn()) {
    return render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuRadioGroup value={value} onValueChange={onValueChange}>
            <DropdownMenuRadioItem value="a">Alpha</DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="b">Beta</DropdownMenuRadioItem>
            <DropdownMenuRadioItem value="c" disabled>Gamma</DropdownMenuRadioItem>
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  it("renders radio items with correct role", async () => {
    const user = userEvent.setup();
    renderRadio("a");
    await user.click(screen.getByText("Menu"));
    expect(screen.getAllByRole("menuitemradio")).toHaveLength(3);
  });

  it("marks selected item aria-checked", async () => {
    const user = userEvent.setup();
    renderRadio("b");
    await user.click(screen.getByText("Menu"));
    const items = screen.getAllByRole("menuitemradio");
    expect(items[0]).toHaveAttribute("aria-checked", "false");
    expect(items[1]).toHaveAttribute("aria-checked", "true");
  });

  it("calls onValueChange on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderRadio("a", onValueChange);
    await user.click(screen.getByText("Menu"));
    await user.click(screen.getByText("Beta"));
    expect(onValueChange).toHaveBeenCalledWith("b");
  });

  it("disabled radio item does not fire", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    renderRadio("a", onValueChange);
    await user.click(screen.getByText("Menu"));
    await user.click(screen.getByText("Gamma"));
    expect(onValueChange).not.toHaveBeenCalled();
  });
});

describe("DropdownMenuSub", () => {
  it("renders sub trigger with aria-haspopup", async () => {
    const user = userEvent.setup();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>More</DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              <DropdownMenuItem>Sub Item</DropdownMenuItem>
            </DropdownMenuSubContent>
          </DropdownMenuSub>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    expect(screen.getByText("More")).toHaveAttribute("aria-haspopup", "menu");
  });

  it("opens sub on hover", async () => {
    const user = userEvent.setup();
    render(
      <DropdownMenu>
        <DropdownMenuTrigger>Menu</DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>More</DropdownMenuSubTrigger>
            <DropdownMenuSubContent>
              <DropdownMenuItem>Sub Item</DropdownMenuItem>
            </DropdownMenuSubContent>
          </DropdownMenuSub>
        </DropdownMenuContent>
      </DropdownMenu>
    );
    await user.click(screen.getByText("Menu"));
    await user.hover(screen.getByText("More"));
    // Sub content should appear (on hover of the parent container)
    expect(screen.getByText("Sub Item")).toBeInTheDocument();
  });
});

describe("displayNames", () => {
  it("all components have correct displayName", () => {
    expect(DropdownMenu.displayName).toBe("DropdownMenu");
    expect(DropdownMenuTrigger.displayName).toBe("DropdownMenuTrigger");
    expect(DropdownMenuContent.displayName).toBe("DropdownMenuContent");
    expect(DropdownMenuLabel.displayName).toBe("DropdownMenuLabel");
    expect(DropdownMenuItem.displayName).toBe("DropdownMenuItem");
    expect(DropdownMenuSeparator.displayName).toBe("DropdownMenuSeparator");
    expect(DropdownMenuCheckboxItem.displayName).toBe("DropdownMenuCheckboxItem");
    expect(DropdownMenuRadioGroup.displayName).toBe("DropdownMenuRadioGroup");
    expect(DropdownMenuRadioItem.displayName).toBe("DropdownMenuRadioItem");
    expect(DropdownMenuSub.displayName).toBe("DropdownMenuSub");
    expect(DropdownMenuSubTrigger.displayName).toBe("DropdownMenuSubTrigger");
    expect(DropdownMenuSubContent.displayName).toBe("DropdownMenuSubContent");
  });
});
