"use client";

import * as React from "react";
import { motion, AnimatePresence } from "motion/react";
import type { Variants, HTMLMotionProps } from "motion/react";

/* ------------------------------------------------------------------ */
/*  Canonical Variants                                                 */
/* ------------------------------------------------------------------ */

export const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" } },
  exit: { opacity: 0, y: 16, transition: { duration: 0.2 } },
};

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.25, ease: "easeOut" } },
  exit: { opacity: 0, scale: 0.9, transition: { duration: 0.15 } },
};

export const slideInRight: Variants = {
  hidden: { opacity: 0, x: 24 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.3, ease: "easeOut" } },
  exit: { opacity: 0, x: 24, transition: { duration: 0.2 } },
};

export const slideInLeft: Variants = {
  hidden: { opacity: 0, x: -24 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.3, ease: "easeOut" } },
  exit: { opacity: 0, x: -24, transition: { duration: 0.2 } },
};

export const glowPulse: Variants = {
  hidden: { opacity: 0.6, boxShadow: "0 0 0px rgba(139,92,246,0)" },
  visible: {
    opacity: 1,
    boxShadow: "0 0 24px rgba(139,92,246,0.4)",
    transition: { duration: 0.8, repeat: Infinity, repeatType: "reverse" },
  },
};

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: { opacity: 1, transition: { duration: 0.3, ease: "easeOut" } },
  exit: { opacity: 0, transition: { duration: 0.2 } },
};

export const collapseVertical: Variants = {
  hidden: { opacity: 0, height: 0, overflow: "hidden" },
  visible: {
    opacity: 1,
    height: "auto",
    overflow: "hidden",
    transition: { duration: 0.3, ease: "easeOut" },
  },
  exit: {
    opacity: 0,
    height: 0,
    overflow: "hidden",
    transition: { duration: 0.2 },
  },
};

/* ------------------------------------------------------------------ */
/*  Re-export AnimatePresence                                          */
/* ------------------------------------------------------------------ */

export { AnimatePresence };

/* ------------------------------------------------------------------ */
/*  MotionDiv — convenience wrapper                                    */
/* ------------------------------------------------------------------ */

export interface MotionDivProps extends HTMLMotionProps<"div"> {
  children?: React.ReactNode;
}

export const MotionDiv = React.forwardRef<HTMLDivElement, MotionDivProps>(
  (props, ref) => {
    return React.createElement(motion.div, { ...props, ref });
  },
);
MotionDiv.displayName = "MotionDiv";
