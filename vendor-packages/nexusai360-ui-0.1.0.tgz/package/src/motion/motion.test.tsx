import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import {
  fadeInUp,
  scaleIn,
  slideInRight,
  slideInLeft,
  glowPulse,
  fadeIn,
  collapseVertical,
  AnimatePresence,
  MotionDiv,
} from "./index";
import type { Variants } from "motion/react";

/* ------------------------------------------------------------------ */
/*  Variant shape tests                                                */
/* ------------------------------------------------------------------ */

function assertVariantShape(name: string, variant: Variants, keys: string[]) {
  describe(`${name} variant`, () => {
    for (const key of keys) {
      it(`has "${key}" state`, () => {
        expect(variant).toHaveProperty(key);
      });
    }
  });
}

assertVariantShape("fadeInUp", fadeInUp, ["hidden", "visible", "exit"]);
assertVariantShape("scaleIn", scaleIn, ["hidden", "visible", "exit"]);
assertVariantShape("slideInRight", slideInRight, ["hidden", "visible", "exit"]);
assertVariantShape("slideInLeft", slideInLeft, ["hidden", "visible", "exit"]);
assertVariantShape("glowPulse", glowPulse, ["hidden", "visible"]);
assertVariantShape("fadeIn", fadeIn, ["hidden", "visible", "exit"]);
assertVariantShape("collapseVertical", collapseVertical, ["hidden", "visible", "exit"]);

/* ------------------------------------------------------------------ */
/*  Specific property checks                                           */
/* ------------------------------------------------------------------ */

describe("fadeInUp properties", () => {
  it("hidden has opacity 0 and positive y", () => {
    expect((fadeInUp as any).hidden.opacity).toBe(0);
    expect((fadeInUp as any).hidden.y).toBeGreaterThan(0);
  });

  it("visible has opacity 1 and y=0", () => {
    expect((fadeInUp as any).visible.opacity).toBe(1);
    expect((fadeInUp as any).visible.y).toBe(0);
  });
});

describe("scaleIn properties", () => {
  it("hidden has scale < 1", () => {
    expect((scaleIn as any).hidden.scale).toBeLessThan(1);
  });
  it("visible has scale 1", () => {
    expect((scaleIn as any).visible.scale).toBe(1);
  });
});

describe("slideInRight properties", () => {
  it("hidden has positive x offset", () => {
    expect((slideInRight as any).hidden.x).toBeGreaterThan(0);
  });
});

describe("slideInLeft properties", () => {
  it("hidden has negative x offset", () => {
    expect((slideInLeft as any).hidden.x).toBeLessThan(0);
  });
});

describe("collapseVertical properties", () => {
  it("hidden has height 0", () => {
    expect((collapseVertical as any).hidden.height).toBe(0);
  });
  it("visible has height auto", () => {
    expect((collapseVertical as any).visible.height).toBe("auto");
  });
});

/* ------------------------------------------------------------------ */
/*  AnimatePresence re-export                                          */
/* ------------------------------------------------------------------ */

describe("AnimatePresence", () => {
  it("is exported and renderable", () => {
    const { container } = render(
      <AnimatePresence>
        <div key="a">hello</div>
      </AnimatePresence>,
    );
    expect(container.textContent).toContain("hello");
  });
});

/* ------------------------------------------------------------------ */
/*  MotionDiv                                                          */
/* ------------------------------------------------------------------ */

describe("MotionDiv", () => {
  it("renders children", () => {
    render(<MotionDiv data-testid="mdiv">content</MotionDiv>);
    expect(screen.getByTestId("mdiv")).toBeInTheDocument();
    expect(screen.getByTestId("mdiv").textContent).toBe("content");
  });

  it("has correct displayName", () => {
    expect(MotionDiv.displayName).toBe("MotionDiv");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLDivElement | null };
    render(<MotionDiv ref={ref}>test</MotionDiv>);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("accepts motion props", () => {
    render(
      <MotionDiv
        data-testid="mdiv2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        animated
      </MotionDiv>,
    );
    expect(screen.getByTestId("mdiv2")).toBeInTheDocument();
  });

  it("accepts variants prop", () => {
    render(
      <MotionDiv
        data-testid="mdiv3"
        variants={fadeInUp}
        initial="hidden"
        animate="visible"
      >
        variant
      </MotionDiv>,
    );
    expect(screen.getByTestId("mdiv3")).toBeInTheDocument();
  });
});
