import { MotionDiv, fadeInUp, scaleIn, slideInRight, fadeIn } from "./index";

export default { title: "Motion/Motion" };

export const FadeInUp = () => (
  <MotionDiv variants={fadeInUp} initial="hidden" animate="visible">
    <div className="p-4 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Fade In Up</div>
  </MotionDiv>
);

export const ScaleIn = () => (
  <MotionDiv variants={scaleIn} initial="hidden" animate="visible">
    <div className="p-4 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Scale In</div>
  </MotionDiv>
);

export const SlideInRight = () => (
  <MotionDiv variants={slideInRight} initial="hidden" animate="visible">
    <div className="p-4 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Slide In Right</div>
  </MotionDiv>
);

export const FadeIn = () => (
  <MotionDiv variants={fadeIn} initial="hidden" animate="visible">
    <div className="p-4 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Fade In</div>
  </MotionDiv>
);
