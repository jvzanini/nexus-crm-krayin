import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableRow,
  TableHead,
  TableCell,
  TableCaption,
} from "./index";

describe("Table", () => {
  const renderTable = () =>
    render(
      <Table>
        <TableCaption>A list of users</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Email</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow>
            <TableCell>Alice</TableCell>
            <TableCell>alice@example.com</TableCell>
          </TableRow>
          <TableRow>
            <TableCell>Bob</TableCell>
            <TableCell>bob@example.com</TableCell>
          </TableRow>
        </TableBody>
        <TableFooter>
          <TableRow>
            <TableCell colSpan={2}>Total: 2</TableCell>
          </TableRow>
        </TableFooter>
      </Table>
    );

  it("renders a table element", () => {
    renderTable();
    expect(screen.getByRole("table")).toBeInTheDocument();
  });

  it("renders table header with column headers", () => {
    renderTable();
    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("Email")).toBeInTheDocument();
  });

  it("renders table rows with cells", () => {
    renderTable();
    expect(screen.getByText("Alice")).toBeInTheDocument();
    expect(screen.getByText("alice@example.com")).toBeInTheDocument();
    expect(screen.getByText("Bob")).toBeInTheDocument();
  });

  it("renders caption", () => {
    renderTable();
    expect(screen.getByText("A list of users")).toBeInTheDocument();
  });

  it("renders footer", () => {
    renderTable();
    expect(screen.getByText("Total: 2")).toBeInTheDocument();
  });

  it("uses semantic HTML elements", () => {
    const { container } = renderTable();
    expect(container.querySelector("table")).toBeInTheDocument();
    expect(container.querySelector("thead")).toBeInTheDocument();
    expect(container.querySelector("tbody")).toBeInTheDocument();
    expect(container.querySelector("tfoot")).toBeInTheDocument();
    expect(container.querySelector("th")).toBeInTheDocument();
    expect(container.querySelector("td")).toBeInTheDocument();
    expect(container.querySelector("caption")).toBeInTheDocument();
  });

  it("forwards ref on Table", () => {
    const ref = createRef<HTMLTableElement>();
    render(<Table ref={ref}><TableBody><TableRow><TableCell>x</TableCell></TableRow></TableBody></Table>);
    expect(ref.current).toBeInstanceOf(HTMLTableElement);
  });

  it("forwards ref on TableRow", () => {
    const ref = createRef<HTMLTableRowElement>();
    render(<Table><TableBody><TableRow ref={ref}><TableCell>x</TableCell></TableRow></TableBody></Table>);
    expect(ref.current).toBeInstanceOf(HTMLTableRowElement);
  });

  it("forwards ref on TableCell", () => {
    const ref = createRef<HTMLTableCellElement>();
    render(<Table><TableBody><TableRow><TableCell ref={ref}>x</TableCell></TableRow></TableBody></Table>);
    expect(ref.current).toBeInstanceOf(HTMLTableCellElement);
  });

  it("forwards ref on TableHead", () => {
    const ref = createRef<HTMLTableCellElement>();
    render(<Table><TableHeader><TableRow><TableHead ref={ref}>x</TableHead></TableRow></TableHeader></Table>);
    expect(ref.current).toBeInstanceOf(HTMLTableCellElement);
  });

  it("merges custom className on Table", () => {
    render(<Table className="my-table"><TableBody><TableRow><TableCell>x</TableCell></TableRow></TableBody></Table>);
    expect(screen.getByRole("table").className).toContain("my-table");
  });

  it("merges custom className on TableRow", () => {
    const { container } = render(<Table><TableBody><TableRow className="my-row"><TableCell>x</TableCell></TableRow></TableBody></Table>);
    expect(container.querySelector("tr")!.className).toContain("my-row");
  });

  it("has correct displayNames", () => {
    expect(Table.displayName).toBe("Table");
    expect(TableHeader.displayName).toBe("TableHeader");
    expect(TableBody.displayName).toBe("TableBody");
    expect(TableFooter.displayName).toBe("TableFooter");
    expect(TableRow.displayName).toBe("TableRow");
    expect(TableHead.displayName).toBe("TableHead");
    expect(TableCell.displayName).toBe("TableCell");
    expect(TableCaption.displayName).toBe("TableCaption");
  });

  it("renders multiple rows correctly", () => {
    renderTable();
    const rows = screen.getAllByRole("row");
    // 1 header row + 2 body rows + 1 footer row
    expect(rows).toHaveLength(4);
  });
});
