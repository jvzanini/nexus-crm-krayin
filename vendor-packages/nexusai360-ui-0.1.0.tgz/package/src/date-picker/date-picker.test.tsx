import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { createRef } from "react";
import { DatePicker } from "./index";

describe("DatePicker", () => {
  // --- Render ---
  it("renders date input", () => {
    render(<DatePicker />);
    expect(screen.getByDisplayValue("")).toBeInTheDocument();
  });

  it("renders with type=date", () => {
    const { container } = render(<DatePicker />);
    expect(container.querySelector('input[type="date"]')).toBeInTheDocument();
  });

  // --- Value ---
  it("displays formatted value", () => {
    render(<DatePicker value={new Date(2025, 0, 15)} />);
    expect(screen.getByDisplayValue("2025-01-15")).toBeInTheDocument();
  });

  it("displays empty when value is null", () => {
    render(<DatePicker value={null} />);
    expect(screen.getByDisplayValue("")).toBeInTheDocument();
  });

  // --- onChange ---
  it("calls onChange with Date on input change", () => {
    const onChange = vi.fn();
    render(<DatePicker onChange={onChange} />);
    const input = screen.getByDisplayValue("");
    fireEvent.change(input, { target: { value: "2025-06-20" } });
    expect(onChange).toHaveBeenCalledTimes(1);
    const arg = onChange.mock.calls[0][0] as Date;
    expect(arg.getFullYear()).toBe(2025);
    expect(arg.getMonth()).toBe(5); // June = 5
    expect(arg.getDate()).toBe(20);
  });

  it("calls onChange with null on empty input", () => {
    const onChange = vi.fn();
    render(<DatePicker value={new Date(2025, 0, 1)} onChange={onChange} />);
    fireEvent.change(screen.getByDisplayValue("2025-01-01"), { target: { value: "" } });
    expect(onChange).toHaveBeenCalledWith(null);
  });

  // --- Min / Max ---
  it("sets min attribute", () => {
    const { container } = render(<DatePicker min={new Date(2025, 0, 1)} />);
    expect(container.querySelector("input")).toHaveAttribute("min", "2025-01-01");
  });

  it("sets max attribute", () => {
    const { container } = render(<DatePicker max={new Date(2025, 11, 31)} />);
    expect(container.querySelector("input")).toHaveAttribute("max", "2025-12-31");
  });

  // --- Disabled ---
  it("disables input", () => {
    const { container } = render(<DatePicker disabled />);
    expect(container.querySelector("input")).toBeDisabled();
  });

  it("sets aria-disabled when disabled", () => {
    const { container } = render(<DatePicker disabled />);
    expect(container.querySelector("input")).toHaveAttribute("aria-disabled", "true");
  });

  // --- Ref ---
  it("forwards ref", () => {
    const ref = createRef<HTMLInputElement>();
    render(<DatePicker ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLInputElement);
  });

  // --- className ---
  it("merges custom className", () => {
    const { container } = render(<DatePicker className="my-date" />);
    expect(container.querySelector("input")!.className).toContain("my-date");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(DatePicker.displayName).toBe("DatePicker");
  });
});
