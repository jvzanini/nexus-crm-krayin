import { useState } from "react";
import { DatePicker } from "./index";

export default { title: "Navigation/DatePicker" };

export const Default = () => {
  const [date, setDate] = useState<Date | null>(null);
  return <DatePicker value={date} onChange={setDate} />;
};

export const WithValue = () => {
  const [date, setDate] = useState<Date | null>(new Date(2025, 5, 15));
  return <DatePicker value={date} onChange={setDate} />;
};

export const WithMinMax = () => {
  const [date, setDate] = useState<Date | null>(null);
  return (
    <DatePicker
      value={date}
      onChange={setDate}
      min={new Date(2025, 0, 1)}
      max={new Date(2025, 11, 31)}
      placeholder="Select date in 2025"
    />
  );
};

export const Disabled = () => <DatePicker disabled placeholder="Disabled" />;
