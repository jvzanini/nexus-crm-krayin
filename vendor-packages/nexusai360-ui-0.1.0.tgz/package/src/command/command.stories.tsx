import {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from "./index";

export default { title: "Primitives/Command" };

export const Default = () => (
  <Command className="w-96">
    <CommandInput placeholder="Search commands..." />
    <CommandList>
      <CommandEmpty>No results found.</CommandEmpty>
      <CommandGroup heading="Suggestions">
        <CommandItem value="calendar">Calendar</CommandItem>
        <CommandItem value="search">Search</CommandItem>
        <CommandItem value="settings">Settings</CommandItem>
      </CommandGroup>
      <CommandSeparator />
      <CommandGroup heading="Actions">
        <CommandItem value="create">Create New</CommandItem>
        <CommandItem value="delete" disabled>Delete</CommandItem>
      </CommandGroup>
    </CommandList>
  </Command>
);

export const WithKeywords = () => (
  <Command className="w-96">
    <CommandInput placeholder="Try typing 'config'..." />
    <CommandList>
      <CommandEmpty>Nothing found.</CommandEmpty>
      <CommandGroup heading="Navigation">
        <CommandItem value="settings" keywords={["config", "preferences"]}>
          Settings
        </CommandItem>
        <CommandItem value="profile" keywords={["account", "user"]}>
          Profile
        </CommandItem>
      </CommandGroup>
    </CommandList>
  </Command>
);
