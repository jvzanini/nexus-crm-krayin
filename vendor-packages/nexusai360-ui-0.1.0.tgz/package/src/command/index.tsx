import * as React from "react";
import { cn } from "../lib/cn";

// --- Icons ---
const SearchIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <circle cx="7" cy="7" r="4.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M10.5 10.5L14 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

// --- Context ---
interface CommandContextValue {
  search: string;
  setSearch: (s: string) => void;
  selectedValue: string;
  setSelectedValue: (v: string) => void;
  onSelect: (value: string) => void;
}

const CommandContext = React.createContext<CommandContextValue | null>(null);

function useCommand() {
  const ctx = React.useContext(CommandContext);
  if (!ctx) throw new Error("Command components must be used within <Command>");
  return ctx;
}

// --- Command (root) ---
export interface CommandProps {
  children: React.ReactNode;
  className?: string;
  /** Callback when an item is selected */
  onSelect?: (value: string) => void;
  /** Controlled search value */
  search?: string;
  /** Callback for search changes */
  onSearchChange?: (search: string) => void;
  /** Label for accessibility */
  label?: string;
}

const Command = React.forwardRef<HTMLDivElement, CommandProps>(
  ({ children, className, onSelect, search: controlledSearch, onSearchChange, label, ...props }, ref) => {
    const [internalSearch, setInternalSearch] = React.useState("");
    const search = controlledSearch ?? internalSearch;
    const setSearch = React.useCallback(
      (s: string) => {
        setInternalSearch(s);
        onSearchChange?.(s);
      },
      [onSearchChange]
    );

    const [selectedValue, setSelectedValue] = React.useState("");

    const handleSelect = React.useCallback(
      (value: string) => {
        onSelect?.(value);
      },
      [onSelect]
    );

    const ctx = React.useMemo<CommandContextValue>(
      () => ({
        search,
        setSearch,
        selectedValue,
        setSelectedValue,
        onSelect: handleSelect,
      }),
      [search, setSearch, selectedValue, setSelectedValue, handleSelect]
    );

    return (
      <CommandContext.Provider value={ctx}>
        <div
          ref={ref}
          role="dialog"
          aria-label={label ?? "Command palette"}
          className={cn(
            "flex flex-col overflow-hidden rounded-lg border",
            "bg-zinc-900 border-zinc-700",
            className
          )}
          {...props}
        >
          {children}
        </div>
      </CommandContext.Provider>
    );
  }
);

Command.displayName = "Command";

// --- CommandInput ---
export interface CommandInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value"> {
  /** Placeholder text */
  placeholder?: string;
}

const CommandInput = React.forwardRef<HTMLInputElement, CommandInputProps>(
  ({ className, placeholder = "Type a command or search...", ...props }, ref) => {
    const { search, setSearch } = useCommand();
    return (
      <div className={cn("flex items-center gap-2 border-b border-zinc-700 px-3", className)}>
        <SearchIcon className="size-4 text-zinc-400 shrink-0" />
        <input
          ref={ref}
          type="text"
          role="searchbox"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={placeholder}
          className={cn(
            "flex-1 h-10 bg-transparent text-sm text-zinc-100 placeholder:text-zinc-500",
            "outline-none border-none"
          )}
          autoComplete="off"
          autoCorrect="off"
          spellCheck={false}
          {...props}
        />
      </div>
    );
  }
);

CommandInput.displayName = "CommandInput";

// --- CommandList ---
export interface CommandListProps {
  children: React.ReactNode;
  className?: string;
}

const CommandList = React.forwardRef<HTMLDivElement, CommandListProps>(
  ({ children, className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        role="listbox"
        className={cn("overflow-y-auto max-h-72 p-1", className)}
        {...props}
      >
        {children}
      </div>
    );
  }
);

CommandList.displayName = "CommandList";

// --- CommandEmpty ---
export interface CommandEmptyProps {
  children?: React.ReactNode;
  className?: string;
}

const CommandEmpty = React.forwardRef<HTMLDivElement, CommandEmptyProps>(
  ({ children, className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        role="status"
        className={cn("py-6 text-center text-sm text-zinc-500", className)}
        {...props}
      >
        {children ?? "No results found."}
      </div>
    );
  }
);

CommandEmpty.displayName = "CommandEmpty";

// --- CommandGroup ---
export interface CommandGroupProps {
  children: React.ReactNode;
  heading?: string;
  className?: string;
}

const CommandGroup = React.forwardRef<HTMLDivElement, CommandGroupProps>(
  ({ children, heading, className, ...props }, ref) => {
    const headingId = React.useId();
    return (
      <div
        ref={ref}
        role="group"
        aria-labelledby={heading ? headingId : undefined}
        className={cn("py-1", className)}
        {...props}
      >
        {heading && (
          <div
            id={headingId}
            className="px-2 py-1.5 text-xs font-medium text-zinc-500"
          >
            {heading}
          </div>
        )}
        {children}
      </div>
    );
  }
);

CommandGroup.displayName = "CommandGroup";

// --- CommandItem ---
export interface CommandItemProps {
  children: React.ReactNode;
  value: string;
  disabled?: boolean;
  onSelect?: (value: string) => void;
  className?: string;
  /** Keywords for search filtering (in addition to text content) */
  keywords?: string[];
}

const CommandItem = React.forwardRef<HTMLDivElement, CommandItemProps>(
  ({ children, value, disabled = false, onSelect, className, keywords = [], ...props }, ref) => {
    const { search, onSelect: ctxOnSelect, selectedValue, setSelectedValue } = useCommand();

    // Filter logic: check if item matches search
    const textContent = typeof children === "string" ? children : value;
    const searchLower = search.toLowerCase();
    const isMatch =
      !search ||
      value.toLowerCase().includes(searchLower) ||
      String(textContent).toLowerCase().includes(searchLower) ||
      keywords.some((k) => k.toLowerCase().includes(searchLower));

    if (!isMatch) return null;

    const handleClick = () => {
      if (disabled) return;
      onSelect?.(value);
      ctxOnSelect(value);
    };

    const handleKeyDown = (e: React.KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        handleClick();
      }
    };

    return (
      <div
        ref={ref}
        role="option"
        aria-selected={selectedValue === value}
        aria-disabled={disabled || undefined}
        data-value={value}
        tabIndex={disabled ? -1 : 0}
        className={cn(
          "flex items-center gap-2 rounded-md px-2 h-8 text-sm cursor-pointer select-none",
          "text-zinc-100 outline-none",
          "hover:bg-zinc-800 focus-visible:bg-zinc-800",
          disabled && "opacity-50 cursor-not-allowed",
          className
        )}
        onClick={handleClick}
        onKeyDown={handleKeyDown}
        onFocus={() => setSelectedValue(value)}
        {...props}
      >
        {children}
      </div>
    );
  }
);

CommandItem.displayName = "CommandItem";

// --- CommandSeparator ---
export interface CommandSeparatorProps {
  className?: string;
}

const CommandSeparator = React.forwardRef<HTMLDivElement, CommandSeparatorProps>(
  ({ className, ...props }, ref) => {
    return (
      <div
        ref={ref}
        role="separator"
        className={cn("-mx-1 my-1 h-px bg-zinc-700", className)}
        {...props}
      />
    );
  }
);

CommandSeparator.displayName = "CommandSeparator";

export {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
};
