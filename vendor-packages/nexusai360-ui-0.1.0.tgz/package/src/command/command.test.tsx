import { describe, it, expect, vi } from "vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from "./index";

function renderCommand(props: { onSelect?: (v: string) => void } = {}) {
  return render(
    <Command onSelect={props.onSelect} label="Test palette">
      <CommandInput placeholder="Search..." />
      <CommandList>
        <CommandGroup heading="Fruits">
          <CommandItem value="apple">Apple</CommandItem>
          <CommandItem value="banana">Banana</CommandItem>
          <CommandItem value="cherry">Cherry</CommandItem>
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Vegetables">
          <CommandItem value="carrot">Carrot</CommandItem>
          <CommandItem value="broccoli">Broccoli</CommandItem>
        </CommandGroup>
      </CommandList>
    </Command>
  );
}

describe("Command", () => {
  it("renders the command dialog", () => {
    renderCommand();
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("renders with custom label", () => {
    renderCommand();
    expect(screen.getByRole("dialog")).toHaveAttribute("aria-label", "Test palette");
  });

  it("renders the search input", () => {
    renderCommand();
    expect(screen.getByRole("searchbox")).toBeInTheDocument();
  });

  it("renders placeholder in search input", () => {
    renderCommand();
    expect(screen.getByPlaceholderText("Search...")).toBeInTheDocument();
  });

  it("renders all items", () => {
    renderCommand();
    expect(screen.getAllByRole("option")).toHaveLength(5);
  });

  it("renders group headings", () => {
    renderCommand();
    expect(screen.getByText("Fruits")).toBeInTheDocument();
    expect(screen.getByText("Vegetables")).toBeInTheDocument();
  });

  it("renders separator", () => {
    renderCommand();
    expect(screen.getByRole("separator")).toBeInTheDocument();
  });

  it("filters items by search", async () => {
    const user = userEvent.setup();
    renderCommand();
    await user.type(screen.getByRole("searchbox"), "app");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(screen.getByText("Apple")).toBeInTheDocument();
  });

  it("shows all items when search is cleared", async () => {
    const user = userEvent.setup();
    renderCommand();
    const input = screen.getByRole("searchbox");
    await user.type(input, "app");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    await user.clear(input);
    expect(screen.getAllByRole("option")).toHaveLength(5);
  });

  it("calls onSelect when item clicked", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    renderCommand({ onSelect });
    await user.click(screen.getByText("Banana"));
    expect(onSelect).toHaveBeenCalledWith("banana");
  });

  it("calls onSelect on Enter key", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    renderCommand({ onSelect });
    const item = screen.getByText("Apple");
    item.focus();
    await user.keyboard("{Enter}");
    expect(onSelect).toHaveBeenCalledWith("apple");
  });

  it("calls onSelect on Space key", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    renderCommand({ onSelect });
    const item = screen.getByText("Cherry");
    item.focus();
    await user.keyboard(" ");
    expect(onSelect).toHaveBeenCalledWith("cherry");
  });

  it("does not call onSelect for disabled item", async () => {
    const user = userEvent.setup();
    const onSelect = vi.fn();
    render(
      <Command onSelect={onSelect}>
        <CommandList>
          <CommandItem value="disabled-item" disabled>
            Disabled
          </CommandItem>
        </CommandList>
      </Command>
    );
    await user.click(screen.getByText("Disabled"));
    expect(onSelect).not.toHaveBeenCalled();
  });

  it("filters by keywords", async () => {
    const user = userEvent.setup();
    render(
      <Command>
        <CommandInput />
        <CommandList>
          <CommandItem value="settings" keywords={["preferences", "config"]}>
            Settings
          </CommandItem>
          <CommandItem value="profile">Profile</CommandItem>
        </CommandList>
      </Command>
    );
    await user.type(screen.getByRole("searchbox"), "config");
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(screen.getByText("Settings")).toBeInTheDocument();
  });

  it("shows empty state when no results", async () => {
    const user = userEvent.setup();
    render(
      <Command>
        <CommandInput />
        <CommandList>
          <CommandItem value="a">A</CommandItem>
          <CommandEmpty>Nothing here</CommandEmpty>
        </CommandList>
      </Command>
    );
    // empty is always shown when rendered — in real usage you'd conditionally render it
    // but the component itself always renders
    expect(screen.getByText("Nothing here")).toBeInTheDocument();
  });

  it("renders CommandEmpty with default text", () => {
    render(
      <Command>
        <CommandList>
          <CommandEmpty />
        </CommandList>
      </Command>
    );
    expect(screen.getByText("No results found.")).toBeInTheDocument();
  });

  it("groups have aria-labelledby", () => {
    renderCommand();
    const groups = screen.getAllByRole("group");
    expect(groups[0]).toHaveAttribute("aria-labelledby");
  });

  it("disabled item has aria-disabled", () => {
    render(
      <Command>
        <CommandList>
          <CommandItem value="x" disabled>
            X
          </CommandItem>
        </CommandList>
      </Command>
    );
    expect(screen.getByRole("option")).toHaveAttribute("aria-disabled", "true");
  });

  it("forwards ref on Command root", () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <Command ref={ref}>
        <CommandList>
          <CommandItem value="a">A</CommandItem>
        </CommandList>
      </Command>
    );
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("has correct displayName for all components", () => {
    expect(Command.displayName).toBe("Command");
    expect(CommandInput.displayName).toBe("CommandInput");
    expect(CommandList.displayName).toBe("CommandList");
    expect(CommandEmpty.displayName).toBe("CommandEmpty");
    expect(CommandGroup.displayName).toBe("CommandGroup");
    expect(CommandItem.displayName).toBe("CommandItem");
    expect(CommandSeparator.displayName).toBe("CommandSeparator");
  });

  it("controlled search works", async () => {
    const user = userEvent.setup();
    const onSearchChange = vi.fn();
    render(
      <Command search="ban" onSearchChange={onSearchChange}>
        <CommandInput />
        <CommandList>
          <CommandItem value="apple">Apple</CommandItem>
          <CommandItem value="banana">Banana</CommandItem>
        </CommandList>
      </Command>
    );
    // Only banana should be visible
    expect(screen.getAllByRole("option")).toHaveLength(1);
    expect(screen.getByText("Banana")).toBeInTheDocument();
  });

  it("renders listbox", () => {
    renderCommand();
    expect(screen.getByRole("listbox")).toBeInTheDocument();
  });
});
