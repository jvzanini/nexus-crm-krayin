import { Popover, PopoverTrigger, PopoverContent } from "./index";

export default { title: "Overlays/Popover" };

export const Default = () => (
  <Popover>
    <PopoverTrigger asChild>
      <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Popover</button>
    </PopoverTrigger>
    <PopoverContent>
      <div className="flex flex-col gap-2 text-sm text-zinc-200">
        <p className="font-medium">Popover Content</p>
        <p className="text-zinc-400">Place any content here.</p>
      </div>
    </PopoverContent>
  </Popover>
);
