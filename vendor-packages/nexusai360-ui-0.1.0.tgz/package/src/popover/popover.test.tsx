import { describe, it, expect } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverArrow,
} from "./index";

function renderPopover() {
  return render(
    <Popover>
      <PopoverTrigger>Toggle</PopoverTrigger>
      <PopoverContent>
        <PopoverArrow />
        <p>Popover body</p>
      </PopoverContent>
    </Popover>,
  );
}

describe("Popover", () => {
  it("renders trigger", () => {
    renderPopover();
    expect(screen.getByText("Toggle")).toBeInTheDocument();
  });

  it("opens on trigger click", async () => {
    const user = userEvent.setup();
    renderPopover();
    await user.click(screen.getByText("Toggle"));
    expect(screen.getByText("Popover body")).toBeInTheDocument();
  });

  it("closes on second trigger click", async () => {
    const user = userEvent.setup();
    renderPopover();
    await user.click(screen.getByText("Toggle"));
    expect(screen.getByText("Popover body")).toBeInTheDocument();
    await user.click(screen.getByText("Toggle"));
    await waitFor(() =>
      expect(screen.queryByText("Popover body")).not.toBeInTheDocument(),
    );
  });

  it("closes on Escape", async () => {
    const user = userEvent.setup();
    renderPopover();
    await user.click(screen.getByText("Toggle"));
    expect(screen.getByText("Popover body")).toBeInTheDocument();
    await user.keyboard("{Escape}");
    await waitFor(() =>
      expect(screen.queryByText("Popover body")).not.toBeInTheDocument(),
    );
  });

  it("renders content with correct classes", async () => {
    const user = userEvent.setup();
    render(
      <Popover>
        <PopoverTrigger>T</PopoverTrigger>
        <PopoverContent className="my-pop">Content</PopoverContent>
      </Popover>,
    );
    await user.click(screen.getByText("T"));
    const content = screen.getByText("Content");
    expect(content.className).toContain("my-pop");
  });

  it("PopoverContent has displayName", () => {
    expect(PopoverContent.displayName).toBe("PopoverContent");
  });

  it("PopoverArrow has displayName", () => {
    expect(PopoverArrow.displayName).toBe("PopoverArrow");
  });

  it("applies default sideOffset", async () => {
    const user = userEvent.setup();
    renderPopover();
    await user.click(screen.getByText("Toggle"));
    // Content should be rendered (sideOffset is internal to Radix positioning)
    expect(screen.getByText("Popover body")).toBeInTheDocument();
  });

  it("renders inside portal", async () => {
    const user = userEvent.setup();
    const { container } = renderPopover();
    await user.click(screen.getByText("Toggle"));
    // Content is portaled — not inside the container's direct tree
    const bodyInContainer = container.querySelector('[class*="rounded-xl"]');
    expect(bodyInContainer).toBeNull();
    expect(screen.getByText("Popover body")).toBeInTheDocument();
  });

  it("renders arrow element", async () => {
    const user = userEvent.setup();
    renderPopover();
    await user.click(screen.getByText("Toggle"));
    // Arrow is an SVG rendered by Radix
    const popoverBody = screen.getByText("Popover body");
    const parent = popoverBody.closest("[data-radix-popper-content-wrapper]");
    expect(parent).toBeInTheDocument();
  });
});
