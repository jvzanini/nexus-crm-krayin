import * as React from "react";
import { cn } from "../lib/cn";

export interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Width of the skeleton (CSS value) */
  width?: string | number;
  /** Height of the skeleton (CSS value) */
  height?: string | number;
  /** Render as circle */
  circle?: boolean;
}

const Skeleton = React.forwardRef<HTMLDivElement, SkeletonProps>(
  ({ className, width, height, circle = false, style, ...props }, ref) => (
    <div
      ref={ref}
      aria-hidden="true"
      className={cn(
        "animate-pulse bg-zinc-800",
        circle ? "rounded-full" : "rounded-xl",
        className
      )}
      style={{
        width: width ?? (circle ? height : undefined),
        height,
        ...style,
      }}
      {...props}
    />
  )
);

Skeleton.displayName = "Skeleton";

export { Skeleton };
