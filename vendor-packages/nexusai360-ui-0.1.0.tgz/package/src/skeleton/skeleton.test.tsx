import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import { createRef } from "react";
import { Skeleton } from "./index";

describe("Skeleton", () => {
  it("renders a div", () => {
    const { container } = render(<Skeleton />);
    expect(container.firstElementChild).toBeInstanceOf(HTMLDivElement);
  });

  it("has pulse animation class", () => {
    const { container } = render(<Skeleton />);
    expect(container.firstElementChild!.className).toContain("animate-pulse");
  });

  it("is hidden from accessibility tree", () => {
    const { container } = render(<Skeleton />);
    expect(container.firstElementChild).toHaveAttribute("aria-hidden", "true");
  });

  it("applies custom width", () => {
    const { container } = render(<Skeleton width={200} />);
    expect(container.firstElementChild).toHaveStyle({ width: "200px" });
  });

  it("applies custom height", () => {
    const { container } = render(<Skeleton height={40} />);
    expect(container.firstElementChild).toHaveStyle({ height: "40px" });
  });

  it("applies string width", () => {
    const { container } = render(<Skeleton width="100%" />);
    expect(container.firstElementChild).toHaveStyle({ width: "100%" });
  });

  it("renders circle variant", () => {
    const { container } = render(<Skeleton circle height={48} />);
    expect(container.firstElementChild!.className).toContain("rounded-full");
    expect(container.firstElementChild).toHaveStyle({ width: "48px", height: "48px" });
  });

  it("renders rectangle variant by default", () => {
    const { container } = render(<Skeleton />);
    expect(container.firstElementChild!.className).toContain("rounded-xl");
    expect(container.firstElementChild!.className).not.toContain("rounded-full");
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLDivElement>();
    render(<Skeleton ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("merges custom className", () => {
    const { container } = render(<Skeleton className="my-skeleton" />);
    expect(container.firstElementChild!.className).toContain("my-skeleton");
  });

  it("has correct displayName", () => {
    expect(Skeleton.displayName).toBe("Skeleton");
  });

  it("merges custom style", () => {
    const { container } = render(<Skeleton style={{ opacity: 0.5 }} />);
    expect(container.firstElementChild).toHaveStyle({ opacity: "0.5" });
  });
});
