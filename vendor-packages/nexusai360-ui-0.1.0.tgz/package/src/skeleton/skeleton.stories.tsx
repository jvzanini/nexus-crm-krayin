import { Skeleton } from "./index";

export default { title: "DataDisplay/Skeleton" };

export const Default = () => <Skeleton className="h-4 w-48" />;

export const Card = () => (
  <div className="flex flex-col gap-3 w-64">
    <Skeleton className="h-32 w-full rounded-lg" />
    <Skeleton className="h-4 w-3/4" />
    <Skeleton className="h-4 w-1/2" />
  </div>
);

export const Avatar = () => <Skeleton className="h-10 w-10 rounded-full" />;

export const TableRows = () => (
  <div className="flex flex-col gap-2 w-96">
    {Array.from({ length: 4 }).map((_, i) => (
      <div key={i} className="flex gap-3">
        <Skeleton className="h-4 w-20" />
        <Skeleton className="h-4 w-32" />
        <Skeleton className="h-4 w-16" />
      </div>
    ))}
  </div>
);
