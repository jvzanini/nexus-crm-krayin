import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "./index";

const renderAccordion = (type: "single" | "multiple" = "single") =>
  render(
    <Accordion type={type} collapsible={type === "single" ? true : undefined}>
      <AccordionItem value="item-1">
        <AccordionTrigger>Item 1</AccordionTrigger>
        <AccordionContent>Content 1</AccordionContent>
      </AccordionItem>
      <AccordionItem value="item-2">
        <AccordionTrigger>Item 2</AccordionTrigger>
        <AccordionContent>Content 2</AccordionContent>
      </AccordionItem>
      <AccordionItem value="item-3">
        <AccordionTrigger>Item 3</AccordionTrigger>
        <AccordionContent>Content 3</AccordionContent>
      </AccordionItem>
    </Accordion>
  );

describe("Accordion", () => {
  it("renders all triggers", () => {
    renderAccordion();
    expect(screen.getByText("Item 1")).toBeInTheDocument();
    expect(screen.getByText("Item 2")).toBeInTheDocument();
    expect(screen.getByText("Item 3")).toBeInTheDocument();
  });

  it("content is hidden by default", () => {
    renderAccordion();
    // Radix removes closed content from DOM in jsdom
    expect(screen.queryByText("Content 1")).not.toBeInTheDocument();
  });

  it("expands content on click", async () => {
    const user = userEvent.setup();
    renderAccordion();
    await user.click(screen.getByText("Item 1"));
    expect(screen.getByText("Content 1")).toBeVisible();
  });

  it("collapses content on second click (single collapsible)", async () => {
    const user = userEvent.setup();
    renderAccordion("single");
    await user.click(screen.getByText("Item 1"));
    expect(screen.getByText("Content 1")).toBeVisible();
    await user.click(screen.getByText("Item 1"));
    expect(screen.queryByText("Content 1")).not.toBeInTheDocument();
  });

  it("single mode: only one item open at a time", async () => {
    const user = userEvent.setup();
    renderAccordion("single");
    await user.click(screen.getByText("Item 1"));
    expect(screen.getByText("Content 1")).toBeVisible();
    await user.click(screen.getByText("Item 2"));
    expect(screen.getByText("Content 2")).toBeVisible();
    expect(screen.queryByText("Content 1")).not.toBeInTheDocument();
  });

  it("multiple mode: multiple items can be open", async () => {
    const user = userEvent.setup();
    renderAccordion("multiple");
    await user.click(screen.getByText("Item 1"));
    await user.click(screen.getByText("Item 2"));
    expect(screen.getByText("Content 1")).toBeVisible();
    expect(screen.getByText("Content 2")).toBeVisible();
  });

  it("trigger has button role", () => {
    renderAccordion();
    const triggers = screen.getAllByRole("button");
    expect(triggers.length).toBeGreaterThanOrEqual(3);
  });

  it("trigger has aria-expanded", async () => {
    const user = userEvent.setup();
    renderAccordion();
    const trigger = screen.getByText("Item 1");
    expect(trigger.closest("button")).toHaveAttribute("aria-expanded", "false");
    await user.click(trigger);
    expect(trigger.closest("button")).toHaveAttribute("aria-expanded", "true");
  });

  it("keyboard: Enter expands item", async () => {
    const user = userEvent.setup();
    renderAccordion();
    const trigger = screen.getByText("Item 1").closest("button")!;
    trigger.focus();
    await user.keyboard("{Enter}");
    expect(screen.getByText("Content 1")).toBeVisible();
  });

  it("keyboard: Space expands item", async () => {
    const user = userEvent.setup();
    renderAccordion();
    const trigger = screen.getByText("Item 1").closest("button")!;
    trigger.focus();
    await user.keyboard(" ");
    expect(screen.getByText("Content 1")).toBeVisible();
  });

  it("forwards ref on AccordionItem", () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <Accordion type="single" collapsible>
        <AccordionItem ref={ref} value="item-1">
          <AccordionTrigger>T</AccordionTrigger>
          <AccordionContent>C</AccordionContent>
        </AccordionItem>
      </Accordion>
    );
    expect(ref.current).toBeInstanceOf(HTMLElement);
  });

  it("has correct displayNames", () => {
    expect(AccordionItem.displayName).toBe("AccordionItem");
    expect(AccordionTrigger.displayName).toBe("AccordionTrigger");
    expect(AccordionContent.displayName).toBe("AccordionContent");
  });

  it("merges custom className on AccordionItem", () => {
    const { container } = render(
      <Accordion type="single" collapsible>
        <AccordionItem className="my-item" value="item-1">
          <AccordionTrigger>T</AccordionTrigger>
          <AccordionContent>C</AccordionContent>
        </AccordionItem>
      </Accordion>
    );
    expect(container.querySelector("[data-state]")!.className).toContain("my-item");
  });
});
