import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "./index";

export default { title: "DataDisplay/Accordion" };

export const Default = () => (
  <Accordion type="single" collapsible className="w-96">
    <AccordionItem value="item-1">
      <AccordionTrigger>What is Nexus Blueprint?</AccordionTrigger>
      <AccordionContent>
        A design system and component library for building modern dashboards.
      </AccordionContent>
    </AccordionItem>
    <AccordionItem value="item-2">
      <AccordionTrigger>How do I get started?</AccordionTrigger>
      <AccordionContent>
        Install the package and import the components you need.
      </AccordionContent>
    </AccordionItem>
    <AccordionItem value="item-3">
      <AccordionTrigger>Is it accessible?</AccordionTrigger>
      <AccordionContent>
        Yes, all components follow WAI-ARIA patterns.
      </AccordionContent>
    </AccordionItem>
  </Accordion>
);

export const Multiple = () => (
  <Accordion type="multiple" className="w-96">
    <AccordionItem value="a">
      <AccordionTrigger>Section A</AccordionTrigger>
      <AccordionContent>Content A</AccordionContent>
    </AccordionItem>
    <AccordionItem value="b">
      <AccordionTrigger>Section B</AccordionTrigger>
      <AccordionContent>Content B</AccordionContent>
    </AccordionItem>
  </Accordion>
);
