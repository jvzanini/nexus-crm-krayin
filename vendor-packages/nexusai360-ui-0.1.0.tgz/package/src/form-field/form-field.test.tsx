import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { FormField } from "./index";

// Simple mock Input for testing
function MockInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} />;
}

describe("FormField", () => {
  it("renders label", () => {
    render(
      <FormField label="Email">
        <MockInput />
      </FormField>
    );
    expect(screen.getByText("Email")).toBeInTheDocument();
  });

  it("renders children", () => {
    render(
      <FormField label="Name">
        <MockInput data-testid="input" />
      </FormField>
    );
    expect(screen.getByTestId("input")).toBeInTheDocument();
  });

  it("shows required asterisk on label", () => {
    render(
      <FormField label="Name" required>
        <MockInput />
      </FormField>
    );
    expect(screen.getByText("*")).toBeInTheDocument();
  });

  it("shows error message", () => {
    render(
      <FormField label="Email" error="Invalid email">
        <MockInput />
      </FormField>
    );
    expect(screen.getByRole("alert")).toHaveTextContent("Invalid email");
  });

  it("shows helper text when no error", () => {
    render(
      <FormField label="Email" helperText="We won't share your email">
        <MockInput />
      </FormField>
    );
    expect(screen.getByText("We won't share your email")).toBeInTheDocument();
  });

  it("hides helper text when error present", () => {
    render(
      <FormField label="Email" error="Required" helperText="Helper">
        <MockInput />
      </FormField>
    );
    expect(screen.queryByText("Helper")).not.toBeInTheDocument();
    expect(screen.getByRole("alert")).toHaveTextContent("Required");
  });

  it("injects id into child", () => {
    render(
      <FormField label="Email" htmlFor="email-field">
        <MockInput />
      </FormField>
    );
    expect(screen.getByRole("textbox")).toHaveAttribute("id", "email-field");
  });

  it("links label to child via htmlFor", () => {
    render(
      <FormField label="Email" htmlFor="my-input">
        <MockInput />
      </FormField>
    );
    expect(screen.getByText("Email")).toHaveAttribute("for", "my-input");
  });

  it("injects aria-invalid on child when error", () => {
    render(
      <FormField label="Email" error="Bad">
        <MockInput />
      </FormField>
    );
    expect(screen.getByRole("textbox")).toHaveAttribute("aria-invalid", "true");
  });

  it("injects aria-describedby linking error message", () => {
    render(
      <FormField label="Email" htmlFor="em" error="Required">
        <MockInput />
      </FormField>
    );
    const input = screen.getByRole("textbox");
    const describedBy = input.getAttribute("aria-describedby") ?? "";
    expect(describedBy).toContain("error");
  });

  it("injects aria-describedby linking helper text", () => {
    render(
      <FormField label="Email" htmlFor="em" helperText="Help">
        <MockInput />
      </FormField>
    );
    const input = screen.getByRole("textbox");
    const describedBy = input.getAttribute("aria-describedby") ?? "";
    expect(describedBy).toContain("helper");
  });

  it("injects aria-required on child when required", () => {
    render(
      <FormField label="Name" required>
        <MockInput />
      </FormField>
    );
    expect(screen.getByRole("textbox")).toHaveAttribute("aria-required", "true");
  });

  it("injects disabled on child when disabled", () => {
    render(
      <FormField label="Name" disabled>
        <MockInput />
      </FormField>
    );
    expect(screen.getByRole("textbox")).toBeDisabled();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <FormField ref={ref} label="Name">
        <MockInput />
      </FormField>
    );
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("has correct displayName", () => {
    expect(FormField.displayName).toBe("FormField");
  });

  it("auto-generates id when htmlFor not provided", () => {
    render(
      <FormField label="Auto">
        <MockInput />
      </FormField>
    );
    const input = screen.getByRole("textbox");
    expect(input.getAttribute("id")).toBeTruthy();
  });
});
