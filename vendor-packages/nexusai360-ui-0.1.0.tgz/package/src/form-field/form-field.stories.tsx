import { FormField } from "./index";

export default { title: "Primitives/FormField" };

const MockInput = (props: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input
    className="h-10 w-full rounded-md border border-zinc-700 bg-zinc-950 px-3 text-zinc-100"
    {...props}
  />
);

export const Default = () => (
  <FormField label="Email">
    <MockInput placeholder="you@example.com" />
  </FormField>
);

export const Required = () => (
  <FormField label="Full name" required>
    <MockInput placeholder="John Doe" />
  </FormField>
);

export const WithError = () => (
  <FormField label="Email" error="Invalid email address" required>
    <MockInput placeholder="you@example.com" />
  </FormField>
);

export const WithHelper = () => (
  <FormField label="Password" helperText="Must be at least 8 characters">
    <MockInput type="password" placeholder="********" />
  </FormField>
);

export const Disabled = () => (
  <FormField label="Username" disabled>
    <MockInput placeholder="disabled" />
  </FormField>
);
