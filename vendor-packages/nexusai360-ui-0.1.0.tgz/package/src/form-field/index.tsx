import * as React from "react";
import { cn } from "../lib/cn";
import { Label } from "../label";

export interface FormFieldProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Label text */
  label?: string;
  /** Error message */
  error?: string;
  /** Helper text displayed below the control */
  helperText?: string;
  /** Mark as required (shows asterisk on label) */
  required?: boolean;
  /** Disable the entire field (propagates to label) */
  disabled?: boolean;
  /** Explicit id — auto-generated if omitted */
  htmlFor?: string;
}

const FormField = React.forwardRef<HTMLDivElement, FormFieldProps>(
  (
    {
      className,
      label,
      error,
      helperText,
      required = false,
      disabled = false,
      htmlFor: providedId,
      children,
      ...props
    },
    ref
  ) => {
    const autoId = React.useId();
    const fieldId = providedId ?? autoId;
    const errorId = error ? `${fieldId}-error` : undefined;
    const helperId = helperText ? `${fieldId}-helper` : undefined;
    const describedBy =
      [errorId, helperId].filter(Boolean).join(" ") || undefined;

    // Clone children to inject aria props and id
    const enhancedChildren = React.Children.map(children, (child) => {
      if (!React.isValidElement(child)) return child;
      return React.cloneElement(child as React.ReactElement<Record<string, unknown>>, {
        id: fieldId,
        "aria-describedby": describedBy,
        "aria-invalid": error ? true : undefined,
        "aria-required": required || undefined,
        disabled: disabled || undefined,
      });
    });

    return (
      <div ref={ref} className={cn("flex flex-col gap-1.5", className)} {...props}>
        {label && (
          <Label htmlFor={fieldId} required={required} disabled={disabled}>
            {label}
          </Label>
        )}
        {enhancedChildren}
        {error && (
          <p id={errorId} className="text-sm text-red-500" role="alert">
            {error}
          </p>
        )}
        {helperText && !error && (
          <p id={helperId} className="text-xs text-zinc-500">
            {helperText}
          </p>
        )}
      </div>
    );
  }
);

FormField.displayName = "FormField";

export { FormField };
