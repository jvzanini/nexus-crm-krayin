import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, act, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Toaster, useToast } from "./index";
import React from "react";

/* Helper component that exposes toast controls */
function ToastController({ children }: { children?: React.ReactNode }) {
  const { toast, dismiss, clearAll, toasts } = useToast();
  return (
    <div>
      <button
        data-testid="add-default"
        onClick={() => toast({ title: "Default toast" })}
      >
        Add Default
      </button>
      <button
        data-testid="add-success"
        onClick={() =>
          toast({ title: "Success!", variant: "success", duration: 0 })
        }
      >
        Add Success
      </button>
      <button
        data-testid="add-danger"
        onClick={() =>
          toast({ title: "Error!", variant: "danger", duration: 0 })
        }
      >
        Add Danger
      </button>
      <button
        data-testid="add-custom-duration"
        onClick={() =>
          toast({ title: "Short", duration: 2000 })
        }
      >
        Add Short
      </button>
      <button data-testid="clear" onClick={clearAll}>
        Clear
      </button>
      <span data-testid="count">{toasts.length}</span>
      {children}
    </div>
  );
}

describe("Toaster", () => {
  it("renders without crashing", () => {
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    expect(screen.getByTestId("add-default")).toBeInTheDocument();
  });

  it("adds a toast on button click", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-default"));
    expect(screen.getByText("Default toast")).toBeInTheDocument();
  });

  it("renders multiple toasts", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-success"));
    await user.click(screen.getByTestId("add-danger"));
    expect(screen.getByText("Success!")).toBeInTheDocument();
    expect(screen.getByText("Error!")).toBeInTheDocument();
  });

  it("dismisses toast on dismiss button", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-success"));
    expect(screen.getByText("Success!")).toBeInTheDocument();
    const dismissBtn = screen.getAllByLabelText("Dismiss")[0];
    await user.click(dismissBtn);
    await waitFor(() =>
      expect(screen.queryByText("Success!")).not.toBeInTheDocument(),
    );
  });

  it("clears all toasts", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-success"));
    await user.click(screen.getByTestId("add-danger"));
    expect(screen.getByText("Success!")).toBeInTheDocument();
    await user.click(screen.getByTestId("clear"));
    await waitFor(() =>
      expect(screen.queryByText("Success!")).not.toBeInTheDocument(),
    );
  });

  it("respects maxVisible prop", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster maxVisible={1} />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-success"));
    await user.click(screen.getByTestId("add-danger"));
    // Only last one visible
    expect(screen.queryByText("Success!")).not.toBeInTheDocument();
    expect(screen.getByText("Error!")).toBeInTheDocument();
  });

  it("has notifications region", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-default"));
    expect(screen.getByRole("region")).toBeInTheDocument();
  });

  it("auto-dismisses toast after duration", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    const user = userEvent.setup({ advanceTimers: vi.advanceTimersByTime });
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-custom-duration"));
    expect(screen.getByText("Short")).toBeInTheDocument();
    act(() => {
      vi.advanceTimersByTime(2100);
    });
    await waitFor(() =>
      expect(screen.queryByText("Short")).not.toBeInTheDocument(),
    );
    vi.useRealTimers();
  });

  it("useToast returns toast count", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    expect(screen.getByTestId("count").textContent).toBe("0");
    await user.click(screen.getByTestId("add-success"));
    expect(screen.getByTestId("count").textContent).toBe("1");
  });

  it("Toaster has displayName", () => {
    expect(Toaster.displayName).toBe("Toaster");
  });

  it("renders in portal (document.body)", async () => {
    const user = userEvent.setup();
    render(
      <ToastController>
        <Toaster />
      </ToastController>,
    );
    await user.click(screen.getByTestId("add-default"));
    const region = screen.getByRole("region");
    // Portaled to body
    expect(region.parentElement).toBe(document.body);
  });

  it("toast returns an id", async () => {
    let returnedId: string | undefined;
    function IdChecker() {
      const { toast } = useToast();
      return (
        <button
          data-testid="check-id"
          onClick={() => {
            returnedId = toast({ title: "ID test" });
          }}
        >
          Go
        </button>
      );
    }
    const user = userEvent.setup();
    render(
      <>
        <IdChecker />
        <Toaster />
      </>,
    );
    await user.click(screen.getByTestId("check-id"));
    expect(returnedId).toBeDefined();
    expect(typeof returnedId).toBe("string");
  });
});
