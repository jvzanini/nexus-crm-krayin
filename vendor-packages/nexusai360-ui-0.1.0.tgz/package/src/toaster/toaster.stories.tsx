import { Toaster, useToast } from "./index";

export default { title: "Overlays/Toaster" };

const ToasterDemo = () => {
  const { toast } = useToast();
  return (
    <>
      <div style={{ display: "flex", gap: 8 }}>
        <button
          className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm"
          onClick={() => toast({ title: "Default toast", description: "Hello!" })}
        >
          Default
        </button>
        <button
          className="px-3 py-2 rounded-lg bg-emerald-600 text-white text-sm"
          onClick={() => toast({ title: "Success", variant: "success" })}
        >
          Success
        </button>
        <button
          className="px-3 py-2 rounded-lg bg-red-600 text-white text-sm"
          onClick={() => toast({ title: "Error", variant: "danger", description: "Something failed." })}
        >
          Danger
        </button>
      </div>
      <Toaster />
    </>
  );
};

export const Default = () => <ToasterDemo />;
