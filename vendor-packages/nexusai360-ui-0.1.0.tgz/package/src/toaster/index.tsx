import * as React from "react";
import { createPortal } from "react-dom";
import { cn } from "../lib/cn";
import { Toast, type ToastProps } from "../toast";

/* ------------------------------------------------------------------ */
/*  Toast state                                                        */
/* ------------------------------------------------------------------ */
export interface ToastItem {
  id: string;
  title?: string;
  description?: string;
  variant?: ToastProps["variant"];
  duration?: number;
  action?: React.ReactNode;
}

type ToastAction =
  | { type: "ADD"; toast: ToastItem }
  | { type: "REMOVE"; id: string }
  | { type: "CLEAR" };

function toastReducer(state: ToastItem[], action: ToastAction): ToastItem[] {
  switch (action.type) {
    case "ADD":
      return [...state, action.toast];
    case "REMOVE":
      return state.filter((t) => t.id !== action.id);
    case "CLEAR":
      return [];
    default:
      return state;
  }
}

let toastCount = 0;

/* ------------------------------------------------------------------ */
/*  Global dispatch (singleton pattern)                                */
/* ------------------------------------------------------------------ */
type DispatchFn = (action: ToastAction) => void;
const listeners = new Set<DispatchFn>();

function dispatch(action: ToastAction) {
  listeners.forEach((fn) => fn(action));
}

/* ------------------------------------------------------------------ */
/*  useToast hook                                                      */
/* ------------------------------------------------------------------ */
export function useToast() {
  const [toasts, _dispatch] = React.useReducer(toastReducer, []);

  React.useEffect(() => {
    listeners.add(_dispatch);
    return () => {
      listeners.delete(_dispatch);
    };
  }, []);

  const toast = React.useCallback(
    (props: Omit<ToastItem, "id">) => {
      const id = String(++toastCount);
      dispatch({ type: "ADD", toast: { id, ...props } });
      return id;
    },
    [],
  );

  const dismiss = React.useCallback((id: string) => {
    dispatch({ type: "REMOVE", id });
  }, []);

  const clearAll = React.useCallback(() => {
    dispatch({ type: "CLEAR" });
  }, []);

  return { toasts, toast, dismiss, clearAll };
}

/* ------------------------------------------------------------------ */
/*  Toaster component                                                  */
/* ------------------------------------------------------------------ */
export interface ToasterProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Maximum visible toasts (default 5) */
  maxVisible?: number;
}

const Toaster: React.FC<ToasterProps> = ({
  className,
  maxVisible = 5,
  ...props
}) => {
  const { toasts, dismiss } = useToast();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  const visible = toasts.slice(-maxVisible);

  const content = (
    <div
      className={cn(
        "fixed bottom-4 right-4 z-[100] flex flex-col gap-2 w-full max-w-sm",
        className,
      )}
      role="region"
      aria-label="Notifications"
      {...props}
    >
      {visible.map((t) => (
        <Toast
          key={t.id}
          variant={t.variant}
          title={t.title}
          description={t.description}
          action={t.action}
          duration={t.duration}
          onDismiss={() => dismiss(t.id)}
        />
      ))}
    </div>
  );

  return createPortal(content, document.body);
};

Toaster.displayName = "Toaster";

export { Toaster };
