import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { EmptyState } from "./index";

describe("EmptyState", () => {
  it("renders title", () => {
    render(<EmptyState title="No results" />);
    expect(screen.getByText("No results")).toBeInTheDocument();
  });

  it("renders description", () => {
    render(<EmptyState title="No results" description="Try adjusting your filters" />);
    expect(screen.getByText("Try adjusting your filters")).toBeInTheDocument();
  });

  it("renders without description", () => {
    render(<EmptyState title="Empty" />);
    expect(screen.getByText("Empty")).toBeInTheDocument();
    expect(screen.queryByText("undefined")).not.toBeInTheDocument();
  });

  it("renders icon", () => {
    render(
      <EmptyState
        title="No data"
        icon={<svg data-testid="empty-icon" />}
      />
    );
    expect(screen.getByTestId("empty-icon")).toBeInTheDocument();
  });

  it("renders without icon", () => {
    const { container } = render(<EmptyState title="No data" />);
    expect(container.querySelector("svg")).not.toBeInTheDocument();
  });

  it("renders action", () => {
    render(
      <EmptyState
        title="No items"
        action={<button>Create one</button>}
      />
    );
    expect(screen.getByText("Create one")).toBeInTheDocument();
  });

  it("renders without action", () => {
    render(<EmptyState title="No items" />);
    expect(screen.queryByRole("button")).not.toBeInTheDocument();
  });

  it("renders with custom icon element", () => {
    render(
      <EmptyState
        title="Custom"
        icon={<span data-testid="custom-icon">📦</span>}
      />
    );
    expect(screen.getByTestId("custom-icon")).toBeInTheDocument();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLDivElement>();
    render(<EmptyState ref={ref} title="Ref test" />);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  it("merges custom className", () => {
    const { container } = render(
      <EmptyState title="Custom" className="my-empty" />
    );
    expect(container.firstElementChild!.className).toContain("my-empty");
  });

  it("has correct displayName", () => {
    expect(EmptyState.displayName).toBe("EmptyState");
  });
});
