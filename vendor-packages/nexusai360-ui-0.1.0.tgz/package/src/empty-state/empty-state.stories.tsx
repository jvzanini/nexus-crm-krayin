import { EmptyState } from "./index";

export default { title: "DataDisplay/EmptyState" };

export const Default = () => (
  <EmptyState
    title="No items yet"
    description="Create your first item to get started."
    action={<button className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm">Create Item</button>}
  />
);

export const WithIcon = () => (
  <EmptyState
    icon={<span className="text-4xl">📦</span>}
    title="No packages found"
    description="Try adjusting your search filters."
  />
);

export const Minimal = () => (
  <EmptyState title="Nothing here" />
);
