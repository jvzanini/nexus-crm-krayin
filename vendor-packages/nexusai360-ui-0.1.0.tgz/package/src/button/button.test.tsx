import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Button } from "./index";

describe("Button", () => {
  // --- Render ---
  it("renders with default variant and size", () => {
    render(<Button>Click me</Button>);
    const btn = screen.getByRole("button", { name: "Click me" });
    expect(btn).toBeInTheDocument();
  });

  it("renders children text", () => {
    render(<Button>Save</Button>);
    expect(screen.getByText("Save")).toBeInTheDocument();
  });

  // --- Variants ---
  it("applies primary variant classes", () => {
    render(<Button variant="primary">Primary</Button>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("from-violet-600");
  });

  it("applies secondary variant classes", () => {
    render(<Button variant="secondary">Secondary</Button>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("bg-zinc-800");
  });

  it("applies ghost variant classes", () => {
    render(<Button variant="ghost">Ghost</Button>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("bg-transparent");
  });

  it("applies danger variant classes", () => {
    render(<Button variant="danger">Danger</Button>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("bg-red-600");
  });

  it("applies outline variant classes", () => {
    render(<Button variant="outline">Outline</Button>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("border-zinc-700");
  });

  it("applies link variant classes", () => {
    render(<Button variant="link">Link</Button>);
    const btn = screen.getByRole("button");
    expect(btn.className).toContain("underline-offset-4");
  });

  // --- Sizes ---
  it("applies sm size", () => {
    render(<Button size="sm">Small</Button>);
    expect(screen.getByRole("button").className).toContain("h-8");
  });

  it("applies md size (default)", () => {
    render(<Button size="md">Medium</Button>);
    expect(screen.getByRole("button").className).toContain("h-10");
  });

  it("applies lg size", () => {
    render(<Button size="lg">Large</Button>);
    expect(screen.getByRole("button").className).toContain("h-12");
  });

  // --- Disabled ---
  it("disables the button when disabled prop is true", () => {
    render(<Button disabled>Disabled</Button>);
    const btn = screen.getByRole("button");
    expect(btn).toBeDisabled();
    expect(btn).toHaveAttribute("aria-disabled", "true");
  });

  // --- Loading ---
  it("shows spinner and sets aria-busy when loading", () => {
    render(<Button loading>Loading</Button>);
    const btn = screen.getByRole("button");
    expect(btn).toHaveAttribute("aria-busy", "true");
    expect(btn).toBeDisabled();
    // spinner SVG present
    expect(btn.querySelector("svg")).toBeInTheDocument();
  });

  it("hides leftIcon and rightIcon when loading", () => {
    const LeftIcon = () => <span data-testid="left">L</span>;
    const RightIcon = () => <span data-testid="right">R</span>;
    render(
      <Button loading leftIcon={<LeftIcon />} rightIcon={<RightIcon />}>
        Go
      </Button>
    );
    expect(screen.queryByTestId("left")).not.toBeInTheDocument();
    expect(screen.queryByTestId("right")).not.toBeInTheDocument();
  });

  // --- Icons ---
  it("renders leftIcon", () => {
    render(<Button leftIcon={<span data-testid="icon">→</span>}>Go</Button>);
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  it("renders rightIcon", () => {
    render(<Button rightIcon={<span data-testid="icon">←</span>}>Back</Button>);
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  // --- Click handler ---
  it("calls onClick handler", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(<Button onClick={onClick}>Click</Button>);
    await user.click(screen.getByRole("button"));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it("does not call onClick when disabled", async () => {
    const user = userEvent.setup();
    const onClick = vi.fn();
    render(<Button disabled onClick={onClick}>Click</Button>);
    await user.click(screen.getByRole("button"));
    expect(onClick).not.toHaveBeenCalled();
  });

  // --- Keyboard ---
  it("activates on Enter key", () => {
    const onClick = vi.fn();
    render(<Button onClick={onClick}>Enter</Button>);
    fireEvent.keyDown(screen.getByRole("button"), { key: "Enter" });
    // native buttons handle Enter
  });

  it("activates on Space key", () => {
    const onClick = vi.fn();
    render(<Button onClick={onClick}>Space</Button>);
    fireEvent.keyDown(screen.getByRole("button"), { key: " " });
  });

  // --- Ref forwarding ---
  it("forwards ref to button element", () => {
    const ref = createRef<HTMLButtonElement>();
    render(<Button ref={ref}>Ref</Button>);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  // --- asChild ---
  it("renders as child element when asChild is true", () => {
    render(
      <Button asChild variant="primary">
        <a href="/test">Link Button</a>
      </Button>
    );
    const link = screen.getByText("Link Button");
    expect(link.tagName).toBe("A");
    expect(link.className).toContain("from-violet-600");
  });

  // --- Custom className ---
  it("merges custom className", () => {
    render(<Button className="my-custom">Custom</Button>);
    expect(screen.getByRole("button").className).toContain("my-custom");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(Button.displayName).toBe("Button");
  });
});
