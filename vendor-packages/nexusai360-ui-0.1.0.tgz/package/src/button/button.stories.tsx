import { Button } from "./index";

export default { title: "Primitives/Button" };

export const Primary = () => <Button variant="primary">Primary</Button>;
export const Secondary = () => <Button variant="secondary">Secondary</Button>;
export const Ghost = () => <Button variant="ghost">Ghost</Button>;
export const Danger = () => <Button variant="danger">Danger</Button>;
export const Outline = () => <Button variant="outline">Outline</Button>;
export const Link = () => <Button variant="link">Link</Button>;

export const Small = () => <Button size="sm">Small</Button>;
export const Medium = () => <Button size="md">Medium</Button>;
export const Large = () => <Button size="lg">Large</Button>;

export const Loading = () => <Button loading>Loading...</Button>;
export const Disabled = () => <Button disabled>Disabled</Button>;

export const WithIcons = () => (
  <div style={{ display: "flex", gap: 8 }}>
    <Button leftIcon={<span>←</span>}>Back</Button>
    <Button rightIcon={<span>→</span>}>Next</Button>
  </div>
);

export const AsChild = () => (
  <Button asChild variant="primary">
    <a href="#">Link as Button</a>
  </Button>
);
