import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

/* ------------------------------------------------------------------ */
/*  Variants                                                           */
/* ------------------------------------------------------------------ */
const navLinkVariants = cva(
  [
    "group inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
    "outline-none focus-visible:ring-2 focus-visible:ring-violet-500/50",
  ].join(" "),
  {
    variants: {
      active: {
        true: "bg-zinc-800 text-zinc-100",
        false: "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200",
      },
      disabled: {
        true: "pointer-events-none opacity-50",
        false: "",
      },
    },
    defaultVariants: { active: false, disabled: false },
  },
);

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface NavLinkProps
  extends Omit<React.AnchorHTMLAttributes<HTMLAnchorElement>, "className">,
    VariantProps<typeof navLinkVariants> {
  className?: string;
  /** Navigation target */
  href: string;
  /** Icon rendered before label */
  icon?: React.ReactNode;
  /** Text label */
  label: string;
  /** Optional trailing badge */
  badge?: React.ReactNode;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const NavLink = React.forwardRef<HTMLAnchorElement, NavLinkProps>(
  ({ className, active, disabled, href, icon, label, badge, ...props }, ref) => (
    <a
      ref={ref}
      href={disabled ? undefined : href}
      aria-current={active ? "page" : undefined}
      aria-disabled={disabled || undefined}
      tabIndex={disabled ? -1 : undefined}
      className={cn(navLinkVariants({ active, disabled }), className)}
      {...props}
    >
      {icon && <span className="shrink-0 [&_svg]:size-5">{icon}</span>}
      <span className="truncate">{label}</span>
      {badge && <span className="ml-auto shrink-0">{badge}</span>}
    </a>
  ),
);

NavLink.displayName = "NavLink";

export { NavLink, navLinkVariants };
