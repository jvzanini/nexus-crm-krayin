import { NavLink } from "./index";

export default { title: "Navigation/NavLink" };

export const Default = () => (
  <div className="flex flex-col gap-1 w-60">
    <NavLink href="#" label="Dashboard" active />
    <NavLink href="#" label="Contacts" />
    <NavLink href="#" label="Companies" />
    <NavLink href="#" label="Disabled" disabled />
  </div>
);

export const WithIcon = () => (
  <div className="flex flex-col gap-1 w-60">
    <NavLink href="#" label="Home" icon={<span>🏠</span>} active />
    <NavLink href="#" label="Settings" icon={<span>⚙️</span>} />
  </div>
);

export const WithBadge = () => (
  <NavLink
    href="#"
    label="Notifications"
    badge={<span className="text-xs bg-red-600 text-white rounded-full px-1.5">3</span>}
  />
);
