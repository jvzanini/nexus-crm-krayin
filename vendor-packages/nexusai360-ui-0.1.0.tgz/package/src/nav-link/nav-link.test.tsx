import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { createRef } from "react";
import { NavLink } from "./index";

describe("NavLink", () => {
  // --- Render ---
  it("renders as anchor with label", () => {
    render(<NavLink href="/dashboard" label="Dashboard" />);
    const link = screen.getByText("Dashboard");
    expect(link.closest("a")).toHaveAttribute("href", "/dashboard");
  });

  it("renders label text", () => {
    render(<NavLink href="/" label="Home" />);
    expect(screen.getByText("Home")).toBeInTheDocument();
  });

  // --- Active ---
  it("applies active classes", () => {
    render(<NavLink href="/" label="Home" active />);
    const el = screen.getByText("Home").closest("a")!;
    expect(el.className).toContain("bg-zinc-800");
  });

  it("sets aria-current when active", () => {
    render(<NavLink href="/" label="Home" active />);
    expect(screen.getByText("Home").closest("a")).toHaveAttribute("aria-current", "page");
  });

  it("does not set aria-current when inactive", () => {
    render(<NavLink href="/" label="Home" />);
    expect(screen.getByText("Home").closest("a")).not.toHaveAttribute("aria-current");
  });

  // --- Disabled ---
  it("applies disabled classes", () => {
    render(<NavLink href="/" label="Disabled" disabled />);
    const el = screen.getByText("Disabled").closest("a")!;
    expect(el.className).toContain("opacity-50");
  });

  it("sets aria-disabled when disabled", () => {
    render(<NavLink href="/" label="Disabled" disabled />);
    expect(screen.getByText("Disabled").closest("a")).toHaveAttribute("aria-disabled", "true");
  });

  it("removes href when disabled", () => {
    render(<NavLink href="/secret" label="Secret" disabled />);
    expect(screen.getByText("Secret").closest("a")).not.toHaveAttribute("href");
  });

  // --- Icon ---
  it("renders icon", () => {
    render(<NavLink href="/" label="Home" icon={<span data-testid="icon">★</span>} />);
    expect(screen.getByTestId("icon")).toBeInTheDocument();
  });

  // --- Badge ---
  it("renders badge", () => {
    render(<NavLink href="/" label="Inbox" badge={<span data-testid="badge">5</span>} />);
    expect(screen.getByTestId("badge")).toBeInTheDocument();
  });

  // --- Ref ---
  it("forwards ref", () => {
    const ref = createRef<HTMLAnchorElement>();
    render(<NavLink ref={ref} href="/" label="Ref" />);
    expect(ref.current).toBeInstanceOf(HTMLAnchorElement);
  });

  // --- className ---
  it("merges custom className", () => {
    render(<NavLink href="/" label="Custom" className="my-nav" />);
    expect(screen.getByText("Custom").closest("a")!.className).toContain("my-nav");
  });

  // --- displayName ---
  it("has correct displayName", () => {
    expect(NavLink.displayName).toBe("NavLink");
  });
});
