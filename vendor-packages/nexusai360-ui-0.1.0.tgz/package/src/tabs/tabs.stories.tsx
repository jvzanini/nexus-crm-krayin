import { Tabs, TabsList, TabsTrigger, TabsContent } from "./index";

export default { title: "DataDisplay/Tabs" };

export const Default = () => (
  <Tabs defaultValue="account" className="w-96">
    <TabsList>
      <TabsTrigger value="account">Account</TabsTrigger>
      <TabsTrigger value="password">Password</TabsTrigger>
      <TabsTrigger value="team">Team</TabsTrigger>
    </TabsList>
    <TabsContent value="account">
      <p className="text-sm text-zinc-300 p-4">Account settings content.</p>
    </TabsContent>
    <TabsContent value="password">
      <p className="text-sm text-zinc-300 p-4">Password settings content.</p>
    </TabsContent>
    <TabsContent value="team">
      <p className="text-sm text-zinc-300 p-4">Team management content.</p>
    </TabsContent>
  </Tabs>
);
