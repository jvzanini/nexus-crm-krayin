import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./index";

const renderTabs = (defaultValue = "tab1") =>
  render(
    <Tabs defaultValue={defaultValue}>
      <TabsList>
        <TabsTrigger value="tab1">Tab 1</TabsTrigger>
        <TabsTrigger value="tab2">Tab 2</TabsTrigger>
        <TabsTrigger value="tab3" disabled>Tab 3</TabsTrigger>
      </TabsList>
      <TabsContent value="tab1">Content 1</TabsContent>
      <TabsContent value="tab2">Content 2</TabsContent>
      <TabsContent value="tab3">Content 3</TabsContent>
    </Tabs>
  );

describe("Tabs", () => {
  it("renders tablist", () => {
    renderTabs();
    expect(screen.getByRole("tablist")).toBeInTheDocument();
  });

  it("renders tab triggers", () => {
    renderTabs();
    expect(screen.getByRole("tab", { name: "Tab 1" })).toBeInTheDocument();
    expect(screen.getByRole("tab", { name: "Tab 2" })).toBeInTheDocument();
  });

  it("shows default tab content", () => {
    renderTabs("tab1");
    expect(screen.getByText("Content 1")).toBeInTheDocument();
  });

  it("switches tab on click", async () => {
    const user = userEvent.setup();
    renderTabs("tab1");
    await user.click(screen.getByRole("tab", { name: "Tab 2" }));
    expect(screen.getByText("Content 2")).toBeInTheDocument();
  });

  it("switches tab via keyboard (ArrowRight)", async () => {
    const user = userEvent.setup();
    renderTabs("tab1");
    const tab1 = screen.getByRole("tab", { name: "Tab 1" });
    tab1.focus();
    await user.keyboard("{ArrowRight}");
    expect(screen.getByRole("tab", { name: "Tab 2" })).toHaveFocus();
  });

  it("switches tab via keyboard (ArrowLeft)", async () => {
    const user = userEvent.setup();
    renderTabs("tab2");
    const tab2 = screen.getByRole("tab", { name: "Tab 2" });
    tab2.focus();
    await user.keyboard("{ArrowLeft}");
    expect(screen.getByRole("tab", { name: "Tab 1" })).toHaveFocus();
  });

  it("renders disabled tab", () => {
    renderTabs();
    const disabledTab = screen.getByRole("tab", { name: "Tab 3" });
    expect(disabledTab).toBeDisabled();
  });

  it("renders tabpanel", () => {
    renderTabs();
    expect(screen.getByRole("tabpanel")).toBeInTheDocument();
  });

  it("active tab has data-state=active", () => {
    renderTabs("tab1");
    const tab1 = screen.getByRole("tab", { name: "Tab 1" });
    expect(tab1).toHaveAttribute("data-state", "active");
  });

  it("inactive tab has data-state=inactive", () => {
    renderTabs("tab1");
    const tab2 = screen.getByRole("tab", { name: "Tab 2" });
    expect(tab2).toHaveAttribute("data-state", "inactive");
  });

  it("forwards ref on TabsList", () => {
    const ref = createRef<HTMLDivElement>();
    render(
      <Tabs defaultValue="a">
        <TabsList ref={ref}>
          <TabsTrigger value="a">A</TabsTrigger>
        </TabsList>
        <TabsContent value="a">A content</TabsContent>
      </Tabs>
    );
    expect(ref.current).toBeInstanceOf(HTMLElement);
  });

  it("has correct displayNames", () => {
    expect(TabsList.displayName).toBe("TabsList");
    expect(TabsTrigger.displayName).toBe("TabsTrigger");
    expect(TabsContent.displayName).toBe("TabsContent");
  });

  it("merges custom className on TabsList", () => {
    render(
      <Tabs defaultValue="a">
        <TabsList className="my-list">
          <TabsTrigger value="a">A</TabsTrigger>
        </TabsList>
        <TabsContent value="a">A</TabsContent>
      </Tabs>
    );
    expect(screen.getByRole("tablist").className).toContain("my-list");
  });
});
