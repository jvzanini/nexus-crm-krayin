import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

/* ================================================================== */
/*  Sidebar Root                                                       */
/* ================================================================== */
export interface SidebarProps extends React.HTMLAttributes<HTMLElement> {
  /** Whether the sidebar is collapsed */
  collapsed?: boolean;
  /** Collapse toggle callback */
  onCollapsedChange?: (collapsed: boolean) => void;
}

interface SidebarContextValue {
  collapsed: boolean;
  toggle: () => void;
}

const SidebarContext = React.createContext<SidebarContextValue>({
  collapsed: false,
  toggle: () => {},
});

export const useSidebar = () => React.useContext(SidebarContext);

const Sidebar = React.forwardRef<HTMLElement, SidebarProps>(
  (
    { className, collapsed: controlledCollapsed, onCollapsedChange, children, ...props },
    ref,
  ) => {
    const [internalCollapsed, setInternalCollapsed] = React.useState(false);
    const collapsed = controlledCollapsed ?? internalCollapsed;

    const toggle = React.useCallback(() => {
      const next = !collapsed;
      setInternalCollapsed(next);
      onCollapsedChange?.(next);
    }, [collapsed, onCollapsedChange]);

    const ctx = React.useMemo(
      () => ({ collapsed, toggle }),
      [collapsed, toggle],
    );

    return (
      <SidebarContext.Provider value={ctx}>
        <aside
          ref={ref}
          data-collapsed={collapsed || undefined}
          className={cn(
            "flex h-full flex-col border-r border-zinc-800 bg-zinc-950 transition-[width] duration-200",
            collapsed ? "w-16" : "w-64",
            className,
          )}
          {...props}
        >
          {children}
        </aside>
      </SidebarContext.Provider>
    );
  },
);
Sidebar.displayName = "Sidebar";

/* ================================================================== */
/*  SidebarHeader                                                      */
/* ================================================================== */
export interface SidebarHeaderProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarHeader = React.forwardRef<HTMLDivElement, SidebarHeaderProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("flex items-center gap-2 px-4 py-3 border-b border-zinc-800", className)}
      {...props}
    />
  ),
);
SidebarHeader.displayName = "SidebarHeader";

/* ================================================================== */
/*  SidebarContent                                                     */
/* ================================================================== */
export interface SidebarContentProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarContent = React.forwardRef<HTMLDivElement, SidebarContentProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("flex-1 overflow-y-auto px-2 py-2 space-y-4", className)}
      {...props}
    />
  ),
);
SidebarContent.displayName = "SidebarContent";

/* ================================================================== */
/*  SidebarFooter                                                      */
/* ================================================================== */
export interface SidebarFooterProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarFooter = React.forwardRef<HTMLDivElement, SidebarFooterProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      className={cn("border-t border-zinc-800 px-4 py-3", className)}
      {...props}
    />
  ),
);
SidebarFooter.displayName = "SidebarFooter";

/* ================================================================== */
/*  SidebarGroup                                                       */
/* ================================================================== */
export interface SidebarGroupProps extends React.HTMLAttributes<HTMLDivElement> {}

const SidebarGroup = React.forwardRef<HTMLDivElement, SidebarGroupProps>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      role="group"
      className={cn("space-y-1", className)}
      {...props}
    />
  ),
);
SidebarGroup.displayName = "SidebarGroup";

/* ================================================================== */
/*  SidebarGroupLabel                                                  */
/* ================================================================== */
export interface SidebarGroupLabelProps
  extends React.HTMLAttributes<HTMLSpanElement> {}

const SidebarGroupLabel = React.forwardRef<
  HTMLSpanElement,
  SidebarGroupLabelProps
>(({ className, ...props }, ref) => {
  const { collapsed } = useSidebar();
  if (collapsed) return null;
  return (
    <span
      ref={ref}
      className={cn(
        "block px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-zinc-500",
        className,
      )}
      {...props}
    />
  );
});
SidebarGroupLabel.displayName = "SidebarGroupLabel";

/* ================================================================== */
/*  SidebarItem                                                        */
/* ================================================================== */
const sidebarItemVariants = cva(
  [
    "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors cursor-pointer",
    "outline-none focus-visible:ring-2 focus-visible:ring-violet-500/50",
  ].join(" "),
  {
    variants: {
      active: {
        true: "bg-violet-600/15 text-violet-400",
        false: "text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100",
      },
    },
    defaultVariants: { active: false },
  },
);

export interface SidebarItemProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof sidebarItemVariants> {}

const SidebarItem = React.forwardRef<HTMLDivElement, SidebarItemProps>(
  ({ className, active, ...props }, ref) => (
    <div
      ref={ref}
      data-active={active || undefined}
      className={cn(sidebarItemVariants({ active }), className)}
      {...props}
    />
  ),
);
SidebarItem.displayName = "SidebarItem";

/* ================================================================== */
/*  SidebarSeparator                                                   */
/* ================================================================== */
export interface SidebarSeparatorProps
  extends React.HTMLAttributes<HTMLHRElement> {}

const SidebarSeparator = React.forwardRef<
  HTMLHRElement,
  SidebarSeparatorProps
>(({ className, ...props }, ref) => (
  <hr
    ref={ref}
    className={cn("border-zinc-800 my-2", className)}
    {...props}
  />
));
SidebarSeparator.displayName = "SidebarSeparator";

/* ================================================================== */
/*  Exports                                                            */
/* ================================================================== */
export {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarItem,
  SidebarSeparator,
  sidebarItemVariants,
};
