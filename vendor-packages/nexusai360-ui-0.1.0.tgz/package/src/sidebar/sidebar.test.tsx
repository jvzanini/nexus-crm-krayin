import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { createRef } from "react";
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarItem,
  SidebarSeparator,
  useSidebar,
} from "./index";

describe("Sidebar", () => {
  const renderFull = (collapsed = false) =>
    render(
      <Sidebar collapsed={collapsed}>
        <SidebarHeader>Header</SidebarHeader>
        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Group 1</SidebarGroupLabel>
            <SidebarItem>Item A</SidebarItem>
            <SidebarItem active>Item B</SidebarItem>
          </SidebarGroup>
          <SidebarSeparator />
          <SidebarGroup>
            <SidebarGroupLabel>Group 2</SidebarGroupLabel>
            <SidebarItem>Item C</SidebarItem>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter>Footer</SidebarFooter>
      </Sidebar>,
    );

  // --- Render ---
  it("renders as aside element", () => {
    const { container } = renderFull();
    expect(container.querySelector("aside")).toBeInTheDocument();
  });

  it("renders header", () => {
    renderFull();
    expect(screen.getByText("Header")).toBeInTheDocument();
  });

  it("renders footer", () => {
    renderFull();
    expect(screen.getByText("Footer")).toBeInTheDocument();
  });

  it("renders items", () => {
    renderFull();
    expect(screen.getByText("Item A")).toBeInTheDocument();
    expect(screen.getByText("Item B")).toBeInTheDocument();
    expect(screen.getByText("Item C")).toBeInTheDocument();
  });

  // --- Active state ---
  it("applies active variant on SidebarItem", () => {
    renderFull();
    const active = screen.getByText("Item B").closest("div")!;
    expect(active.className).toContain("text-violet-400");
    expect(active).toHaveAttribute("data-active", "true");
  });

  it("inactive item does not have data-active", () => {
    renderFull();
    const inactive = screen.getByText("Item A").closest("div")!;
    expect(inactive).not.toHaveAttribute("data-active");
  });

  // --- Groups ---
  it("renders group labels", () => {
    renderFull();
    expect(screen.getByText("Group 1")).toBeInTheDocument();
    expect(screen.getByText("Group 2")).toBeInTheDocument();
  });

  it("renders groups with role=group", () => {
    renderFull();
    const groups = screen.getAllByRole("group");
    expect(groups.length).toBeGreaterThanOrEqual(2);
  });

  // --- Separator ---
  it("renders separator", () => {
    const { container } = renderFull();
    expect(container.querySelector("hr")).toBeInTheDocument();
  });

  // --- Collapse ---
  it("applies collapsed width", () => {
    const { container } = renderFull(true);
    const aside = container.querySelector("aside")!;
    expect(aside.className).toContain("w-16");
  });

  it("applies expanded width", () => {
    const { container } = renderFull(false);
    const aside = container.querySelector("aside")!;
    expect(aside.className).toContain("w-64");
  });

  it("sets data-collapsed when collapsed", () => {
    const { container } = renderFull(true);
    expect(container.querySelector("aside")).toHaveAttribute("data-collapsed", "true");
  });

  it("hides group labels when collapsed", () => {
    renderFull(true);
    expect(screen.queryByText("Group 1")).not.toBeInTheDocument();
  });

  // --- Controlled collapse ---
  it("calls onCollapsedChange", () => {
    const onCollapsedChange = vi.fn();
    const ToggleSidebar = () => {
      const { toggle } = useSidebar();
      return <button onClick={toggle}>Toggle</button>;
    };
    render(
      <Sidebar onCollapsedChange={onCollapsedChange}>
        <ToggleSidebar />
      </Sidebar>,
    );
    fireEvent.click(screen.getByText("Toggle"));
    expect(onCollapsedChange).toHaveBeenCalledWith(true);
  });

  // --- Refs ---
  it("forwards ref on Sidebar", () => {
    const ref = createRef<HTMLElement>();
    render(<Sidebar ref={ref} />);
    expect(ref.current).toBeInstanceOf(HTMLElement);
  });

  it("forwards ref on SidebarHeader", () => {
    const ref = createRef<HTMLDivElement>();
    render(<Sidebar><SidebarHeader ref={ref}>H</SidebarHeader></Sidebar>);
    expect(ref.current).toBeInstanceOf(HTMLDivElement);
  });

  // --- displayNames ---
  it("has correct displayNames", () => {
    expect(Sidebar.displayName).toBe("Sidebar");
    expect(SidebarHeader.displayName).toBe("SidebarHeader");
    expect(SidebarContent.displayName).toBe("SidebarContent");
    expect(SidebarFooter.displayName).toBe("SidebarFooter");
    expect(SidebarGroup.displayName).toBe("SidebarGroup");
    expect(SidebarGroupLabel.displayName).toBe("SidebarGroupLabel");
    expect(SidebarItem.displayName).toBe("SidebarItem");
    expect(SidebarSeparator.displayName).toBe("SidebarSeparator");
  });

  // --- className ---
  it("merges custom className on Sidebar", () => {
    const { container } = render(<Sidebar className="custom-sb" />);
    expect(container.querySelector("aside")!.className).toContain("custom-sb");
  });
});
