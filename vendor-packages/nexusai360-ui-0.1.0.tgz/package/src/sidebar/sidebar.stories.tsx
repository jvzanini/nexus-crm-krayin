import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarItem,
  SidebarSeparator,
} from "./index";

export default { title: "Navigation/Sidebar" };

export const Default = () => (
  <div style={{ height: 500, display: "flex" }}>
    <Sidebar>
      <SidebarHeader>
        <span className="text-lg font-bold text-zinc-100 px-2">Nexus</span>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Main</SidebarGroupLabel>
          <SidebarItem active>Dashboard</SidebarItem>
          <SidebarItem>Contacts</SidebarItem>
          <SidebarItem>Companies</SidebarItem>
        </SidebarGroup>
        <SidebarSeparator />
        <SidebarGroup>
          <SidebarGroupLabel>Settings</SidebarGroupLabel>
          <SidebarItem>Profile</SidebarItem>
          <SidebarItem>Team</SidebarItem>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter>
        <span className="text-xs text-zinc-500 px-2">v1.0.0</span>
      </SidebarFooter>
    </Sidebar>
  </div>
);
