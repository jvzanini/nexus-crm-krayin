import { describe, it, expect, vi } from "vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { BadgeSelect } from "./index";

const options = [
  { value: "red", label: "Red" },
  { value: "green", label: "Green" },
  { value: "blue", label: "Blue" },
  { value: "yellow", label: "Yellow" },
];

describe("BadgeSelect", () => {
  it("renders a combobox trigger", () => {
    render(<BadgeSelect options={options} aria-label="Colors" />);
    expect(screen.getByRole("combobox")).toBeInTheDocument();
  });

  it("shows placeholder when empty", () => {
    render(<BadgeSelect options={options} placeholder="Pick colors" aria-label="Colors" />);
    expect(screen.getByText("Pick colors")).toBeInTheDocument();
  });

  it("shows default placeholder", () => {
    render(<BadgeSelect options={options} aria-label="Colors" />);
    expect(screen.getByText("Select items...")).toBeInTheDocument();
  });

  it("renders badges for selected values", () => {
    render(<BadgeSelect options={options} value={["red", "blue"]} aria-label="Colors" />);
    expect(screen.getByText("Red")).toBeInTheDocument();
    expect(screen.getByText("Blue")).toBeInTheDocument();
  });

  it("opens dropdown on click", async () => {
    const user = userEvent.setup();
    render(<BadgeSelect options={options} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("listbox")).toBeInTheDocument();
    expect(screen.getAllByRole("option")).toHaveLength(4);
  });

  it("toggles selection on click", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BadgeSelect options={options} value={[]} onValueChange={onValueChange} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Red"));
    expect(onValueChange).toHaveBeenCalledWith(["red"]);
  });

  it("adds to selection", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BadgeSelect options={options} value={["red"]} onValueChange={onValueChange} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("Green"));
    expect(onValueChange).toHaveBeenCalledWith(["red", "green"]);
  });

  it("removes from selection via dropdown", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BadgeSelect options={options} value={["red", "green"]} onValueChange={onValueChange} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    const listbox = screen.getByRole("listbox");
    const redOption = within(listbox).getByText("Red");
    await user.click(redOption);
    expect(onValueChange).toHaveBeenCalledWith(["green"]);
  });

  it("removes badge via X button", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(<BadgeSelect options={options} value={["red", "blue"]} onValueChange={onValueChange} aria-label="Colors" />);
    await user.click(screen.getByLabelText("Remove Red"));
    expect(onValueChange).toHaveBeenCalledWith(["blue"]);
  });

  it("shows +N more when exceeding maxDisplay", () => {
    render(
      <BadgeSelect options={options} value={["red", "green", "blue"]} maxDisplay={2} aria-label="Colors" />
    );
    expect(screen.getByText("Red")).toBeInTheDocument();
    expect(screen.getByText("Green")).toBeInTheDocument();
    expect(screen.queryByText("Blue")).not.toBeInTheDocument();
    expect(screen.getByTestId("overflow-badge")).toHaveTextContent("+1 more");
  });

  it("shows correct overflow count", () => {
    render(
      <BadgeSelect options={options} value={["red", "green", "blue", "yellow"]} maxDisplay={1} aria-label="Colors" />
    );
    expect(screen.getByTestId("overflow-badge")).toHaveTextContent("+3 more");
  });

  it("clear all button removes all", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    render(
      <BadgeSelect options={options} value={["red", "blue"]} onValueChange={onValueChange} aria-label="Colors" />
    );
    await user.click(screen.getByLabelText("Clear all"));
    expect(onValueChange).toHaveBeenCalledWith([]);
  });

  it("does not show clear button when empty", () => {
    render(<BadgeSelect options={options} value={[]} aria-label="Colors" />);
    expect(screen.queryByLabelText("Clear all")).not.toBeInTheDocument();
  });

  it("disables the trigger", () => {
    render(<BadgeSelect options={options} disabled aria-label="Colors" />);
    expect(screen.getByRole("combobox")).toBeDisabled();
  });

  it("does not open when disabled", async () => {
    const user = userEvent.setup();
    render(<BadgeSelect options={options} disabled aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("marks selected options in dropdown", async () => {
    const user = userEvent.setup();
    render(<BadgeSelect options={options} value={["blue"]} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    const opts = screen.getAllByRole("option");
    const selected = opts.find((o) => o.getAttribute("aria-selected") === "true");
    expect(selected).toHaveTextContent("Blue");
  });

  it("has aria-multiselectable on listbox", async () => {
    const user = userEvent.setup();
    render(<BadgeSelect options={options} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("listbox")).toHaveAttribute("aria-multiselectable", "true");
  });

  it("closes on Escape", async () => {
    const user = userEvent.setup();
    render(<BadgeSelect options={options} aria-label="Colors" />);
    await user.click(screen.getByRole("combobox"));
    await user.keyboard("{Escape}");
    expect(screen.queryByRole("listbox")).not.toBeInTheDocument();
  });

  it("has aria-expanded states", async () => {
    const user = userEvent.setup();
    render(<BadgeSelect options={options} aria-label="Colors" />);
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "false");
    await user.click(screen.getByRole("combobox"));
    expect(screen.getByRole("combobox")).toHaveAttribute("aria-expanded", "true");
  });

  it("does not select disabled option", async () => {
    const user = userEvent.setup();
    const onValueChange = vi.fn();
    const opts = [
      { value: "a", label: "A" },
      { value: "b", label: "B", disabled: true },
    ];
    render(<BadgeSelect options={opts} value={[]} onValueChange={onValueChange} aria-label="X" />);
    await user.click(screen.getByRole("combobox"));
    await user.click(screen.getByText("B"));
    expect(onValueChange).not.toHaveBeenCalled();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLButtonElement>();
    render(<BadgeSelect ref={ref} options={options} aria-label="Colors" />);
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it("has correct displayName", () => {
    expect(BadgeSelect.displayName).toBe("BadgeSelect");
  });
});
