import * as React from "react";
import { cn } from "../lib/cn";

// --- Icons ---
const XIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M3 3L9 9M9 3L3 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const ChevronDown: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M4 6L8 10L12 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const CheckIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <path d="M2.5 6L5 8.5L9.5 3.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

// --- Types ---
export interface BadgeSelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface BadgeSelectProps {
  /** Options list */
  options: BadgeSelectOption[];
  /** Currently selected values */
  value?: string[];
  /** Callback when selection changes */
  onValueChange?: (value: string[]) => void;
  /** Placeholder when nothing selected */
  placeholder?: string;
  /** Max badges to display before "+N more" */
  maxDisplay?: number;
  /** Disable the component */
  disabled?: boolean;
  /** Additional class names */
  className?: string;
  /** Accessible name */
  "aria-label"?: string;
}

const BadgeSelect = React.forwardRef<HTMLButtonElement, BadgeSelectProps>(
  (
    {
      options,
      value = [],
      onValueChange,
      placeholder = "Select items...",
      maxDisplay = Infinity,
      disabled = false,
      className,
      "aria-label": ariaLabel,
    },
    ref
  ) => {
    const [open, setOpen] = React.useState(false);
    const triggerRef = React.useRef<HTMLButtonElement | null>(null);
    const dropdownRef = React.useRef<HTMLDivElement | null>(null);
    const listboxId = React.useId();

    const setTriggerRefs = React.useCallback(
      (node: HTMLButtonElement | null) => {
        triggerRef.current = node;
        if (typeof ref === "function") ref(node);
        else if (ref) (ref as React.MutableRefObject<HTMLButtonElement | null>).current = node;
      },
      [ref]
    );

    const selectedOptions = React.useMemo(
      () => options.filter((o) => value.includes(o.value)),
      [options, value]
    );

    const visibleBadges = selectedOptions.slice(0, maxDisplay);
    const overflowCount = Math.max(0, selectedOptions.length - maxDisplay);

    const handleOpen = React.useCallback(() => {
      if (disabled) return;
      setOpen(true);
    }, [disabled]);

    const handleClose = React.useCallback(() => {
      setOpen(false);
      triggerRef.current?.focus();
    }, []);

    const toggleOption = React.useCallback(
      (optionValue: string) => {
        const option = options.find((o) => o.value === optionValue);
        if (!option || option.disabled) return;
        const next = value.includes(optionValue)
          ? value.filter((v) => v !== optionValue)
          : [...value, optionValue];
        onValueChange?.(next);
      },
      [options, value, onValueChange]
    );

    const removeValue = React.useCallback(
      (optionValue: string, e: React.MouseEvent) => {
        e.stopPropagation();
        onValueChange?.(value.filter((v) => v !== optionValue));
      },
      [value, onValueChange]
    );

    const clearAll = React.useCallback(
      (e: React.MouseEvent) => {
        e.stopPropagation();
        onValueChange?.([]);
      },
      [onValueChange]
    );

    // Close on outside click
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: MouseEvent) => {
        if (
          !triggerRef.current?.contains(e.target as Node) &&
          !dropdownRef.current?.contains(e.target as Node)
        ) {
          handleClose();
        }
      };
      document.addEventListener("mousedown", handler);
      return () => document.removeEventListener("mousedown", handler);
    }, [open, handleClose]);

    // Close on Escape
    React.useEffect(() => {
      if (!open) return;
      const handler = (e: KeyboardEvent) => {
        if (e.key === "Escape") handleClose();
      };
      document.addEventListener("keydown", handler);
      return () => document.removeEventListener("keydown", handler);
    }, [open, handleClose]);

    return (
      <div className={cn("relative w-full", className)}>
        <button
          ref={setTriggerRefs}
          type="button"
          role="combobox"
          aria-expanded={open}
          aria-haspopup="listbox"
          aria-controls={open ? listboxId : undefined}
          aria-label={ariaLabel}
          disabled={disabled}
          className={cn(
            "flex items-center gap-1.5 flex-wrap min-h-[2.5rem] w-full",
            "rounded-lg border transition-colors duration-150 px-2 py-1",
            "bg-zinc-900 border-zinc-700 text-zinc-100 outline-none",
            "focus-visible:ring-2 focus-visible:ring-violet-500/50 focus-visible:ring-offset-2 focus-visible:ring-offset-zinc-950",
            "disabled:pointer-events-none disabled:opacity-50"
          )}
          onClick={() => (open ? handleClose() : handleOpen())}
        >
          {selectedOptions.length === 0 && (
            <span className="text-zinc-500 text-sm px-1">{placeholder}</span>
          )}
          {visibleBadges.map((opt) => (
            <span
              key={opt.value}
              data-testid={`badge-${opt.value}`}
              className={cn(
                "inline-flex items-center gap-1 rounded-md px-2 py-0.5",
                "bg-violet-600/20 text-violet-300 text-xs font-medium"
              )}
            >
              {opt.label}
              <span
                role="button"
                aria-label={`Remove ${opt.label}`}
                className="hover:text-violet-100 outline-none rounded-sm focus-visible:ring-1 focus-visible:ring-violet-500 cursor-pointer"
                onClick={(e) => removeValue(opt.value, e)}
                tabIndex={-1}
              >
                <XIcon className="size-3" />
              </span>
            </span>
          ))}
          {overflowCount > 0 && (
            <span className="text-xs text-zinc-400 px-1" data-testid="overflow-badge">
              +{overflowCount} more
            </span>
          )}
          <span className="ml-auto flex items-center gap-1 shrink-0">
            {value.length > 0 && (
              <span
                role="button"
                aria-label="Clear all"
                className="text-zinc-400 hover:text-zinc-200 outline-none rounded-sm p-0.5 focus-visible:ring-1 focus-visible:ring-violet-500 cursor-pointer"
                onClick={clearAll}
                tabIndex={-1}
              >
                <XIcon className="size-3.5" />
              </span>
            )}
            <ChevronDown
              className={cn(
                "size-4 text-zinc-400 transition-transform",
                open && "rotate-180"
              )}
            />
          </span>
        </button>

        {open && (
          <div
            ref={dropdownRef}
            id={listboxId}
            role="listbox"
            aria-label={ariaLabel}
            aria-multiselectable="true"
            className={cn(
              "absolute z-50 mt-1 w-full overflow-auto rounded-lg border",
              "bg-zinc-900 border-zinc-700 shadow-lg shadow-black/40",
              "max-h-60 p-1"
            )}
          >
            {options.map((option) => {
              const selected = value.includes(option.value);
              return (
                <div
                  key={option.value}
                  role="option"
                  aria-selected={selected}
                  aria-disabled={option.disabled || undefined}
                  className={cn(
                    "flex items-center gap-2 rounded-md px-2 h-8 text-sm cursor-pointer select-none",
                    "text-zinc-100 hover:bg-zinc-800",
                    option.disabled && "opacity-50 cursor-not-allowed"
                  )}
                  onClick={() => toggleOption(option.value)}
                >
                  <div
                    className={cn(
                      "flex size-4 items-center justify-center rounded border",
                      selected
                        ? "border-violet-600 bg-violet-600 text-white"
                        : "border-zinc-600"
                    )}
                    aria-hidden="true"
                  >
                    {selected && <CheckIcon className="size-2.5" />}
                  </div>
                  <span className="flex-1 truncate">{option.label}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }
);

BadgeSelect.displayName = "BadgeSelect";

export { BadgeSelect };
