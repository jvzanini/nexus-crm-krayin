import { useState } from "react";
import { BadgeSelect } from "./index";

export default { title: "Primitives/BadgeSelect" };

const options = [
  { value: "bug", label: "Bug" },
  { value: "feature", label: "Feature" },
  { value: "docs", label: "Documentation" },
  { value: "chore", label: "Chore" },
  { value: "refactor", label: "Refactor" },
];

export const Default = () => {
  const [v, setV] = useState<string[]>(["bug", "feature"]);
  return <BadgeSelect options={options} value={v} onValueChange={setV} />;
};

export const Empty = () => {
  const [v, setV] = useState<string[]>([]);
  return <BadgeSelect options={options} value={v} onValueChange={setV} />;
};

export const MaxDisplay = () => {
  const [v, setV] = useState(["bug", "feature", "docs", "chore"]);
  return <BadgeSelect options={options} value={v} onValueChange={setV} maxDisplay={2} />;
};

export const Disabled = () => (
  <BadgeSelect options={options} value={["bug"]} disabled />
);
