import { Badge } from "./index";

export default { title: "DataDisplay/Badge" };

export const Default = () => <Badge>Default</Badge>;
export const Success = () => <Badge variant="success">Success</Badge>;
export const Warning = () => <Badge variant="warning">Warning</Badge>;
export const Danger = () => <Badge variant="danger">Danger</Badge>;
export const Info = () => <Badge variant="info">Info</Badge>;
export const Outline = () => <Badge variant="outline">Outline</Badge>;

export const WithIcon = () => (
  <Badge icon={<span>★</span>}>Featured</Badge>
);

export const Removable = () => (
  <Badge removable onRemove={() => {}}>
    Removable
  </Badge>
);
