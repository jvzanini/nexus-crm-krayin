import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Badge } from "./index";

describe("Badge", () => {
  it("renders with default variant", () => {
    render(<Badge>Default</Badge>);
    expect(screen.getByText("Default")).toBeInTheDocument();
  });

  it("renders success variant", () => {
    render(<Badge variant="success">Success</Badge>);
    const badge = screen.getByText("Success");
    expect(badge.className).toContain("text-emerald-400");
  });

  it("renders warning variant", () => {
    render(<Badge variant="warning">Warning</Badge>);
    const badge = screen.getByText("Warning");
    expect(badge.className).toContain("text-amber-400");
  });

  it("renders danger variant", () => {
    render(<Badge variant="danger">Danger</Badge>);
    const badge = screen.getByText("Danger");
    expect(badge.className).toContain("text-red-400");
  });

  it("renders info variant", () => {
    render(<Badge variant="info">Info</Badge>);
    const badge = screen.getByText("Info");
    expect(badge.className).toContain("text-blue-400");
  });

  it("renders outline variant", () => {
    render(<Badge variant="outline">Outline</Badge>);
    const badge = screen.getByText("Outline");
    expect(badge.className).toContain("bg-transparent");
  });

  it("renders with icon", () => {
    render(
      <Badge icon={<svg data-testid="badge-icon" />}>With Icon</Badge>
    );
    expect(screen.getByTestId("badge-icon")).toBeInTheDocument();
  });

  it("renders removable badge", () => {
    render(<Badge removable>Removable</Badge>);
    expect(screen.getByLabelText("Remove")).toBeInTheDocument();
  });

  it("calls onRemove when remove button clicked", async () => {
    const user = userEvent.setup();
    const onRemove = vi.fn();
    render(<Badge removable onRemove={onRemove}>Tag</Badge>);
    await user.click(screen.getByLabelText("Remove"));
    expect(onRemove).toHaveBeenCalledTimes(1);
  });

  it("does not show remove button when removable is false", () => {
    render(<Badge>No Remove</Badge>);
    expect(screen.queryByLabelText("Remove")).not.toBeInTheDocument();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLSpanElement>();
    render(<Badge ref={ref}>Ref</Badge>);
    expect(ref.current).toBeInstanceOf(HTMLSpanElement);
  });

  it("merges custom className", () => {
    render(<Badge className="my-badge">Custom</Badge>);
    expect(screen.getByText("Custom").className).toContain("my-badge");
  });

  it("has correct displayName", () => {
    expect(Badge.displayName).toBe("Badge");
  });
});
