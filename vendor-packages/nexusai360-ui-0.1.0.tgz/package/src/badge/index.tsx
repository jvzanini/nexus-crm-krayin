import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:ring-offset-2 focus:ring-offset-zinc-950",
  {
    variants: {
      variant: {
        default:
          "border-zinc-700 bg-zinc-800 text-zinc-100",
        success:
          "border-emerald-700/50 bg-emerald-950 text-emerald-400",
        warning:
          "border-amber-700/50 bg-amber-950 text-amber-400",
        danger:
          "border-red-700/50 bg-red-950 text-red-400",
        info:
          "border-blue-700/50 bg-blue-950 text-blue-400",
        outline:
          "border-zinc-700 bg-transparent text-zinc-400",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  /** Icon rendered before children */
  icon?: React.ReactNode;
  /** Show remove button */
  removable?: boolean;
  /** Called when remove button is clicked */
  onRemove?: () => void;
}

const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant, icon, removable, onRemove, children, ...props }, ref) => (
    <span
      ref={ref}
      className={cn(badgeVariants({ variant }), className)}
      {...props}
    >
      {icon && <span className="[&_svg]:size-3" aria-hidden="true">{icon}</span>}
      {children}
      {removable && (
        <button
          type="button"
          aria-label="Remove"
          className="ml-0.5 -mr-1 inline-flex h-4 w-4 items-center justify-center rounded-full hover:bg-zinc-700/50 transition-colors"
          onClick={(e) => {
            e.stopPropagation();
            onRemove?.();
          }}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="12"
            height="12"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <path d="M18 6 6 18" />
            <path d="m6 6 12 12" />
          </svg>
        </button>
      )}
    </span>
  )
);

Badge.displayName = "Badge";

export { Badge, badgeVariants };
