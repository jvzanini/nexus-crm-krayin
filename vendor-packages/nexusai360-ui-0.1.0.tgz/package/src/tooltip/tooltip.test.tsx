import { describe, it, expect } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  Tooltip,
  TooltipTrigger,
  TooltipContent,
  TooltipProvider,
} from "./index";

function renderTooltip(props: { delayDuration?: number } = {}) {
  return render(
    <TooltipProvider delayDuration={props.delayDuration ?? 0}>
      <Tooltip>
        <TooltipTrigger>Hover me</TooltipTrigger>
        <TooltipContent>Tooltip text</TooltipContent>
      </Tooltip>
    </TooltipProvider>,
  );
}

describe("Tooltip", () => {
  it("renders trigger", () => {
    renderTooltip();
    expect(screen.getByText("Hover me")).toBeInTheDocument();
  });

  it("does not show content initially", () => {
    renderTooltip();
    expect(screen.queryByRole("tooltip")).not.toBeInTheDocument();
  });

  it("shows content on hover", async () => {
    const user = userEvent.setup();
    renderTooltip();
    await user.hover(screen.getByText("Hover me"));
    await waitFor(() =>
      expect(screen.getByRole("tooltip")).toBeInTheDocument(),
    );
  });

  it("renders tooltip content text when visible", async () => {
    const user = userEvent.setup();
    renderTooltip();
    await user.hover(screen.getByText("Hover me"));
    await waitFor(() => {
      const tooltip = screen.getByRole("tooltip");
      expect(tooltip.textContent).toBe("Tooltip text");
    });
  });

  it("shows on focus", async () => {
    const user = userEvent.setup();
    renderTooltip();
    await user.tab();
    await waitFor(() =>
      expect(screen.getByRole("tooltip")).toBeInTheDocument(),
    );
  });

  it("merges custom className on content", async () => {
    const user = userEvent.setup();
    render(
      <TooltipProvider delayDuration={0}>
        <Tooltip>
          <TooltipTrigger>TrigBtn</TooltipTrigger>
          <TooltipContent className="my-tip">TipContent</TooltipContent>
        </Tooltip>
      </TooltipProvider>,
    );
    await user.hover(screen.getByText("TrigBtn"));
    await waitFor(() => {
      const tips = screen.getAllByText("TipContent");
      const visible = tips.find((el) => el.className.includes("my-tip"));
      expect(visible).toBeDefined();
    });
  });

  it("TooltipContent has displayName", () => {
    expect(TooltipContent.displayName).toBe("TooltipContent");
  });

  it("renders in portal (outside container)", async () => {
    const user = userEvent.setup();
    const { container } = renderTooltip();
    await user.hover(screen.getByText("Hover me"));
    await waitFor(() =>
      expect(screen.getByRole("tooltip")).toBeInTheDocument(),
    );
    // Tooltip portaled: role=tooltip not inside container div
    const tooltipInContainer = container.querySelector('[role="tooltip"]');
    expect(tooltipInContainer).toBeNull();
  });

  it("has tooltip role", async () => {
    const user = userEvent.setup();
    renderTooltip();
    await user.hover(screen.getByText("Hover me"));
    await waitFor(() =>
      expect(screen.getByRole("tooltip")).toBeInTheDocument(),
    );
  });

  it("content has correct text classes", async () => {
    const user = userEvent.setup();
    renderTooltip();
    await user.hover(screen.getByText("Hover me"));
    await waitFor(() => {
      const tooltipEl = screen.getByRole("tooltip");
      // The visually hidden span has role=tooltip; parent div has the classes
      const contentDiv = tooltipEl.parentElement;
      expect(contentDiv?.className).toContain("text-xs");
    });
  });
});
