import { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider } from "./index";

export default { title: "Overlays/Tooltip" };

export const Default = () => (
  <TooltipProvider>
    <Tooltip>
      <TooltipTrigger asChild>
        <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">
          Hover me
        </button>
      </TooltipTrigger>
      <TooltipContent>Tooltip content</TooltipContent>
    </Tooltip>
  </TooltipProvider>
);

export const Multiple = () => (
  <TooltipProvider>
    <div style={{ display: "flex", gap: 16 }}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Save</button>
        </TooltipTrigger>
        <TooltipContent>Save changes (Ctrl+S)</TooltipContent>
      </Tooltip>
      <Tooltip>
        <TooltipTrigger asChild>
          <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Delete</button>
        </TooltipTrigger>
        <TooltipContent>Delete item</TooltipContent>
      </Tooltip>
    </div>
  </TooltipProvider>
);
