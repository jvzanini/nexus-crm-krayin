"use client";

import * as React from "react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

export type Theme = "dark" | "light" | "system";

export interface ThemeProviderProps {
  children: React.ReactNode;
  defaultTheme?: Theme;
  storageKey?: string;
}

export interface ThemeContextValue {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  resolvedTheme: "dark" | "light";
  themes: readonly Theme[];
}

/* ------------------------------------------------------------------ */
/*  Context                                                            */
/* ------------------------------------------------------------------ */

const THEMES: readonly Theme[] = ["dark", "light", "system"] as const;

const ThemeContext = React.createContext<ThemeContextValue | undefined>(
  undefined,
);

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function getSystemTheme(): "dark" | "light" {
  if (typeof window === "undefined") return "dark";
  return window.matchMedia("(prefers-color-scheme: dark)").matches
    ? "dark"
    : "light";
}

function getStoredTheme(storageKey: string): Theme | null {
  if (typeof document === "undefined") return null;

  // Cookie first (SSR-safe)
  const cookie = document.cookie
    .split("; ")
    .find((c) => c.startsWith(`${storageKey}=`));
  if (cookie) {
    const val = cookie.split("=")[1] as Theme;
    if (THEMES.includes(val)) return val;
  }

  // localStorage fallback
  if (typeof localStorage !== "undefined") {
    const val = localStorage.getItem(storageKey) as Theme | null;
    if (val && THEMES.includes(val)) return val;
  }

  return null;
}

function persistTheme(storageKey: string, theme: Theme) {
  if (typeof document !== "undefined") {
    document.cookie = `${storageKey}=${theme};path=/;max-age=31536000;SameSite=Lax`;
  }
  if (typeof localStorage !== "undefined") {
    try {
      localStorage.setItem(storageKey, theme);
    } catch {
      // quota exceeded — ignore
    }
  }
}

function applyThemeToDOM(resolved: "dark" | "light") {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.remove("dark", "light");
  root.classList.add(resolved);
  root.style.colorScheme = resolved;
}

/* ------------------------------------------------------------------ */
/*  ThemeProvider                                                       */
/* ------------------------------------------------------------------ */

export const ThemeProvider: React.FC<ThemeProviderProps> = ({
  children,
  defaultTheme = "dark",
  storageKey = "nexus-theme",
}) => {
  const [theme, setThemeState] = React.useState<Theme>(() => {
    return getStoredTheme(storageKey) ?? defaultTheme;
  });

  const resolvedTheme: "dark" | "light" =
    theme === "system" ? getSystemTheme() : theme;

  const setTheme = React.useCallback(
    (next: Theme) => {
      setThemeState(next);
      persistTheme(storageKey, next);
    },
    [storageKey],
  );

  // Apply to DOM on mount + changes
  React.useEffect(() => {
    applyThemeToDOM(resolvedTheme);
  }, [resolvedTheme]);

  // Listen for system changes when theme === 'system'
  React.useEffect(() => {
    if (theme !== "system") return;
    const mq = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => applyThemeToDOM(getSystemTheme());
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, [theme]);

  const value = React.useMemo<ThemeContextValue>(
    () => ({ theme, setTheme, resolvedTheme, themes: THEMES }),
    [theme, setTheme, resolvedTheme],
  );

  return (
    <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>
  );
};
ThemeProvider.displayName = "ThemeProvider";

/* ------------------------------------------------------------------ */
/*  useTheme                                                           */
/* ------------------------------------------------------------------ */

export function useTheme(): ThemeContextValue {
  const ctx = React.useContext(ThemeContext);
  if (!ctx) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return ctx;
}

/* ------------------------------------------------------------------ */
/*  ThemeToggle                                                        */
/* ------------------------------------------------------------------ */

const SunIcon: React.FC = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    aria-hidden="true"
    data-testid="sun-icon"
  >
    <circle cx="8" cy="8" r="3" stroke="currentColor" strokeWidth="1.5" />
    <path
      d="M8 1v2M8 13v2M1 8h2M13 8h2M3.05 3.05l1.41 1.41M11.54 11.54l1.41 1.41M3.05 12.95l1.41-1.41M11.54 4.46l1.41-1.41"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

const MoonIcon: React.FC = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    aria-hidden="true"
    data-testid="moon-icon"
  >
    <path
      d="M13.36 10.06A6 6 0 015.94 2.64 6 6 0 108 14a6 6 0 005.36-3.94z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
  </svg>
);

const MonitorIcon: React.FC = () => (
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    aria-hidden="true"
    data-testid="monitor-icon"
  >
    <rect
      x="1"
      y="2"
      width="14"
      height="10"
      rx="1.5"
      stroke="currentColor"
      strokeWidth="1.5"
    />
    <path d="M5 14h6M8 12v2" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

export interface ThemeToggleProps {
  className?: string;
}

export const ThemeToggle = React.forwardRef<
  HTMLButtonElement,
  ThemeToggleProps
>(({ className }, ref) => {
  const { theme, setTheme } = useTheme();

  const cycle = () => {
    const order: Theme[] = ["dark", "light", "system"];
    const next = order[(order.indexOf(theme) + 1) % order.length];
    setTheme(next);
  };

  const icon =
    theme === "dark" ? (
      <MoonIcon />
    ) : theme === "light" ? (
      <SunIcon />
    ) : (
      <MonitorIcon />
    );

  return (
    <button
      ref={ref}
      type="button"
      onClick={cycle}
      className={className}
      aria-label={`Current theme: ${theme}. Click to change.`}
      data-testid="theme-toggle"
    >
      {icon}
    </button>
  );
});
ThemeToggle.displayName = "ThemeToggle";
