import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ThemeProvider, ThemeToggle, useTheme } from "./index";
import type { Theme } from "./index";

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function ThemeDisplay() {
  const { theme, resolvedTheme, themes } = useTheme();
  return (
    <div>
      <span data-testid="theme">{theme}</span>
      <span data-testid="resolved">{resolvedTheme}</span>
      <span data-testid="themes">{themes.join(",")}</span>
    </div>
  );
}

function SetThemeButton({ to }: { to: Theme }) {
  const { setTheme } = useTheme();
  return (
    <button onClick={() => setTheme(to)} data-testid={`set-${to}`}>
      Set {to}
    </button>
  );
}

beforeEach(() => {
  document.documentElement.classList.remove("dark", "light");
  document.documentElement.style.colorScheme = "";
  document.cookie = "nexus-theme=; max-age=0; path=/";
  localStorage.clear();
});

/* ================================================================== */
/*  ThemeProvider                                                       */
/* ================================================================== */

describe("ThemeProvider", () => {
  it("provides default dark theme", () => {
    render(
      <ThemeProvider>
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme").textContent).toBe("dark");
    expect(screen.getByTestId("resolved").textContent).toBe("dark");
  });

  it("provides all themes list", () => {
    render(
      <ThemeProvider>
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("themes").textContent).toBe("dark,light,system");
  });

  it("accepts defaultTheme=light", () => {
    render(
      <ThemeProvider defaultTheme="light">
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme").textContent).toBe("light");
    expect(screen.getByTestId("resolved").textContent).toBe("light");
  });

  it("applies dark class to documentElement", () => {
    render(
      <ThemeProvider>
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(document.documentElement.classList.contains("dark")).toBe(true);
  });

  it("applies light class when light theme", () => {
    render(
      <ThemeProvider defaultTheme="light">
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(document.documentElement.classList.contains("light")).toBe(true);
  });

  it("sets colorScheme style", () => {
    render(
      <ThemeProvider>
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(document.documentElement.style.colorScheme).toBe("dark");
  });

  it("setTheme updates theme", async () => {
    const user = userEvent.setup();
    render(
      <ThemeProvider>
        <ThemeDisplay />
        <SetThemeButton to="light" />
      </ThemeProvider>,
    );
    await user.click(screen.getByTestId("set-light"));
    expect(screen.getByTestId("theme").textContent).toBe("light");
    expect(screen.getByTestId("resolved").textContent).toBe("light");
  });

  it("persists to localStorage", async () => {
    const user = userEvent.setup();
    render(
      <ThemeProvider>
        <SetThemeButton to="light" />
      </ThemeProvider>,
    );
    await user.click(screen.getByTestId("set-light"));
    expect(localStorage.getItem("nexus-theme")).toBe("light");
  });

  it("persists to cookie", async () => {
    const user = userEvent.setup();
    render(
      <ThemeProvider>
        <SetThemeButton to="light" />
      </ThemeProvider>,
    );
    await user.click(screen.getByTestId("set-light"));
    expect(document.cookie).toContain("nexus-theme=light");
  });

  it("reads from cookie on mount", () => {
    document.cookie = "nexus-theme=light; path=/";
    render(
      <ThemeProvider>
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme").textContent).toBe("light");
  });

  it("reads from localStorage fallback", () => {
    localStorage.setItem("nexus-theme", "light");
    render(
      <ThemeProvider>
        <ThemeDisplay />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme").textContent).toBe("light");
  });

  it("uses custom storageKey", async () => {
    const user = userEvent.setup();
    render(
      <ThemeProvider storageKey="my-theme">
        <SetThemeButton to="light" />
      </ThemeProvider>,
    );
    await user.click(screen.getByTestId("set-light"));
    expect(localStorage.getItem("my-theme")).toBe("light");
  });
});

/* ================================================================== */
/*  useTheme error                                                     */
/* ================================================================== */

describe("useTheme", () => {
  it("throws outside provider", () => {
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    expect(() => render(<ThemeDisplay />)).toThrow(
      "useTheme must be used within a ThemeProvider",
    );
    consoleSpy.mockRestore();
  });
});

/* ================================================================== */
/*  ThemeToggle                                                        */
/* ================================================================== */

describe("ThemeToggle", () => {
  it("renders toggle button", () => {
    render(
      <ThemeProvider>
        <ThemeToggle />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme-toggle")).toBeInTheDocument();
  });

  it("shows moon icon for dark theme", () => {
    render(
      <ThemeProvider defaultTheme="dark">
        <ThemeToggle />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("moon-icon")).toBeInTheDocument();
  });

  it("cycles dark→light→system→dark", async () => {
    const user = userEvent.setup();
    render(
      <ThemeProvider defaultTheme="dark">
        <ThemeToggle />
        <ThemeDisplay />
      </ThemeProvider>,
    );
    const btn = screen.getByTestId("theme-toggle");
    // dark → light
    await user.click(btn);
    expect(screen.getByTestId("theme").textContent).toBe("light");
    expect(screen.getByTestId("sun-icon")).toBeInTheDocument();
    // light → system
    await user.click(btn);
    expect(screen.getByTestId("theme").textContent).toBe("system");
    expect(screen.getByTestId("monitor-icon")).toBeInTheDocument();
    // system → dark
    await user.click(btn);
    expect(screen.getByTestId("theme").textContent).toBe("dark");
  });

  it("has accessible aria-label", () => {
    render(
      <ThemeProvider>
        <ThemeToggle />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme-toggle")).toHaveAttribute(
      "aria-label",
      "Current theme: dark. Click to change.",
    );
  });

  it("applies custom className", () => {
    render(
      <ThemeProvider>
        <ThemeToggle className="toggle-cls" />
      </ThemeProvider>,
    );
    expect(screen.getByTestId("theme-toggle")).toHaveClass("toggle-cls");
  });

  it("forwards ref", () => {
    const ref = { current: null as HTMLButtonElement | null };
    render(
      <ThemeProvider>
        <ThemeToggle ref={ref} />
      </ThemeProvider>,
    );
    expect(ref.current).toBeInstanceOf(HTMLButtonElement);
  });

  it("has correct displayName", () => {
    expect(ThemeToggle.displayName).toBe("ThemeToggle");
  });
});
