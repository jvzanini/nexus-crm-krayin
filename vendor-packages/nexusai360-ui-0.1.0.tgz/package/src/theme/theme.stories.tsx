import { ThemeProvider, ThemeToggle } from "./index";

export default { title: "Theme/Theme" };

export const Toggle = () => (
  <ThemeProvider>
    <div className="flex items-center gap-4">
      <ThemeToggle />
      <span className="text-sm text-zinc-300">Click to toggle theme</span>
    </div>
  </ThemeProvider>
);
