import { Input } from "./index";

export default { title: "Primitives/Input" };

export const Default = () => <Input placeholder="Enter text..." />;
export const Small = () => <Input size="sm" placeholder="Small" />;
export const Medium = () => <Input size="md" placeholder="Medium" />;
export const Large = () => <Input size="lg" placeholder="Large" />;
export const Disabled = () => <Input disabled placeholder="Disabled" />;
export const ReadOnly = () => <Input readOnly value="Read only" />;
export const WithError = () => <Input error errorMessage="This field is required" />;
export const WithAddons = () => (
  <Input
    leftAddon={<span>$</span>}
    rightAddon={<span>.00</span>}
    placeholder="0"
  />
);
export const Password = () => <Input type="password" placeholder="Password" />;
