import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Input } from "./index";

describe("Input", () => {
  it("renders an input element", () => {
    render(<Input aria-label="test" />);
    expect(screen.getByRole("textbox")).toBeInTheDocument();
  });

  it("renders with default type text", () => {
    render(<Input aria-label="test" />);
    expect(screen.getByRole("textbox")).toHaveAttribute("type", "text");
  });

  it("accepts typed text", async () => {
    const user = userEvent.setup();
    render(<Input aria-label="test" />);
    const input = screen.getByRole("textbox");
    await user.type(input, "hello");
    expect(input).toHaveValue("hello");
  });

  it("applies sm size class", () => {
    render(<Input aria-label="test" size="sm" />);
    expect(screen.getByRole("textbox").className).toContain("h-8");
  });

  it("applies md size class", () => {
    render(<Input aria-label="test" size="md" />);
    expect(screen.getByRole("textbox").className).toContain("h-10");
  });

  it("applies lg size class", () => {
    render(<Input aria-label="test" size="lg" />);
    expect(screen.getByRole("textbox").className).toContain("h-12");
  });

  it("shows disabled state", () => {
    render(<Input aria-label="test" disabled />);
    expect(screen.getByRole("textbox")).toBeDisabled();
  });

  it("shows readOnly state", () => {
    render(<Input aria-label="test" readOnly />);
    expect(screen.getByRole("textbox")).toHaveAttribute("readonly");
  });

  it("shows error styling when error is true", () => {
    render(<Input aria-label="test" error />);
    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("aria-invalid", "true");
    expect(input.className).toContain("border-red-500");
  });

  it("shows error message", () => {
    render(<Input aria-label="test" errorMessage="Required field" />);
    expect(screen.getByRole("alert")).toHaveTextContent("Required field");
  });

  it("links error message via aria-describedby", () => {
    render(<Input aria-label="test" id="email" errorMessage="Invalid" />);
    const input = screen.getByRole("textbox");
    expect(input).toHaveAttribute("aria-describedby", "email-error");
  });

  it("renders left addon", () => {
    render(<Input aria-label="test" leftAddon={<span data-testid="left">$</span>} />);
    expect(screen.getByTestId("left")).toBeInTheDocument();
  });

  it("renders right addon", () => {
    render(<Input aria-label="test" rightAddon={<span data-testid="right">%</span>} />);
    expect(screen.getByTestId("right")).toBeInTheDocument();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLInputElement>();
    render(<Input ref={ref} aria-label="test" />);
    expect(ref.current).toBeInstanceOf(HTMLInputElement);
  });

  it("sets aria-required when required", () => {
    render(<Input aria-label="test" required />);
    expect(screen.getByRole("textbox")).toHaveAttribute("aria-required", "true");
  });

  it("calls onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Input aria-label="test" onChange={onChange} />);
    await user.type(screen.getByRole("textbox"), "a");
    expect(onChange).toHaveBeenCalled();
  });

  it("has correct displayName", () => {
    expect(Input.displayName).toBe("Input");
  });

  it("merges custom className", () => {
    render(<Input aria-label="test" className="my-cls" />);
    expect(screen.getByRole("textbox").className).toContain("my-cls");
  });
});
