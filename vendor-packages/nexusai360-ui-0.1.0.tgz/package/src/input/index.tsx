import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

const inputVariants = cva(
  [
    "w-full min-w-0 rounded-md border bg-zinc-950 text-zinc-100 transition-colors",
    "placeholder:text-zinc-500",
    "outline-none",
    "focus-visible:border-violet-500 focus-visible:ring-2 focus-visible:ring-violet-500/50",
    "disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-zinc-900 disabled:text-zinc-600",
    "read-only:bg-zinc-900",
  ].join(" "),
  {
    variants: {
      size: {
        sm: "h-8 px-2 text-sm",
        md: "h-10 px-3 text-base",
        lg: "h-12 px-4 text-lg",
      },
      error: {
        true: "border-red-500 focus-visible:border-red-500 focus-visible:ring-red-500/30",
        false: "border-zinc-700 hover:border-zinc-500",
      },
    },
    defaultVariants: {
      size: "md",
      error: false,
    },
  }
);

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size">,
    VariantProps<typeof inputVariants> {
  /** Error message displayed below input */
  errorMessage?: string;
  /** Addon rendered at left inside the input container */
  leftAddon?: React.ReactNode;
  /** Addon rendered at right inside the input container */
  rightAddon?: React.ReactNode;
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      type = "text",
      size,
      error = false,
      errorMessage,
      leftAddon,
      rightAddon,
      disabled,
      readOnly,
      id,
      "aria-describedby": ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    const errorId = errorMessage ? `${id ?? "input"}-error` : undefined;
    const describedBy = [ariaDescribedBy, errorId].filter(Boolean).join(" ") || undefined;
    const hasError = error === true || !!errorMessage;

    if (leftAddon || rightAddon) {
      return (
        <div className="flex flex-col">
          <div className="relative flex items-center">
            {leftAddon && (
              <div className="pointer-events-none absolute left-0 flex items-center pl-3 text-zinc-500">
                {leftAddon}
              </div>
            )}
            <input
              ref={ref}
              id={id}
              type={type}
              className={cn(
                inputVariants({ size, error: hasError }),
                leftAddon && "pl-10",
                rightAddon && "pr-10",
                className
              )}
              disabled={disabled}
              readOnly={readOnly}
              aria-invalid={hasError || undefined}
              aria-describedby={describedBy}
              aria-required={props.required || undefined}
              {...props}
            />
            {rightAddon && (
              <div className="pointer-events-none absolute right-0 flex items-center pr-3 text-zinc-500">
                {rightAddon}
              </div>
            )}
          </div>
          {errorMessage && (
            <p id={errorId} className="mt-1 text-sm text-red-500" role="alert">
              {errorMessage}
            </p>
          )}
        </div>
      );
    }

    return (
      <>
        <input
          ref={ref}
          id={id}
          type={type}
          className={cn(inputVariants({ size, error: hasError }), className)}
          disabled={disabled}
          readOnly={readOnly}
          aria-invalid={hasError || undefined}
          aria-describedby={describedBy}
          aria-required={props.required || undefined}
          {...props}
        />
        {errorMessage && (
          <p id={errorId} className="mt-1 text-sm text-red-500" role="alert">
            {errorMessage}
          </p>
        )}
      </>
    );
  }
);

Input.displayName = "Input";

export { Input, inputVariants };
