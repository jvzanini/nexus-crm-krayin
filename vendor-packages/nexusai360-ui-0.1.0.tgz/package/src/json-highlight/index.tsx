import * as React from "react";

/**
 * JSON syntax highlighter simples — converte string JSON em nodes coloridos.
 * Tokens: keys (violet), strings (emerald), numbers (amber), true/false/null (sky),
 * brackets/colon (zinc). Usado no API Docs viewer e similares.
 *
 * Não usa regex complexa — scanner incremental por linha. Zero deps.
 */
export function highlightJson(src: string): React.ReactNode {
  const lines = src.split("\n");
  return lines.map((line, idx) => {
    const parts: React.ReactNode[] = [];
    let rest = line;
    let k = 0;
    while (rest.length > 0) {
      const ws = rest.match(/^(\s+)/);
      if (ws) {
        parts.push(ws[1]);
        rest = rest.slice(ws[1].length);
        continue;
      }
      const br = rest.match(/^([{}\[\],:])/);
      if (br) {
        parts.push(
          <span key={k++} className="text-zinc-500">
            {br[1]}
          </span>,
        );
        rest = rest.slice(1);
        if (br[1] === ":" && rest.startsWith(" ")) {
          parts.push(" ");
          rest = rest.slice(1);
        }
        continue;
      }
      const key = rest.match(/^("(?:[^"\\]|\\.)*")(\s*:)/);
      if (key) {
        parts.push(
          <span key={k++} className="text-violet-400">
            {key[1]}
          </span>,
        );
        rest = rest.slice(key[1].length);
        continue;
      }
      const str = rest.match(/^("(?:[^"\\]|\\.)*")/);
      if (str) {
        parts.push(
          <span key={k++} className="text-emerald-400">
            {str[1]}
          </span>,
        );
        rest = rest.slice(str[1].length);
        continue;
      }
      const num = rest.match(/^(-?\d+\.?\d*(?:[eE][+-]?\d+)?)/);
      if (num) {
        parts.push(
          <span key={k++} className="text-amber-400">
            {num[1]}
          </span>,
        );
        rest = rest.slice(num[1].length);
        continue;
      }
      const bool = rest.match(/^(true|false|null)/);
      if (bool) {
        parts.push(
          <span key={k++} className="text-sky-400">
            {bool[1]}
          </span>,
        );
        rest = rest.slice(bool[1].length);
        continue;
      }
      parts.push(rest[0]);
      rest = rest.slice(1);
    }
    return (
      <div key={idx} className="whitespace-pre">
        {parts}
      </div>
    );
  });
}
