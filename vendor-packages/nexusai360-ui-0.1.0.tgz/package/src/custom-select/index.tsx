"use client";
/**
 * CustomSelect — port do Roteador Webhook Meta matriz.
 *
 * Select renderizado em portal (fixed positioning) com framer-motion. Suporta:
 * - options com label + description + icon
 * - trigger customizado via renderTrigger
 * - fecha em click-outside e Escape
 *
 * Mantém API idêntica ao Roteador (value/onChange/options/placeholder/icon/renderTrigger).
 * Usa tokens do Blueprint (bg-card, bg-popover, text-foreground, text-muted-foreground, border-border, hover:bg-accent).
 */
import * as React from "react";
import { createPortal } from "react-dom";
import { cn } from "../lib/cn";

export interface CustomSelectOption {
  value: string;
  label: string;
  description?: string;
  icon?: React.ReactNode;
}

export interface CustomSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: CustomSelectOption[];
  placeholder?: string;
  className?: string;
  triggerClassName?: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  /** Render prop do trigger — recebe option selecionada, estado open e toggle */
  renderTrigger?: (
    option: CustomSelectOption | undefined,
    open: boolean,
    toggle: () => void,
  ) => React.ReactNode;
}

const ChevronDown: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

const Check: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true"
  >
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

export function CustomSelect({
  value,
  onChange,
  options,
  placeholder = "Selecionar",
  className,
  triggerClassName,
  icon,
  disabled = false,
  renderTrigger,
}: CustomSelectProps) {
  const [open, setOpen] = React.useState(false);
  const [dropdownStyle, setDropdownStyle] = React.useState<React.CSSProperties>({});
  const ref = React.useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = React.useState(false);

  const selected = options.find((o) => o.value === value);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  React.useEffect(() => {
    if (!open) return;
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    function handleEsc(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEsc);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEsc);
    };
  }, [open]);

  const handleToggle = React.useCallback(() => {
    if (disabled) return;
    if (!open && ref.current) {
      const rect = ref.current.getBoundingClientRect();
      setDropdownStyle({
        position: "fixed",
        top: rect.bottom + 4,
        left: rect.left,
        width: Math.max(rect.width, 240),
      });
    }
    setOpen((v) => !v);
  }, [open, disabled]);

  const dropdown = open ? (
    <div
      style={dropdownStyle}
      className="z-[100] rounded-lg border border-zinc-700 bg-zinc-900 shadow-xl shadow-black/40 overflow-hidden animate-in fade-in-0 slide-in-from-top-1 duration-150"
      role="listbox"
    >
      {options.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => {
                onChange(option.value);
                setOpen(false);
              }}
              role="option"
              aria-selected={value === option.value}
              className={cn(
                "flex w-full items-start gap-3 px-4 py-2.5 text-left cursor-pointer transition-colors duration-150 hover:bg-zinc-800",
                value === option.value && "bg-zinc-800/50",
              )}
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-zinc-100">
                    {option.label}
                  </span>
                  {option.icon && <span className="shrink-0">{option.icon}</span>}
                </div>
                {option.description && (
                  <span className="block text-xs text-zinc-400 mt-0.5">
                    {option.description}
                  </span>
                )}
              </div>
              {value === option.value && (
                <Check className="h-4 w-4 text-violet-400 shrink-0 mt-0.5" />
              )}
            </button>
          ))}
    </div>
  ) : null;

  return (
    <div ref={ref} className={cn("relative", className)}>
      {renderTrigger ? (
        renderTrigger(selected, open, handleToggle)
      ) : (
        <button
          type="button"
          onClick={handleToggle}
          disabled={disabled}
          aria-haspopup="listbox"
          aria-expanded={open}
          className={cn(
            "flex w-full items-center justify-between rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100 cursor-pointer transition-colors duration-150 hover:border-zinc-600 disabled:opacity-50 disabled:cursor-not-allowed",
            triggerClassName,
          )}
        >
          <span className="flex min-w-0 flex-1 items-center gap-2 truncate text-left">
            {icon}
            {selected?.icon}
            {selected?.label ?? placeholder}
          </span>
          <ChevronDown
            className={cn(
              "h-4 w-4 text-zinc-400 transition-transform duration-150 shrink-0 ml-2",
              open && "rotate-180",
            )}
          />
        </button>
      )}
      {/* Portal — garante que dropdown escape overflow:hidden de containers */}
      {mounted && typeof document !== "undefined" && createPortal(dropdown, document.body)}
    </div>
  );
}
