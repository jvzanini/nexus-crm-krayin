import { describe, it, expect, vi } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose,
} from "./index";

function renderSheet(side?: "left" | "right" | "top" | "bottom") {
  return render(
    <Sheet>
      <SheetTrigger>Open Sheet</SheetTrigger>
      <SheetContent side={side}>
        <SheetHeader>
          <SheetTitle>Sheet Title</SheetTitle>
          <SheetDescription>Sheet Desc</SheetDescription>
        </SheetHeader>
        <p>Sheet Body</p>
        <SheetFooter>
          <SheetClose>Done</SheetClose>
        </SheetFooter>
      </SheetContent>
    </Sheet>,
  );
}

describe("Sheet", () => {
  it("renders trigger", () => {
    renderSheet();
    expect(screen.getByText("Open Sheet")).toBeInTheDocument();
  });

  it("opens on trigger click", async () => {
    const user = userEvent.setup();
    renderSheet();
    await user.click(screen.getByText("Open Sheet"));
    expect(screen.getByText("Sheet Title")).toBeInTheDocument();
    expect(screen.getByText("Sheet Body")).toBeInTheDocument();
  });

  it("closes on close button", async () => {
    const user = userEvent.setup();
    renderSheet();
    await user.click(screen.getByText("Open Sheet"));
    await user.click(screen.getByText("Done"));
    await waitFor(() =>
      expect(screen.queryByText("Sheet Title")).not.toBeInTheDocument(),
    );
  });

  it("closes on Escape", async () => {
    const user = userEvent.setup();
    renderSheet();
    await user.click(screen.getByText("Open Sheet"));
    await user.keyboard("{Escape}");
    await waitFor(() =>
      expect(screen.queryByText("Sheet Title")).not.toBeInTheDocument(),
    );
  });

  it("renders with side=right (default)", async () => {
    const user = userEvent.setup();
    renderSheet();
    await user.click(screen.getByText("Open Sheet"));
    const dialog = screen.getByRole("dialog");
    expect(dialog.className).toContain("right-0");
  });

  it("renders with side=left", async () => {
    const user = userEvent.setup();
    renderSheet("left");
    await user.click(screen.getByText("Open Sheet"));
    const dialog = screen.getByRole("dialog");
    expect(dialog.className).toContain("left-0");
  });

  it("renders with side=top", async () => {
    const user = userEvent.setup();
    renderSheet("top");
    await user.click(screen.getByText("Open Sheet"));
    const dialog = screen.getByRole("dialog");
    expect(dialog.className).toContain("top-0");
  });

  it("renders with side=bottom", async () => {
    const user = userEvent.setup();
    renderSheet("bottom");
    await user.click(screen.getByText("Open Sheet"));
    const dialog = screen.getByRole("dialog");
    expect(dialog.className).toContain("bottom-0");
  });

  it("has dialog role when open", async () => {
    const user = userEvent.setup();
    renderSheet();
    await user.click(screen.getByText("Open Sheet"));
    expect(screen.getByRole("dialog")).toBeInTheDocument();
  });

  it("renders description", async () => {
    const user = userEvent.setup();
    renderSheet();
    await user.click(screen.getByText("Open Sheet"));
    expect(screen.getByText("Sheet Desc")).toBeInTheDocument();
  });

  it("SheetContent has displayName", () => {
    expect(SheetContent.displayName).toBe("SheetContent");
  });

  it("SheetHeader has displayName", () => {
    expect(SheetHeader.displayName).toBe("SheetHeader");
  });

  it("SheetFooter has displayName", () => {
    expect(SheetFooter.displayName).toBe("SheetFooter");
  });

  it("SheetTitle has displayName", () => {
    expect(SheetTitle.displayName).toBe("SheetTitle");
  });

  it("SheetDescription has displayName", () => {
    expect(SheetDescription.displayName).toBe("SheetDescription");
  });

  it("merges custom className", async () => {
    const user = userEvent.setup();
    render(
      <Sheet>
        <SheetTrigger>Open</SheetTrigger>
        <SheetContent className="my-sheet">Content</SheetContent>
      </Sheet>,
    );
    await user.click(screen.getByText("Open"));
    const dialog = screen.getByRole("dialog");
    expect(dialog.className).toContain("my-sheet");
  });
});
