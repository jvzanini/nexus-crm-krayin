import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose,
} from "./index";

export default { title: "Overlays/Sheet" };

export const Right = () => (
  <Sheet>
    <SheetTrigger asChild>
      <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Sheet</button>
    </SheetTrigger>
    <SheetContent side="right">
      <SheetHeader>
        <SheetTitle>Sheet Title</SheetTitle>
        <SheetDescription>Sheet description goes here.</SheetDescription>
      </SheetHeader>
      <div className="py-4 text-zinc-300 text-sm">Content area.</div>
      <SheetFooter>
        <SheetClose asChild>
          <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Close</button>
        </SheetClose>
      </SheetFooter>
    </SheetContent>
  </Sheet>
);

export const Left = () => (
  <Sheet>
    <SheetTrigger asChild>
      <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Left</button>
    </SheetTrigger>
    <SheetContent side="left">
      <SheetHeader>
        <SheetTitle>Left Panel</SheetTitle>
      </SheetHeader>
      <div className="py-4 text-zinc-300 text-sm">Left-side content.</div>
    </SheetContent>
  </Sheet>
);

export const Top = () => (
  <Sheet>
    <SheetTrigger asChild>
      <button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Top</button>
    </SheetTrigger>
    <SheetContent side="top">
      <SheetHeader>
        <SheetTitle>Top Panel</SheetTitle>
      </SheetHeader>
    </SheetContent>
  </Sheet>
);
