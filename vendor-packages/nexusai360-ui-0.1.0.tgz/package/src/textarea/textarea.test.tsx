import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { createRef } from "react";
import { Textarea } from "./index";

describe("Textarea", () => {
  it("renders a textarea element", () => {
    render(<Textarea aria-label="desc" />);
    expect(screen.getByRole("textbox")).toBeInTheDocument();
  });

  it("accepts typed text", async () => {
    const user = userEvent.setup();
    render(<Textarea aria-label="desc" />);
    const ta = screen.getByRole("textbox");
    await user.type(ta, "Hello world");
    expect(ta).toHaveValue("Hello world");
  });

  it("renders with specified rows", () => {
    render(<Textarea aria-label="desc" rows={5} />);
    expect(screen.getByRole("textbox")).toHaveAttribute("rows", "5");
  });

  it("shows error styling", () => {
    render(<Textarea aria-label="desc" error />);
    const ta = screen.getByRole("textbox");
    expect(ta).toHaveAttribute("aria-invalid", "true");
    expect(ta.className).toContain("border-red-500");
  });

  it("shows error message", () => {
    render(<Textarea aria-label="desc" errorMessage="Too short" />);
    expect(screen.getByRole("alert")).toHaveTextContent("Too short");
  });

  it("shows character counter when showCounter and maxLength set", async () => {
    const user = userEvent.setup();
    render(<Textarea aria-label="desc" maxLength={10} showCounter />);
    expect(screen.getByText("0/10")).toBeInTheDocument();
    await user.type(screen.getByRole("textbox"), "abc");
    expect(screen.getByText("3/10")).toBeInTheDocument();
  });

  it("highlights counter in red at max", async () => {
    const user = userEvent.setup();
    render(<Textarea aria-label="desc" maxLength={3} showCounter />);
    await user.type(screen.getByRole("textbox"), "abc");
    const counter = screen.getByText("3/3");
    expect(counter.className).toContain("text-red-500");
  });

  it("disables the textarea", () => {
    render(<Textarea aria-label="desc" disabled />);
    expect(screen.getByRole("textbox")).toBeDisabled();
  });

  it("forwards ref", () => {
    const ref = createRef<HTMLTextAreaElement>();
    render(<Textarea ref={ref} aria-label="desc" />);
    expect(ref.current).toBeInstanceOf(HTMLTextAreaElement);
  });

  it("calls onChange", async () => {
    const user = userEvent.setup();
    const onChange = vi.fn();
    render(<Textarea aria-label="desc" onChange={onChange} />);
    await user.type(screen.getByRole("textbox"), "x");
    expect(onChange).toHaveBeenCalled();
  });

  it("sets aria-required when required", () => {
    render(<Textarea aria-label="desc" required />);
    expect(screen.getByRole("textbox")).toHaveAttribute("aria-required", "true");
  });

  it("has correct displayName", () => {
    expect(Textarea.displayName).toBe("Textarea");
  });

  it("applies autoResize class (resize-none)", () => {
    render(<Textarea aria-label="desc" autoResize />);
    expect(screen.getByRole("textbox").className).toContain("resize-none");
  });
});
