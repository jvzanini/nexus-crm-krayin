import { Textarea } from "./index";

export default { title: "Primitives/Textarea" };

export const Default = () => <Textarea placeholder="Write something..." />;
export const WithRows = () => <Textarea rows={6} placeholder="6 rows" />;
export const WithError = () => <Textarea error errorMessage="Too short" />;
export const WithCounter = () => <Textarea maxLength={100} showCounter placeholder="Max 100 chars" />;
export const AutoResize = () => <Textarea autoResize placeholder="Auto-resize" />;
export const Disabled = () => <Textarea disabled placeholder="Disabled" />;
