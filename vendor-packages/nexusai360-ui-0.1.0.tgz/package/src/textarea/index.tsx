import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../lib/cn";

const textareaVariants = cva(
  [
    "w-full min-w-0 rounded-md border bg-zinc-950 text-zinc-100 transition-colors",
    "placeholder:text-zinc-500",
    "outline-none resize-y",
    "focus-visible:border-violet-500 focus-visible:ring-2 focus-visible:ring-violet-500/50",
    "disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-zinc-900 disabled:text-zinc-600",
    "read-only:bg-zinc-900",
    "px-3 py-2 text-base",
  ].join(" "),
  {
    variants: {
      error: {
        true: "border-red-500 focus-visible:border-red-500 focus-visible:ring-red-500/30",
        false: "border-zinc-700 hover:border-zinc-500",
      },
    },
    defaultVariants: {
      error: false,
    },
  }
);

export interface TextareaProps
  extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "children">,
    VariantProps<typeof textareaVariants> {
  /** Error message displayed below textarea */
  errorMessage?: string;
  /** Auto-resize textarea to fit content */
  autoResize?: boolean;
  /** Show character counter when maxLength is set */
  showCounter?: boolean;
}

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  (
    {
      className,
      error = false,
      errorMessage,
      autoResize = false,
      showCounter = false,
      maxLength,
      rows = 3,
      id,
      value,
      defaultValue,
      onChange,
      "aria-describedby": ariaDescribedBy,
      ...props
    },
    ref
  ) => {
    const internalRef = React.useRef<HTMLTextAreaElement | null>(null);
    const [charCount, setCharCount] = React.useState(() => {
      const initial = (value ?? defaultValue ?? "") as string;
      return initial.length;
    });

    const hasError = error === true || !!errorMessage;
    const errorId = errorMessage ? `${id ?? "textarea"}-error` : undefined;
    const counterId = showCounter && maxLength ? `${id ?? "textarea"}-counter` : undefined;
    const describedBy =
      [ariaDescribedBy, errorId, counterId].filter(Boolean).join(" ") || undefined;

    const setRefs = React.useCallback(
      (node: HTMLTextAreaElement | null) => {
        internalRef.current = node;
        if (typeof ref === "function") {
          ref(node);
        } else if (ref) {
          (ref as React.MutableRefObject<HTMLTextAreaElement | null>).current = node;
        }
      },
      [ref]
    );

    const handleAutoResize = React.useCallback(() => {
      const el = internalRef.current;
      if (el && autoResize) {
        el.style.height = "auto";
        el.style.height = `${el.scrollHeight}px`;
      }
    }, [autoResize]);

    const handleChange = React.useCallback(
      (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setCharCount(e.target.value.length);
        handleAutoResize();
        onChange?.(e);
      },
      [onChange, handleAutoResize]
    );

    React.useEffect(() => {
      handleAutoResize();
    }, [handleAutoResize]);

    return (
      <div className="flex flex-col">
        <textarea
          ref={setRefs}
          id={id}
          className={cn(textareaVariants({ error: hasError }), autoResize && "resize-none", className)}
          rows={rows}
          maxLength={maxLength}
          value={value}
          defaultValue={defaultValue}
          onChange={handleChange}
          aria-invalid={hasError || undefined}
          aria-describedby={describedBy}
          aria-required={props.required || undefined}
          {...props}
        />
        <div className="flex items-center justify-between">
          {errorMessage && (
            <p id={errorId} className="mt-1 text-sm text-red-500" role="alert">
              {errorMessage}
            </p>
          )}
          {showCounter && maxLength && (
            <p
              id={counterId}
              className={cn(
                "mt-1 ml-auto text-xs",
                charCount >= maxLength ? "text-red-500" : "text-zinc-500"
              )}
            >
              {charCount}/{maxLength}
            </p>
          )}
        </div>
      </div>
    );
  }
);

Textarea.displayName = "Textarea";

export { Textarea, textareaVariants };
