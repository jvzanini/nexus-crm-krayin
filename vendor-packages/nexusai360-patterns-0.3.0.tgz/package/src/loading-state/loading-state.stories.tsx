import { LoadingState } from "./index";

export default { title: "Patterns/LoadingState" };

export const Spinner = () => <LoadingState variant="spinner" message="Loading data..." />;
export const Skeleton = () => <LoadingState variant="skeleton" />;
export const Dots = () => <LoadingState variant="dots" message="Please wait..." />;
export const FullPage = () => <LoadingState variant="spinner" fullPage message="Loading application..." />;
