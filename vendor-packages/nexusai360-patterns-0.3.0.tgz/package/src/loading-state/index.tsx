import * as React from "react";
import { Skeleton } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Spinner sub-component                                              */
/* ------------------------------------------------------------------ */
const Spinner: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={["animate-spin text-violet-500", className]
      .filter(Boolean)
      .join(" ")}
    xmlns="http://www.w3.org/2000/svg"
    fill="none"
    viewBox="0 0 24 24"
    aria-hidden="true"
  >
    <circle
      className="opacity-25"
      cx="12"
      cy="12"
      r="10"
      stroke="currentColor"
      strokeWidth="4"
    />
    <path
      className="opacity-75"
      fill="currentColor"
      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Dots sub-component                                                 */
/* ------------------------------------------------------------------ */
const Dots: React.FC = () => (
  <div className="flex items-center gap-1.5" aria-hidden="true">
    {[0, 1, 2].map((i) => (
      <div
        key={i}
        className="size-2 rounded-full bg-violet-500"
        style={{
          animation: "pulse 1.4s ease-in-out infinite",
          animationDelay: `${i * 0.2}s`,
        }}
      />
    ))}
  </div>
);

/* ------------------------------------------------------------------ */
/*  Skeleton layout                                                    */
/* ------------------------------------------------------------------ */
const SkeletonLayout: React.FC = () => (
  <div className="flex w-full max-w-lg flex-col gap-4" aria-hidden="true">
    <Skeleton height={20} width="60%" />
    <Skeleton height={14} width="100%" />
    <Skeleton height={14} width="80%" />
    <div className="flex gap-3 pt-2">
      <Skeleton height={40} width={120} />
      <Skeleton height={40} width={120} />
    </div>
  </div>
);

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export type LoadingVariant = "spinner" | "skeleton" | "dots";

export interface LoadingStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Visual variant */
  variant?: LoadingVariant;
  /** Optional message shown below the indicator */
  message?: string;
  /** Whether it fills the full page (min-h-screen) or just a section */
  fullPage?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const LoadingState = React.forwardRef<HTMLDivElement, LoadingStateProps>(
  (
    {
      className,
      variant = "spinner",
      message,
      fullPage = false,
      ...props
    },
    ref
  ) => {
    const indicator =
      variant === "spinner" ? (
        <Spinner className="size-8" />
      ) : variant === "dots" ? (
        <Dots />
      ) : (
        <SkeletonLayout />
      );

    return (
      <div
        ref={ref}
        role="status"
        aria-label={message ?? "Loading"}
        className={[
          "flex flex-col items-center justify-center gap-4",
          fullPage ? "min-h-screen" : "min-h-[200px]",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        {indicator}
        {message && (
          <p className="text-sm text-zinc-400">{message}</p>
        )}
      </div>
    );
  }
);

LoadingState.displayName = "LoadingState";

export { LoadingState };
