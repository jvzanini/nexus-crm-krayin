import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { LoadingState } from "./index";

describe("LoadingState", () => {
  it("renders spinner variant by default", () => {
    render(<LoadingState />);
    expect(screen.getByRole("status")).toBeInTheDocument();
  });

  it("renders with aria-label Loading", () => {
    render(<LoadingState />);
    expect(screen.getByRole("status")).toHaveAttribute("aria-label", "Loading");
  });

  it("renders custom message", () => {
    render(<LoadingState message="Please wait..." />);
    expect(screen.getByText("Please wait...")).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveAttribute(
      "aria-label",
      "Please wait..."
    );
  });

  it("renders skeleton variant", () => {
    const { container } = render(<LoadingState variant="skeleton" />);
    // Skeleton renders multiple animated-pulse divs
    const skeletons = container.querySelectorAll(".animate-pulse");
    expect(skeletons.length).toBeGreaterThan(0);
  });

  it("renders dots variant", () => {
    const { container } = render(<LoadingState variant="dots" />);
    const dots = container.querySelectorAll(".rounded-full");
    expect(dots.length).toBe(3);
  });

  it("applies fullPage class", () => {
    const { container } = render(<LoadingState fullPage />);
    expect(container.firstElementChild).toHaveClass("min-h-screen");
  });

  it("applies section class by default (no fullPage)", () => {
    const { container } = render(<LoadingState />);
    expect(container.firstElementChild).toHaveClass("min-h-[200px]");
  });
});
