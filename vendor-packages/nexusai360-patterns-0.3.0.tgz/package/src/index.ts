// Pre-existing patterns
export * from "./onboarding";

// Phase 18 — Page patterns
export { PageHeader } from "./page-header";
export type { PageHeaderProps, BreadcrumbEntry } from "./page-header";

export { PageShell } from "./page-shell";
export type { PageShellProps } from "./page-shell";

export { SectionHeader } from "./section-header";
export type { SectionHeaderProps } from "./section-header";

export { PatternEmptyState } from "./empty-state";
export type {
  PatternEmptyStateProps,
  EmptyStateVariant,
} from "./empty-state";

export { ErrorState } from "./error-state";
export type { ErrorStateProps } from "./error-state";

export { LoadingState } from "./loading-state";
export type {
  LoadingStateProps,
  LoadingVariant,
} from "./loading-state";

// Phase 19 — Data patterns
export { DataTable } from "./data-table";
export type {
  DataTableProps,
  DataTableColumnDef,
  DataTablePagination,
  SortState,
  ColumnDef,
} from "./data-table";

export { FilterBar } from "./filter-bar";
export type {
  FilterBarProps,
  FilterDefinition,
  FilterValues,
} from "./filter-bar";

export { ToolbarActions } from "./toolbar-actions";
export type {
  ToolbarActionsProps,
  ToolbarAction,
} from "./toolbar-actions";

export { BulkActions } from "./bulk-actions";
export type {
  BulkActionsProps,
  BulkAction,
} from "./bulk-actions";

export { InlineEdit } from "./inline-edit";
export type { InlineEditProps } from "./inline-edit";

// Phase 20 — Interactive patterns
export { FormDialog } from "./form-dialog";
export type { FormDialogProps } from "./form-dialog";

export { ConfirmDialog } from "./confirm-dialog";
export type {
  ConfirmDialogProps,
  ConfirmDialogVariant,
} from "./confirm-dialog";

export { SlideOver } from "./slide-over";
export type {
  SlideOverProps,
  SlideOverSide,
  SlideOverSize,
} from "./slide-over";

export { CommandMenu } from "./command-menu";
export type {
  CommandMenuProps,
  CommandAction,
} from "./command-menu";
export type { CommandGroup as CommandMenuGroup } from "./command-menu";

export { SearchPalette } from "./search-palette";
export type {
  SearchPaletteProps,
  SearchResult,
} from "./search-palette";

export { NotificationCenter } from "./notification-center";
export type {
  NotificationCenterProps,
  Notification,
} from "./notification-center";

// Phase 22 — Notification center deep components
export { NotificationItem } from "./notification-center";
export type { NotificationItemProps } from "./notification-center";
export { NotificationList } from "./notification-center";
export type { NotificationListProps } from "./notification-center";
export { NotificationBadge } from "./notification-center";
export type { NotificationBadgeProps } from "./notification-center";
export { useNotifications } from "./notification-center";
export type { UseNotificationsReturn } from "./notification-center";
export type {
  NotificationFull,
  NotificationType,
  NotificationState,
} from "./notification-center";

export { ProfileMenu } from "./profile-menu";
export type {
  ProfileMenuProps,
  UserInfo,
  ProfileMenuItem,
} from "./profile-menu";

export { OrgSwitcher } from "./org-switcher";
export type {
  OrgSwitcherProps,
  Organization,
} from "./org-switcher";

// Phase 34 — CRM app shell patterns
export { CrmShell } from "./crm-shell";
export type {
  CrmShellProps,
  CrmShellSidebarSlots,
  CrmShellTopbarSlots,
  CrmShellLabels,
} from "./crm-shell";

export { CrmListShell } from "./crm-list-shell";
export type { CrmListShellProps } from "./crm-list-shell";

export { CrmDetailShell } from "./crm-detail-shell";
export type { CrmDetailShellProps } from "./crm-detail-shell";

export { CrmDashboardGrid } from "./crm-dashboard-grid";
export type { CrmDashboardGridProps } from "./crm-dashboard-grid";
