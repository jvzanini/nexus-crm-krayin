"use client";

import type { CSSProperties } from "react";
import type { Notification } from "./types";

export interface NotificationItemProps {
  notification: Notification;
  onRead?: (id: string) => void;
  onDismiss?: (id: string) => void;
}

const TYPE_COLORS: Record<string, string> = {
  info: "#3b82f6",
  success: "#22c55e",
  warning: "#f59e0b",
  error: "#ef4444",
};

export function NotificationItem({
  notification,
  onRead,
  onDismiss,
}: NotificationItemProps) {
  const { id, title, description, type, read, createdAt, action } =
    notification;

  const containerStyle: CSSProperties = {
    display: "flex",
    gap: 12,
    padding: "12px 16px",
    borderBottom: "1px solid rgba(0,0,0,0.06)",
    background: read ? "transparent" : "rgba(59,130,246,0.04)",
    cursor: onRead && !read ? "pointer" : "default",
    transition: "background 150ms ease",
  };

  const indicatorStyle: CSSProperties = {
    width: 8,
    height: 8,
    borderRadius: "50%",
    background: read ? "transparent" : TYPE_COLORS[type] ?? TYPE_COLORS.info,
    marginTop: 6,
    flexShrink: 0,
  };

  const handleClick = () => {
    if (!read && onRead) onRead(id);
    action?.onClick?.();
  };

  const timeAgo = formatTimeAgo(createdAt);

  return (
    <div
      data-testid={`notification-item-${id}`}
      style={containerStyle}
      onClick={handleClick}
      role="article"
      aria-label={title}
    >
      <div style={indicatorStyle} data-testid={`notification-indicator-${id}`} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            gap: 8,
          }}
        >
          <strong
            style={{
              fontSize: 14,
              fontWeight: read ? 400 : 600,
              lineHeight: 1.4,
            }}
          >
            {title}
          </strong>
          {onDismiss && (
            <button
              type="button"
              data-testid={`notification-dismiss-${id}`}
              onClick={(e) => {
                e.stopPropagation();
                onDismiss(id);
              }}
              aria-label={`Dismiss ${title}`}
              style={{
                background: "transparent",
                border: 0,
                cursor: "pointer",
                padding: 2,
                fontSize: 16,
                lineHeight: 1,
                opacity: 0.4,
              }}
            >
              &times;
            </button>
          )}
        </div>
        {description && (
          <p
            style={{
              margin: "4px 0 0",
              fontSize: 13,
              opacity: 0.7,
              lineHeight: 1.4,
            }}
          >
            {description}
          </p>
        )}
        <span style={{ fontSize: 12, opacity: 0.5, marginTop: 4, display: "block" }}>
          {timeAgo}
        </span>
        {action?.href && (
          <a
            href={action.href}
            data-testid={`notification-action-${id}`}
            style={{
              fontSize: 13,
              color: TYPE_COLORS[type] ?? TYPE_COLORS.info,
              marginTop: 4,
              display: "inline-block",
              textDecoration: "none",
            }}
          >
            {action.label}
          </a>
        )}
      </div>
    </div>
  );
}
NotificationItem.displayName = "NotificationItem";

function formatTimeAgo(date: Date): string {
  const now = Date.now();
  const diff = now - date.getTime();
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
