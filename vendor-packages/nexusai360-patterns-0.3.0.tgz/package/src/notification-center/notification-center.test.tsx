import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { NotificationCenter, type Notification } from "./index";

const notifications: Notification[] = [
  {
    id: "1",
    title: "New message",
    description: "You have a new message from Alice",
    time: "2m ago",
    read: false,
  },
  {
    id: "2",
    title: "Task completed",
    time: "1h ago",
    read: true,
  },
  {
    id: "3",
    title: "System update",
    description: "System will be down for maintenance",
    time: "3h ago",
    read: false,
  },
];

describe("NotificationCenter", () => {
  it("renders bell trigger button", () => {
    render(<NotificationCenter notifications={notifications} />);
    expect(
      screen.getByLabelText(/Notifications/)
    ).toBeInTheDocument();
  });

  it("shows unread count badge", () => {
    render(<NotificationCenter notifications={notifications} />);
    expect(screen.getByText("2")).toBeInTheDocument();
  });

  it("shows custom unread count", () => {
    render(
      <NotificationCenter notifications={notifications} unreadCount={99} />
    );
    expect(screen.getByText("99")).toBeInTheDocument();
  });

  it("shows 99+ for large counts", () => {
    render(
      <NotificationCenter notifications={notifications} unreadCount={150} />
    );
    expect(screen.getByText("99+")).toBeInTheDocument();
  });

  it("opens dropdown on trigger click", () => {
    render(<NotificationCenter notifications={notifications} />);
    fireEvent.click(screen.getByLabelText(/Notifications/));
    expect(screen.getByText("Notifications")).toBeInTheDocument();
    expect(screen.getByText("New message")).toBeInTheDocument();
  });

  it("shows mark all read button when unread exist", () => {
    const onMarkAllRead = vi.fn();
    render(
      <NotificationCenter
        notifications={notifications}
        onMarkAllRead={onMarkAllRead}
      />
    );
    fireEvent.click(screen.getByLabelText(/Notifications/));
    expect(screen.getByText("Mark all read")).toBeInTheDocument();
  });

  it("calls onMarkAllRead", () => {
    const onMarkAllRead = vi.fn();
    render(
      <NotificationCenter
        notifications={notifications}
        onMarkAllRead={onMarkAllRead}
      />
    );
    fireEvent.click(screen.getByLabelText(/Notifications/));
    fireEvent.click(screen.getByText("Mark all read"));
    expect(onMarkAllRead).toHaveBeenCalledOnce();
  });

  it("shows empty state when no notifications", () => {
    render(<NotificationCenter notifications={[]} />);
    fireEvent.click(screen.getByLabelText("Notifications"));
    expect(screen.getByText("No notifications")).toBeInTheDocument();
  });

  it("limits visible notifications", () => {
    render(
      <NotificationCenter notifications={notifications} maxVisible={1} />
    );
    fireEvent.click(screen.getByLabelText(/Notifications/));
    expect(screen.getByText("New message")).toBeInTheDocument();
    expect(screen.queryByText("Task completed")).toBeNull();
  });
});
