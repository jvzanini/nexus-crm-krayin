import * as React from "react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
  Button,
  Badge,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Bell Icon                                                          */
/* ------------------------------------------------------------------ */
const BellIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    viewBox="0 0 20 20"
    fill="none"
    className={className}
    aria-hidden="true"
  >
    <path
      d="M10 2a5.5 5.5 0 00-5.5 5.5v2.7L3.3 12.4a1 1 0 00.7 1.6h12a1 1 0 00.7-1.6l-1.2-2.2V7.5A5.5 5.5 0 0010 2z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
    <path
      d="M8 14a2 2 0 004 0"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface Notification {
  /** Unique id */
  id: string;
  /** Title */
  title: string;
  /** Description/body */
  description?: string;
  /** Timestamp display string */
  time: string;
  /** Whether it's been read */
  read: boolean;
  /** Icon */
  icon?: React.ReactNode;
  /** Click handler */
  onClick?: () => void;
}

export interface NotificationCenterProps {
  /** List of notifications */
  notifications: Notification[];
  /** Callback to mark a single notification as read */
  onMarkRead?: (id: string) => void;
  /** Callback to mark all as read */
  onMarkAllRead?: () => void;
  /** Number of unread notifications (auto-computed if not provided) */
  unreadCount?: number;
  /** Maximum notifications shown (default: 5) */
  maxVisible?: number;
  /** View all link callback */
  onViewAll?: () => void;
  /** Additional className on the trigger button */
  triggerClassName?: string;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  onMarkRead,
  onMarkAllRead,
  unreadCount: controlledUnread,
  maxVisible = 5,
  onViewAll,
  triggerClassName,
}) => {
  const unreadCount =
    controlledUnread ?? notifications.filter((n) => !n.read).length;
  const visibleNotifications = notifications.slice(0, maxVisible);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className={["relative inline-flex h-9 w-9 items-center justify-center rounded-md p-0 hover:bg-muted/50", triggerClassName]
          .filter(Boolean)
          .join(" ")}
        aria-label={`Notifications${unreadCount > 0 ? ` (${unreadCount} unread)` : ""}`}
      >
        <BellIcon className="size-5" />
        {unreadCount > 0 && (
          <Badge
            variant="default"
            className="absolute -right-1 -top-1 flex size-5 items-center justify-center p-0 text-[10px]"
          >
            {unreadCount > 99 ? "99+" : unreadCount}
          </Badge>
        )}
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-80" align="end">
        <div className="flex items-center justify-between px-3 py-2">
          <DropdownMenuLabel className="p-0 text-sm font-semibold text-zinc-100">
            Notifications
          </DropdownMenuLabel>
          {unreadCount > 0 && onMarkAllRead && (
            <button
              type="button"
              className="text-xs text-violet-400 hover:text-violet-300 transition-colors"
              onClick={onMarkAllRead}
            >
              Mark all read
            </button>
          )}
        </div>
        <DropdownMenuSeparator />

        {visibleNotifications.length === 0 ? (
          <div className="py-8 text-center text-sm text-zinc-500">
            No notifications
          </div>
        ) : (
          visibleNotifications.map((notification) => (
            <DropdownMenuItem
              key={notification.id}
              className={[
                "flex flex-col items-start gap-1 px-3 py-2.5",
                !notification.read && "bg-zinc-900/50",
              ]
                .filter(Boolean)
                .join(" ")}
              onSelect={() => {
                if (!notification.read) onMarkRead?.(notification.id);
                notification.onClick?.();
              }}
            >
              <div className="flex w-full items-start gap-2">
                {notification.icon && (
                  <span className="mt-0.5 text-zinc-400">
                    {notification.icon}
                  </span>
                )}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-zinc-100">
                      {notification.title}
                    </span>
                    {!notification.read && (
                      <span className="size-1.5 rounded-full bg-violet-500" />
                    )}
                  </div>
                  {notification.description && (
                    <p className="text-xs text-zinc-400 line-clamp-2">
                      {notification.description}
                    </p>
                  )}
                </div>
                <span className="shrink-0 text-xs text-zinc-500">
                  {notification.time}
                </span>
              </div>
            </DropdownMenuItem>
          ))
        )}

        {onViewAll && notifications.length > maxVisible && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="justify-center text-sm text-violet-400"
              onSelect={onViewAll}
            >
              View all notifications
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

NotificationCenter.displayName = "NotificationCenter";

export { NotificationCenter };

// Phase 22 — Deep notification components
export { NotificationItem } from "./notification-item";
export type { NotificationItemProps } from "./notification-item";
export { NotificationList } from "./notification-list";
export type { NotificationListProps } from "./notification-list";
export { NotificationBadge } from "./notification-badge";
export type { NotificationBadgeProps } from "./notification-badge";
export { useNotifications } from "./use-notifications";
export type { UseNotificationsReturn } from "./use-notifications";
export type {
  Notification as NotificationFull,
  NotificationType,
  NotificationState,
} from "./types";
