"use client";

import { useCallback, useMemo, useState } from "react";
import type { Notification, NotificationState } from "./types";

export interface UseNotificationsReturn extends NotificationState {
  /** Add a new notification */
  add: (notification: Omit<Notification, "id" | "read" | "createdAt"> & { id?: string }) => void;
  /** Mark a single notification as read */
  markRead: (id: string) => void;
  /** Mark all notifications as read */
  markAllRead: () => void;
  /** Dismiss (remove) a notification */
  dismiss: (id: string) => void;
  /** Clear all notifications */
  clearAll: () => void;
}

let idCounter = 0;
function generateId(): string {
  idCounter += 1;
  return `notif-${Date.now()}-${idCounter}`;
}

export function useNotifications(
  initial: Notification[] = [],
): UseNotificationsReturn {
  const [notifications, setNotifications] = useState<Notification[]>(initial);

  const add = useCallback(
    (
      notif: Omit<Notification, "id" | "read" | "createdAt"> & { id?: string },
    ) => {
      const full: Notification = {
        ...notif,
        id: notif.id ?? generateId(),
        read: false,
        createdAt: new Date(),
      };
      setNotifications((prev) => [full, ...prev]);
    },
    [],
  );

  const markRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n)),
    );
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const dismiss = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  const unreadCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications],
  );

  return {
    notifications,
    unreadCount,
    add,
    markRead,
    markAllRead,
    dismiss,
    clearAll,
  };
}
