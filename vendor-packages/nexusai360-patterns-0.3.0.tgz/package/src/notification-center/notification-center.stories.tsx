import { NotificationCenter } from "./index";

export default { title: "Patterns/NotificationCenter" };

const notifications = [
  { id: "1", title: "New lead assigned", description: "Alice Johnson was assigned to you.", time: "2 min ago", read: false },
  { id: "2", title: "Deal closed", description: "Acme Corp deal was marked as won.", time: "1 hour ago", read: false },
  { id: "3", title: "Meeting reminder", description: "Team standup in 15 minutes.", time: "3 hours ago", read: true },
  { id: "4", title: "Report ready", description: "Monthly sales report is available.", time: "1 day ago", read: true },
];

export const Default = () => (
  <NotificationCenter
    notifications={notifications}
    onMarkRead={(id) => console.log("Mark read:", id)}
    onMarkAllRead={() => console.log("Mark all read")}
    onViewAll={() => console.log("View all")}
  />
);

export const AllRead = () => (
  <NotificationCenter
    notifications={notifications.map((n) => ({ ...n, read: true }))}
  />
);

export const Empty = () => <NotificationCenter notifications={[]} />;
