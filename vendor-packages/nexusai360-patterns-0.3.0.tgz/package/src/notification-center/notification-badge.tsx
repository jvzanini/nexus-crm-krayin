"use client";

import type { CSSProperties } from "react";

export interface NotificationBadgeProps {
  /** Number of unread notifications */
  count: number;
  /** Click handler (typically opens the notification panel) */
  onClick?: () => void;
  /** Max number to display before showing "N+" */
  max?: number;
  /** Custom aria-label */
  "aria-label"?: string;
}

export function NotificationBadge({
  count,
  onClick,
  max = 99,
  "aria-label": ariaLabel,
}: NotificationBadgeProps) {
  const displayCount = count > max ? `${max}+` : String(count);
  const label = ariaLabel ?? `${count} unread notification${count === 1 ? "" : "s"}`;

  const buttonStyle: CSSProperties = {
    position: "relative",
    background: "transparent",
    border: 0,
    cursor: "pointer",
    padding: 8,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
  };

  const badgeStyle: CSSProperties = {
    position: "absolute",
    top: 2,
    right: 2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    background: "#ef4444",
    color: "#fff",
    fontSize: 11,
    fontWeight: 700,
    display: count > 0 ? "flex" : "none",
    alignItems: "center",
    justifyContent: "center",
    padding: "0 4px",
    lineHeight: 1,
  };

  return (
    <button
      type="button"
      data-testid="notification-badge"
      onClick={onClick}
      aria-label={label}
      style={buttonStyle}
    >
      {/* Bell icon (inline SVG to avoid external dep) */}
      <svg
        data-testid="notification-bell-icon"
        width={20}
        height={20}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
        <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
      </svg>
      <span data-testid="notification-badge-count" style={badgeStyle}>
        {displayCount}
      </span>
    </button>
  );
}
NotificationBadge.displayName = "NotificationBadge";
