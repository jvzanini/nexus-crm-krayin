"use client";

import type { CSSProperties } from "react";
import type { Notification } from "./types";
import { NotificationItem } from "./notification-item";

export interface NotificationListProps {
  notifications: Notification[];
  /** Whether notifications are still loading */
  loading?: boolean;
  /** Message to show when empty */
  emptyMessage?: string;
  /** Called when a notification is read */
  onRead?: (id: string) => void;
  /** Called when a notification is dismissed */
  onDismiss?: (id: string) => void;
  /** Max height for the scrollable area */
  maxHeight?: number | string;
}

export function NotificationList({
  notifications,
  loading = false,
  emptyMessage = "No notifications",
  onRead,
  onDismiss,
  maxHeight = 400,
}: NotificationListProps) {
  const containerStyle: CSSProperties = {
    maxHeight,
    overflowY: "auto",
    overflowX: "hidden",
  };

  if (loading) {
    return (
      <div
        data-testid="notification-list-loading"
        style={{ padding: 24, textAlign: "center", opacity: 0.5 }}
      >
        Loading...
      </div>
    );
  }

  if (notifications.length === 0) {
    return (
      <div
        data-testid="notification-list-empty"
        style={{
          padding: 24,
          textAlign: "center",
          opacity: 0.5,
          fontSize: 14,
        }}
      >
        {emptyMessage}
      </div>
    );
  }

  return (
    <div data-testid="notification-list" style={containerStyle}>
      {notifications.map((n) => (
        <NotificationItem
          key={n.id}
          notification={n}
          onRead={onRead}
          onDismiss={onDismiss}
        />
      ))}
    </div>
  );
}
NotificationList.displayName = "NotificationList";
