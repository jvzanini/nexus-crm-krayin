/** Notification type for visual differentiation */
export type NotificationType = "info" | "success" | "warning" | "error";

/** A single notification */
export interface Notification {
  id: string;
  title: string;
  description?: string;
  type: NotificationType;
  read: boolean;
  createdAt: Date;
  /** Optional action (link, callback, etc.) */
  action?: {
    label: string;
    href?: string;
    onClick?: () => void;
  };
}

/** State shape for useNotifications hook */
export interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
}
