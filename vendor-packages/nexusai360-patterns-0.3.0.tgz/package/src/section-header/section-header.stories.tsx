import { SectionHeader } from "./index";

export default { title: "Patterns/SectionHeader" };

export const Default = () => <SectionHeader title="Team Members" />;

export const WithDescription = () => (
  <SectionHeader title="Integrations" description="Manage your connected services." />
);

export const WithAction = () => (
  <SectionHeader
    title="API Keys"
    description="Manage your API keys."
    action={<button className="px-3 py-1.5 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Generate Key</button>}
  />
);

export const AsH3 = () => <SectionHeader title="Subsection" as="h3" />;
