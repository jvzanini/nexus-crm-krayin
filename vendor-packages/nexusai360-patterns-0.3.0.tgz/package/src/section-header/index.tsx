import * as React from "react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface SectionHeaderProps
  extends React.HTMLAttributes<HTMLDivElement> {
  /** Section title */
  title: string;
  /** Optional description */
  description?: string;
  /** Optional action element (button, link, etc.) */
  action?: React.ReactNode;
  /** Heading level (default: h2) */
  as?: "h2" | "h3" | "h4";
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const SectionHeader = React.forwardRef<HTMLDivElement, SectionHeaderProps>(
  (
    { className, title, description, action, as: Heading = "h2", ...props },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={[
          "flex items-start justify-between gap-4 pb-4",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        <div className="flex flex-col gap-1">
          <Heading className="text-lg font-semibold text-zinc-50">
            {title}
          </Heading>
          {description && (
            <p className="text-sm text-zinc-400">{description}</p>
          )}
        </div>
        {action && (
          <div className="flex shrink-0 items-center gap-2">{action}</div>
        )}
      </div>
    );
  }
);

SectionHeader.displayName = "SectionHeader";

export { SectionHeader };
