import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { SectionHeader } from "./index";

describe("SectionHeader", () => {
  it("renders the title as h2 by default", () => {
    render(<SectionHeader title="Settings" />);
    const heading = screen.getByRole("heading", { name: "Settings" });
    expect(heading.tagName).toBe("H2");
  });

  it("renders description when provided", () => {
    render(
      <SectionHeader title="Settings" description="Manage your preferences" />
    );
    expect(screen.getByText("Manage your preferences")).toBeInTheDocument();
  });

  it("does not render description when not provided", () => {
    const { container } = render(<SectionHeader title="Settings" />);
    expect(container.querySelector("p")).toBeNull();
  });

  it("renders action element", () => {
    render(
      <SectionHeader
        title="Users"
        action={<button>Add</button>}
      />
    );
    expect(screen.getByRole("button", { name: "Add" })).toBeInTheDocument();
  });

  it("renders as h3 when specified", () => {
    render(<SectionHeader title="Sub" as="h3" />);
    const heading = screen.getByRole("heading", { name: "Sub" });
    expect(heading.tagName).toBe("H3");
  });

  it("renders as h4 when specified", () => {
    render(<SectionHeader title="Deep" as="h4" />);
    const heading = screen.getByRole("heading", { name: "Deep" });
    expect(heading.tagName).toBe("H4");
  });

  it("forwards className", () => {
    const { container } = render(
      <SectionHeader title="T" className="custom" />
    );
    expect(container.firstElementChild).toHaveClass("custom");
  });
});
