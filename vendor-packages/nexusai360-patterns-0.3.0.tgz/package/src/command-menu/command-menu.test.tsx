import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { CommandMenu, type CommandGroup } from "./index";

const commands: CommandGroup[] = [
  {
    heading: "Navigation",
    commands: [
      { value: "dashboard", label: "Dashboard", shortcut: "G D" },
      { value: "settings", label: "Settings" },
    ],
  },
  {
    heading: "Actions",
    commands: [
      { value: "create-user", label: "Create User" },
      { value: "disabled-action", label: "Disabled", disabled: true },
    ],
  },
];

describe("CommandMenu", () => {
  it("renders when open=true", () => {
    render(
      <CommandMenu commands={commands} onSelect={vi.fn()} open />
    );
    expect(screen.getByText("Dashboard")).toBeInTheDocument();
    expect(screen.getByText("Settings")).toBeInTheDocument();
  });

  it("renders group headings", () => {
    render(
      <CommandMenu commands={commands} onSelect={vi.fn()} open />
    );
    expect(screen.getByText("Navigation")).toBeInTheDocument();
    expect(screen.getByText("Actions")).toBeInTheDocument();
  });

  it("renders keyboard shortcut", () => {
    render(
      <CommandMenu commands={commands} onSelect={vi.fn()} open />
    );
    expect(screen.getByText("G D")).toBeInTheDocument();
  });

  it("renders search input", () => {
    render(
      <CommandMenu commands={commands} onSelect={vi.fn()} open />
    );
    expect(
      screen.getByPlaceholderText("Type a command or search...")
    ).toBeInTheDocument();
  });

  it("renders custom placeholder", () => {
    render(
      <CommandMenu
        commands={commands}
        onSelect={vi.fn()}
        open
        placeholder="Search commands..."
      />
    );
    expect(
      screen.getByPlaceholderText("Search commands...")
    ).toBeInTheDocument();
  });

  it("opens on Ctrl+K", () => {
    render(<CommandMenu commands={commands} onSelect={vi.fn()} />);
    fireEvent.keyDown(document, { key: "k", ctrlKey: true });
    expect(screen.getByText("Dashboard")).toBeInTheDocument();
  });

  it("calls onSelect when item clicked", () => {
    const onSelect = vi.fn();
    render(
      <CommandMenu commands={commands} onSelect={onSelect} open />
    );
    fireEvent.click(screen.getByText("Dashboard"));
    expect(onSelect).toHaveBeenCalledWith("dashboard");
  });

  it("renders custom empty message", () => {
    render(
      <CommandMenu
        commands={[{ heading: "Empty", commands: [] }]}
        onSelect={vi.fn()}
        open
        emptyMessage="Nothing found!"
      />
    );
    // With no search term and no items, shows the group heading at least
    expect(screen.getByText("Empty")).toBeInTheDocument();
  });
});
