import { useState } from "react";
import { CommandMenu } from "./index";

export default { title: "Patterns/CommandMenu" };

const commands = [
  {
    heading: "Navigation",
    commands: [
      { value: "home", label: "Go to Home", shortcut: "G H" },
      { value: "contacts", label: "Go to Contacts", shortcut: "G C" },
      { value: "settings", label: "Go to Settings", shortcut: "G S" },
    ],
  },
  {
    heading: "Actions",
    commands: [
      { value: "create-contact", label: "Create Contact", shortcut: "C" },
      { value: "export", label: "Export Data", shortcut: "E" },
      { value: "delete", label: "Delete Selected", disabled: true },
    ],
  },
];

export const Default = () => {
  const [open, setOpen] = useState(true);
  return (
    <>
      <button
        className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm"
        onClick={() => setOpen(true)}
      >
        Open Command Menu (Cmd+K)
      </button>
      <CommandMenu
        commands={commands}
        onSelect={(v) => console.log("Selected:", v)}
        open={open}
        onOpenChange={setOpen}
      />
    </>
  );
};
