import * as React from "react";
import {
  Dialog,
  DialogContent,
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandSeparator,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface CommandAction {
  /** Unique value/id */
  value: string;
  /** Display label */
  label: string;
  /** Icon rendered before label */
  icon?: React.ReactNode;
  /** Keyboard shortcut hint */
  shortcut?: string;
  /** Whether this action is disabled */
  disabled?: boolean;
  /** Search keywords */
  keywords?: string[];
}

export interface CommandGroup {
  /** Group heading */
  heading: string;
  /** Commands in this group */
  commands: CommandAction[];
}

export interface CommandMenuProps {
  /** Grouped commands */
  commands: CommandGroup[];
  /** Callback when a command is selected */
  onSelect: (value: string) => void;
  /** Placeholder for search input */
  placeholder?: string;
  /** Controlled open state */
  open?: boolean;
  /** Open change callback */
  onOpenChange?: (open: boolean) => void;
  /** Empty state message */
  emptyMessage?: string;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const CommandMenu: React.FC<CommandMenuProps> = ({
  commands,
  onSelect,
  placeholder = "Type a command or search...",
  open: controlledOpen,
  onOpenChange,
  emptyMessage = "No results found.",
}) => {
  const [internalOpen, setInternalOpen] = React.useState(false);
  const open = controlledOpen ?? internalOpen;

  const setOpen = React.useCallback(
    (v: boolean) => {
      setInternalOpen(v);
      onOpenChange?.(v);
    },
    [onOpenChange]
  );

  // Ctrl+K / Cmd+K handler
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen(!open);
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, setOpen]);

  const handleSelect = React.useCallback(
    (value: string) => {
      onSelect(value);
      setOpen(false);
    },
    [onSelect, setOpen]
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden p-0 shadow-lg">
        <Command onSelect={handleSelect} label="Command palette">
          <CommandInput placeholder={placeholder} />
          <CommandList>
            <CommandEmpty>{emptyMessage}</CommandEmpty>
            {commands.map((group, groupIdx) => (
              <React.Fragment key={group.heading}>
                {groupIdx > 0 && <CommandSeparator />}
                <CommandGroup heading={group.heading}>
                  {group.commands.map((cmd) => (
                    <CommandItem
                      key={cmd.value}
                      value={cmd.value}
                      disabled={cmd.disabled}
                      keywords={cmd.keywords}
                      onSelect={handleSelect}
                    >
                      {cmd.icon && (
                        <span className="mr-2 text-zinc-400">{cmd.icon}</span>
                      )}
                      <span className="flex-1">{cmd.label}</span>
                      {cmd.shortcut && (
                        <kbd className="ml-auto text-xs text-zinc-500 bg-zinc-800 px-1.5 py-0.5 rounded">
                          {cmd.shortcut}
                        </kbd>
                      )}
                    </CommandItem>
                  ))}
                </CommandGroup>
              </React.Fragment>
            ))}
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
};

CommandMenu.displayName = "CommandMenu";

export { CommandMenu };
