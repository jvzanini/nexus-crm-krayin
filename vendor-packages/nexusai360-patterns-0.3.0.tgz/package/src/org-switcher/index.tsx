import * as React from "react";
import {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  Dialog,
  DialogContent,
  DialogTrigger,
  Avatar,
  Button,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface Organization {
  /** Unique id */
  id: string;
  /** Organization name */
  name: string;
  /** Avatar/logo URL */
  avatar?: string;
  /** Plan or subtitle */
  plan?: string;
}

export interface OrgSwitcherProps {
  /** Currently active organization */
  currentOrg: Organization;
  /** All available organizations */
  orgs: Organization[];
  /** Switch callback */
  onSwitch: (orgId: string) => void;
  /** Additional className */
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Chevron Icon                                                       */
/* ------------------------------------------------------------------ */
const ChevronUpDown: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M5 6l3-3 3 3M5 10l3 3 3-3"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Check Icon                                                         */
/* ------------------------------------------------------------------ */
const CheckIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M3 8l4 4 6-7"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const OrgSwitcher: React.FC<OrgSwitcherProps> = ({
  currentOrg,
  orgs,
  onSwitch,
  className,
}) => {
  const [open, setOpen] = React.useState(false);

  const currentInitials = currentOrg.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const handleSelect = React.useCallback(
    (orgId: string) => {
      if (orgId !== currentOrg.id) {
        onSwitch(orgId);
      }
      setOpen(false);
    },
    [currentOrg.id, onSwitch]
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className={[
            "flex items-center gap-2 px-2 h-10 w-full justify-start",
            className,
          ]
            .filter(Boolean)
            .join(" ")}
          aria-label="Switch organization"
        >
          <Avatar
            src={currentOrg.avatar}
            fallback={currentInitials}
            size="xs"
          />
          <span className="flex-1 truncate text-left text-sm font-medium text-zinc-100">
            {currentOrg.name}
          </span>
          <ChevronUpDown />
        </Button>
      </DialogTrigger>
      <DialogContent className="overflow-hidden p-0">
        <Command label="Switch organization" onSelect={handleSelect}>
          <CommandInput placeholder="Search organizations..." />
          <CommandList>
            <CommandEmpty>No organizations found.</CommandEmpty>
            <CommandGroup heading="Organizations">
              {orgs.map((org) => {
                const initials = org.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .slice(0, 2)
                  .toUpperCase();
                const isActive = org.id === currentOrg.id;

                return (
                  <CommandItem
                    key={org.id}
                    value={org.id}
                    onSelect={handleSelect}
                  >
                    <Avatar
                      src={org.avatar}
                      fallback={initials}
                      size="xs"
                      className="mr-2"
                    />
                    <div className="flex flex-1 flex-col">
                      <span className="text-sm">{org.name}</span>
                      {org.plan && (
                        <span className="text-xs text-zinc-500">
                          {org.plan}
                        </span>
                      )}
                    </div>
                    {isActive && (
                      <span className="text-violet-400">
                        <CheckIcon />
                      </span>
                    )}
                  </CommandItem>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
};

OrgSwitcher.displayName = "OrgSwitcher";

export { OrgSwitcher };
