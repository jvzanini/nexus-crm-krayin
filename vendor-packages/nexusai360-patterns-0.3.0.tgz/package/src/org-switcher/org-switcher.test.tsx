import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { OrgSwitcher, type Organization } from "./index";

const orgs: Organization[] = [
  { id: "1", name: "Acme Corp", plan: "Enterprise" },
  { id: "2", name: "Startup Inc", plan: "Free" },
  { id: "3", name: "Big Co" },
];

describe("OrgSwitcher", () => {
  const defaultProps = {
    currentOrg: orgs[0],
    orgs,
    onSwitch: vi.fn(),
  };

  it("renders current org name", () => {
    render(<OrgSwitcher {...defaultProps} />);
    expect(screen.getByText("Acme Corp")).toBeInTheDocument();
  });

  it("renders trigger button with label", () => {
    render(<OrgSwitcher {...defaultProps} />);
    expect(
      screen.getByLabelText("Switch organization")
    ).toBeInTheDocument();
  });

  it("shows avatar initials", () => {
    render(<OrgSwitcher {...defaultProps} />);
    expect(screen.getByText("AC")).toBeInTheDocument();
  });

  it("opens command dialog on click", () => {
    render(<OrgSwitcher {...defaultProps} />);
    fireEvent.click(screen.getByLabelText("Switch organization"));
    expect(
      screen.getByPlaceholderText("Search organizations...")
    ).toBeInTheDocument();
  });

  it("lists all organizations", () => {
    render(<OrgSwitcher {...defaultProps} />);
    fireEvent.click(screen.getByLabelText("Switch organization"));
    expect(screen.getByText("Startup Inc")).toBeInTheDocument();
    expect(screen.getByText("Big Co")).toBeInTheDocument();
  });

  it("shows plan label", () => {
    render(<OrgSwitcher {...defaultProps} />);
    fireEvent.click(screen.getByLabelText("Switch organization"));
    expect(screen.getByText("Enterprise")).toBeInTheDocument();
    expect(screen.getByText("Free")).toBeInTheDocument();
  });

  it("calls onSwitch with org id on select", () => {
    const onSwitch = vi.fn();
    render(<OrgSwitcher {...defaultProps} onSwitch={onSwitch} />);
    fireEvent.click(screen.getByLabelText("Switch organization"));
    fireEvent.click(screen.getByText("Startup Inc"));
    expect(onSwitch).toHaveBeenCalledWith("2");
  });
});
