import { OrgSwitcher } from "./index";

export default { title: "Patterns/OrgSwitcher" };

const orgs = [
  { id: "1", name: "Nexus AI", plan: "Enterprise" },
  { id: "2", name: "Side Project", plan: "Free" },
  { id: "3", name: "Consulting LLC", plan: "Pro" },
];

export const Default = () => (
  <OrgSwitcher
    currentOrg={orgs[0]}
    orgs={orgs}
    onSwitch={(id) => console.log("Switch to:", id)}
  />
);

export const SingleOrg = () => (
  <OrgSwitcher
    currentOrg={orgs[0]}
    orgs={[orgs[0]]}
    onSwitch={() => {}}
  />
);
