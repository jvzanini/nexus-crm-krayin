import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { FormDialog } from "./index";

describe("FormDialog", () => {
  const defaultProps = {
    title: "Create User",
    trigger: <button>Open</button>,
    onSubmit: vi.fn((e) => e.preventDefault()),
    children: <input data-testid="name-field" />,
  };

  it("renders trigger button", () => {
    render(<FormDialog {...defaultProps} />);
    expect(screen.getByRole("button", { name: "Open" })).toBeInTheDocument();
  });

  it("opens dialog on trigger click", () => {
    render(<FormDialog {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByText("Create User")).toBeInTheDocument();
  });

  it("renders description when provided", () => {
    render(<FormDialog {...defaultProps} description="Fill the form" />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByText("Fill the form")).toBeInTheDocument();
  });

  it("renders children inside form", () => {
    render(<FormDialog {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByTestId("name-field")).toBeInTheDocument();
  });

  it("renders Save and Cancel buttons", () => {
    render(<FormDialog {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Save" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Cancel" })).toBeInTheDocument();
  });

  it("renders custom submit and cancel text", () => {
    render(
      <FormDialog
        {...defaultProps}
        submitText="Create"
        cancelText="Discard"
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Create" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Discard" })).toBeInTheDocument();
  });

  it("calls onSubmit on form submit", () => {
    const onSubmit = vi.fn((e: React.FormEvent) => e.preventDefault());
    render(<FormDialog {...defaultProps} onSubmit={onSubmit} />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    fireEvent.click(screen.getByRole("button", { name: "Save" }));
    expect(onSubmit).toHaveBeenCalledOnce();
  });

  it("disables buttons when loading", () => {
    render(<FormDialog {...defaultProps} loading open />);
    const saveBtn = screen.getByRole("button", { name: "Save" });
    expect(saveBtn).toBeDisabled();
  });
});
