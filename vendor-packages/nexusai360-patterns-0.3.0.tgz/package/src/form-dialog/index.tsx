import * as React from "react";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
  Button,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface FormDialogProps {
  /** Dialog title */
  title: string;
  /** Dialog description */
  description?: string;
  /** Trigger element that opens the dialog */
  trigger: React.ReactNode;
  /** Form content (FormField children) */
  children: React.ReactNode;
  /** Submit callback */
  onSubmit: (e: React.FormEvent<HTMLFormElement>) => void | Promise<void>;
  /** Whether submit is in progress */
  loading?: boolean;
  /** Submit button text (default: "Save") */
  submitText?: string;
  /** Cancel button text (default: "Cancel") */
  cancelText?: string;
  /** Controlled open state */
  open?: boolean;
  /** Open change callback */
  onOpenChange?: (open: boolean) => void;
  /** Additional className for the content */
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const FormDialog: React.FC<FormDialogProps> = ({
  title,
  description,
  trigger,
  children,
  onSubmit,
  loading = false,
  submitText = "Save",
  cancelText = "Cancel",
  open,
  onOpenChange,
  className,
}) => {
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    await onSubmit(e);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className={className}>
        <form onSubmit={handleSubmit} noValidate>
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
            {description && (
              <DialogDescription>{description}</DialogDescription>
            )}
          </DialogHeader>

          <div className="flex flex-col gap-4 py-4">{children}</div>

          <DialogFooter>
            <DialogClose asChild>
              <Button variant="secondary" type="button" disabled={loading}>
                {cancelText}
              </Button>
            </DialogClose>
            <Button
              variant="primary"
              type="submit"
              loading={loading}
              disabled={loading}
            >
              {submitText}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

FormDialog.displayName = "FormDialog";

export { FormDialog };
