import { FormDialog } from "./index";

export default { title: "Patterns/FormDialog" };

export const Default = () => (
  <FormDialog
    title="Create Contact"
    description="Fill in the details below."
    trigger={<button className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm">New Contact</button>}
    onSubmit={(e) => { e.preventDefault(); }}
  >
    <div className="flex flex-col gap-3">
      <label className="text-sm text-zinc-300">
        Name
        <input className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100" />
      </label>
      <label className="text-sm text-zinc-300">
        Email
        <input className="mt-1 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100" type="email" />
      </label>
    </div>
  </FormDialog>
);

export const Loading = () => (
  <FormDialog
    title="Saving..."
    trigger={<button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open</button>}
    onSubmit={(e) => e.preventDefault()}
    loading
  >
    <div className="text-sm text-zinc-400">Form content</div>
  </FormDialog>
);
