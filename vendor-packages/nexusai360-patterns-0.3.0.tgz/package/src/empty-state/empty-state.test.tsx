import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { PatternEmptyState } from "./index";

describe("PatternEmptyState", () => {
  it("renders default no-data variant", () => {
    render(<PatternEmptyState />);
    expect(screen.getByText("No data yet")).toBeInTheDocument();
    expect(
      screen.getByText("Get started by creating your first item.")
    ).toBeInTheDocument();
  });

  it("renders no-results variant", () => {
    render(<PatternEmptyState variant="no-results" />);
    expect(screen.getByText("No results found")).toBeInTheDocument();
  });

  it("renders error variant", () => {
    render(<PatternEmptyState variant="error" />);
    expect(screen.getByText("Something went wrong")).toBeInTheDocument();
  });

  it("renders no-access variant", () => {
    render(<PatternEmptyState variant="no-access" />);
    expect(screen.getByText("Access denied")).toBeInTheDocument();
  });

  it("overrides title and description", () => {
    render(
      <PatternEmptyState
        variant="error"
        title="Custom Title"
        description="Custom desc"
      />
    );
    expect(screen.getByText("Custom Title")).toBeInTheDocument();
    expect(screen.getByText("Custom desc")).toBeInTheDocument();
  });

  it("renders string action as a Button", () => {
    const onAction = vi.fn();
    render(
      <PatternEmptyState action="Create" onAction={onAction} />
    );
    const btn = screen.getByRole("button", { name: "Create" });
    expect(btn).toBeInTheDocument();
    fireEvent.click(btn);
    expect(onAction).toHaveBeenCalledOnce();
  });

  it("renders ReactNode action as-is", () => {
    render(
      <PatternEmptyState action={<a href="/create">Create link</a>} />
    );
    expect(screen.getByText("Create link")).toBeInTheDocument();
  });

  it("renders custom icon", () => {
    render(
      <PatternEmptyState icon={<span data-testid="custom-icon" />} />
    );
    expect(screen.getByTestId("custom-icon")).toBeInTheDocument();
  });
});
