import * as React from "react";
import { EmptyState as UiEmptyState, Button } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Default illustrations (inline SVGs per variant)                    */
/* ------------------------------------------------------------------ */
const illustrations: Record<EmptyStateVariant, React.ReactNode> = {
  "no-data": (
    <svg viewBox="0 0 48 48" fill="none" className="size-12" aria-hidden="true">
      <rect x="8" y="12" width="32" height="24" rx="4" stroke="currentColor" strokeWidth="2" />
      <path d="M16 24h16M16 30h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  "no-results": (
    <svg viewBox="0 0 48 48" fill="none" className="size-12" aria-hidden="true">
      <circle cx="22" cy="22" r="10" stroke="currentColor" strokeWidth="2" />
      <path d="M30 30l8 8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <path d="M18 22h8" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  error: (
    <svg viewBox="0 0 48 48" fill="none" className="size-12" aria-hidden="true">
      <circle cx="24" cy="24" r="16" stroke="currentColor" strokeWidth="2" />
      <path d="M24 16v10M24 30v2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  ),
  "no-access": (
    <svg viewBox="0 0 48 48" fill="none" className="size-12" aria-hidden="true">
      <rect x="14" y="20" width="20" height="16" rx="3" stroke="currentColor" strokeWidth="2" />
      <path d="M20 20v-4a4 4 0 018 0v4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
      <circle cx="24" cy="28" r="2" fill="currentColor" />
    </svg>
  ),
};

const defaultTitles: Record<EmptyStateVariant, string> = {
  "no-data": "No data yet",
  "no-results": "No results found",
  error: "Something went wrong",
  "no-access": "Access denied",
};

const defaultDescriptions: Record<EmptyStateVariant, string> = {
  "no-data": "Get started by creating your first item.",
  "no-results": "Try adjusting your search or filter criteria.",
  error: "An unexpected error occurred. Please try again.",
  "no-access": "You don't have permission to view this resource.",
};

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export type EmptyStateVariant = "no-data" | "no-results" | "error" | "no-access";

export interface PatternEmptyStateProps
  extends React.HTMLAttributes<HTMLDivElement> {
  /** Visual variant — controls default icon, title, and description */
  variant?: EmptyStateVariant;
  /** Override title */
  title?: string;
  /** Override description */
  description?: string;
  /** Action element — if string, renders as primary Button */
  action?: React.ReactNode | string;
  /** Callback for string actions */
  onAction?: () => void;
  /** Custom icon (overrides variant default) */
  icon?: React.ReactNode;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const PatternEmptyState = React.forwardRef<HTMLDivElement, PatternEmptyStateProps>(
  (
    {
      variant = "no-data",
      title,
      description,
      action,
      onAction,
      icon,
      ...props
    },
    ref
  ) => {
    const resolvedIcon = icon ?? illustrations[variant];
    const resolvedTitle = title ?? defaultTitles[variant];
    const resolvedDescription = description ?? defaultDescriptions[variant];

    const resolvedAction =
      typeof action === "string" ? (
        <Button variant="primary" size="sm" onClick={onAction}>
          {action}
        </Button>
      ) : (
        action
      );

    return (
      <UiEmptyState
        ref={ref}
        icon={resolvedIcon}
        title={resolvedTitle}
        description={resolvedDescription}
        action={resolvedAction}
        {...props}
      />
    );
  }
);

PatternEmptyState.displayName = "PatternEmptyState";

export { PatternEmptyState };
