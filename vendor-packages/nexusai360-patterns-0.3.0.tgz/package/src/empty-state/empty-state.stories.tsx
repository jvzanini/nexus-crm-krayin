import { PatternEmptyState } from "./index";

export default { title: "Patterns/EmptyState" };

export const NoData = () => <PatternEmptyState variant="no-data" />;
export const NoResults = () => <PatternEmptyState variant="no-results" />;
export const Error = () => <PatternEmptyState variant="error" />;
export const NoAccess = () => <PatternEmptyState variant="no-access" />;

export const Custom = () => (
  <PatternEmptyState
    title="No projects yet"
    description="Create your first project to get started."
    action="Create Project"
    onAction={() => {}}
  />
);
