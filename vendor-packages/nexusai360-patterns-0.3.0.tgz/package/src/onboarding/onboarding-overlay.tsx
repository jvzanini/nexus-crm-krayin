"use client";

import { useEffect, useState, type CSSProperties } from "react";
import { useOnboardingPattern } from "./onboarding-provider";

export interface OnboardingOverlayProps {
  /** CSS selector of the element to spotlight. Overrides the step's targetSelector. */
  targetSelector?: string;
  /** Tooltip position relative to target */
  position?: "top" | "bottom" | "left" | "right";
  /** Overlay background color */
  overlayColor?: string;
  /** Z-index for the overlay */
  zIndex?: number;
  /** Content to render in the tooltip area */
  children?: React.ReactNode;
}

interface Rect {
  top: number;
  left: number;
  width: number;
  height: number;
}

function useTargetRect(selector: string | undefined): Rect | null {
  const [rect, setRect] = useState<Rect | null>(null);

  useEffect(() => {
    if (!selector) {
      setRect(null);
      return;
    }
    const update = () => {
      if (typeof document === "undefined") return;
      const el = document.querySelector(selector);
      if (!el) {
        setRect(null);
        return;
      }
      const r = el.getBoundingClientRect();
      setRect({ top: r.top, left: r.left, width: r.width, height: r.height });
    };
    update();
    window.addEventListener("resize", update);
    window.addEventListener("scroll", update, true);
    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("scroll", update, true);
    };
  }, [selector]);

  return rect;
}

function computeTooltipStyle(
  rect: Rect | null,
  position: "top" | "bottom" | "left" | "right",
): CSSProperties {
  if (!rect) {
    return { position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)" };
  }
  const gap = 12;
  const base: CSSProperties = { position: "fixed", zIndex: 1 };
  switch (position) {
    case "top":
      return { ...base, bottom: `calc(100vh - ${rect.top}px + ${gap}px)`, left: rect.left };
    case "bottom":
      return { ...base, top: rect.top + rect.height + gap, left: rect.left };
    case "left":
      return { ...base, top: rect.top, right: `calc(100vw - ${rect.left}px + ${gap}px)` };
    case "right":
      return { ...base, top: rect.top, left: rect.left + rect.width + gap };
    default:
      return { ...base, top: rect.top + rect.height + gap, left: rect.left };
  }
}

export function OnboardingOverlay({
  targetSelector,
  position = "bottom",
  overlayColor = "rgba(0,0,0,0.5)",
  zIndex = 9998,
  children,
}: OnboardingOverlayProps) {
  const { currentStep, isComplete } = useOnboardingPattern();

  const effectiveSelector = targetSelector ?? currentStep?.targetSelector;
  const effectivePosition = position ?? currentStep?.position ?? "bottom";
  const targetRect = useTargetRect(effectiveSelector);

  if (isComplete || !currentStep) return null;

  const spotlightStyle: CSSProperties = targetRect
    ? {
        position: "fixed",
        top: targetRect.top - 4,
        left: targetRect.left - 4,
        width: targetRect.width + 8,
        height: targetRect.height + 8,
        borderRadius: 8,
        boxShadow: `0 0 0 9999px ${overlayColor}`,
        zIndex,
        pointerEvents: "none" as const,
      }
    : {
        position: "fixed",
        inset: 0,
        background: overlayColor,
        zIndex,
        pointerEvents: "none" as const,
      };

  const tooltipStyle = computeTooltipStyle(targetRect, effectivePosition);

  return (
    <>
      <div data-testid="onboarding-overlay" style={spotlightStyle} />
      {children && (
        <div
          data-testid="onboarding-tooltip"
          style={{ ...tooltipStyle, zIndex: zIndex + 1 }}
        >
          {children}
        </div>
      )}
    </>
  );
}
OnboardingOverlay.displayName = "OnboardingOverlay";
