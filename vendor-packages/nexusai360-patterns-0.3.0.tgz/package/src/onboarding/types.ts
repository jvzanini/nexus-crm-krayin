/** Step definition for onboarding flow */
export interface OnboardingStepConfig {
  /** Unique identifier */
  id: string;
  /** Step title */
  title: string;
  /** Step description/body text */
  description: string;
  /** CSS selector for the target element to highlight */
  targetSelector: string;
  /** Tooltip placement relative to target */
  position: "top" | "bottom" | "left" | "right";
  /** Optional image URL to show in the step */
  image?: string;
  /** Action label override (defaults to "Next") */
  actionLabel?: string;
}

/** Onboarding flow state */
export interface OnboardingState {
  currentStepIndex: number;
  isComplete: boolean;
  skipped: boolean;
}

/** Storage adapter for persistence */
export interface OnboardingStorage {
  get: (key: string) => string | null;
  set: (key: string, value: string) => void;
  remove: (key: string) => void;
}

/** Context value exposed by OnboardingProvider */
export interface OnboardingContextValue {
  /** Current step definition (null if complete/skipped) */
  currentStep: OnboardingStepConfig | null;
  /** Current step index */
  currentStepIndex: number;
  /** Total steps */
  totalSteps: number;
  /** Progress as 0-1 fraction */
  progress: number;
  /** Whether the onboarding is complete */
  isComplete: boolean;
  /** Go to next step */
  nextStep: () => void;
  /** Go to previous step */
  prevStep: () => void;
  /** Skip the entire onboarding */
  skipAll: () => void;
}

/** Props for OnboardingProvider */
export interface OnboardingProviderProps {
  /** Step definitions */
  steps: OnboardingStepConfig[];
  /** Called when onboarding completes (all steps done) */
  onComplete?: () => void;
  /** localStorage key for persistence. If omitted, state lives in memory only. */
  storageKey?: string;
  /** Custom storage adapter. Defaults to localStorage. */
  storage?: OnboardingStorage;
  /** Children */
  children: React.ReactNode;
}
