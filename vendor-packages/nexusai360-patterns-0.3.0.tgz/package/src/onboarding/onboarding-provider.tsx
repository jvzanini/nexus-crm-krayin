"use client";

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";
import type {
  OnboardingContextValue,
  OnboardingProviderProps,
  OnboardingState,
  OnboardingStorage,
} from "./types";

const OnboardingCtx = createContext<OnboardingContextValue | null>(null);
OnboardingCtx.displayName = "OnboardingContext";

const DEFAULT_STORAGE: OnboardingStorage =
  typeof window !== "undefined" && window.localStorage
    ? {
        get: (key) => localStorage.getItem(key),
        set: (key, value) => localStorage.setItem(key, value),
        remove: (key) => localStorage.removeItem(key),
      }
    : {
        get: () => null,
        set: () => {},
        remove: () => {},
      };

function loadState(
  storageKey: string | undefined,
  storage: OnboardingStorage,
): OnboardingState | null {
  if (!storageKey) return null;
  try {
    const raw = storage.get(storageKey);
    if (!raw) return null;
    return JSON.parse(raw) as OnboardingState;
  } catch {
    return null;
  }
}

function saveState(
  state: OnboardingState,
  storageKey: string | undefined,
  storage: OnboardingStorage,
): void {
  if (!storageKey) return;
  try {
    storage.set(storageKey, JSON.stringify(state));
  } catch {
    // silently ignore storage errors
  }
}

export function OnboardingProvider({
  steps,
  onComplete,
  storageKey,
  storage = DEFAULT_STORAGE,
  children,
}: OnboardingProviderProps) {
  const [state, setState] = useState<OnboardingState>(() => {
    const persisted = loadState(storageKey, storage);
    if (persisted) return persisted;
    return { currentStepIndex: 0, isComplete: false, skipped: false };
  });

  const nextStep = useCallback(() => {
    setState((prev) => {
      if (prev.isComplete || prev.skipped) return prev;
      const nextIndex = prev.currentStepIndex + 1;
      if (nextIndex >= steps.length) {
        const next: OnboardingState = {
          ...prev,
          currentStepIndex: steps.length,
          isComplete: true,
        };
        saveState(next, storageKey, storage);
        onComplete?.();
        return next;
      }
      const next: OnboardingState = { ...prev, currentStepIndex: nextIndex };
      saveState(next, storageKey, storage);
      return next;
    });
  }, [steps.length, storageKey, storage, onComplete]);

  const prevStep = useCallback(() => {
    setState((prev) => {
      if (prev.isComplete || prev.skipped) return prev;
      if (prev.currentStepIndex <= 0) return prev;
      const next: OnboardingState = {
        ...prev,
        currentStepIndex: prev.currentStepIndex - 1,
      };
      saveState(next, storageKey, storage);
      return next;
    });
  }, [storageKey, storage]);

  const skipAll = useCallback(() => {
    setState((prev) => {
      const next: OnboardingState = { ...prev, skipped: true, isComplete: true };
      saveState(next, storageKey, storage);
      return next;
    });
  }, [storageKey, storage]);

  const value = useMemo<OnboardingContextValue>(
    () => ({
      currentStep:
        state.isComplete || state.skipped
          ? null
          : steps[state.currentStepIndex] ?? null,
      currentStepIndex: state.currentStepIndex,
      totalSteps: steps.length,
      progress:
        steps.length === 0
          ? 1
          : Math.min(state.currentStepIndex / steps.length, 1),
      isComplete: state.isComplete,
      nextStep,
      prevStep,
      skipAll,
    }),
    [state, steps, nextStep, prevStep, skipAll],
  );

  return (
    <OnboardingCtx.Provider value={value}>{children}</OnboardingCtx.Provider>
  );
}
OnboardingProvider.displayName = "OnboardingProvider";

export function useOnboardingPattern(): OnboardingContextValue {
  const ctx = useContext(OnboardingCtx);
  if (!ctx) {
    throw new Error(
      "[@nexusai360/patterns] useOnboardingPattern must be used within <OnboardingProvider>",
    );
  }
  return ctx;
}
