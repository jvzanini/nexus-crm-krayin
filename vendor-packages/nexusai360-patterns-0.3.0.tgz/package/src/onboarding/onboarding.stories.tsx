import { OnboardingProvider, OnboardingProgress, OnboardingStep } from "./index";
import type { OnboardingStepConfig } from "./index";

export default { title: "Patterns/Onboarding" };

const steps: OnboardingStepConfig[] = [
  { id: "welcome", title: "Welcome", description: "Let's get you started.", targetSelector: "#step-1", position: "bottom" },
  { id: "create", title: "Create your first item", description: "Click the button to create.", targetSelector: "#step-2", position: "bottom" },
  { id: "done", title: "All set!", description: "You're ready to go.", targetSelector: "#step-3", position: "bottom" },
];

export const Progress = () => (
  <OnboardingProvider steps={steps}>
    <div className="flex flex-col gap-4 p-4">
      <OnboardingProgress variant="bar" />
      <OnboardingProgress variant="dots" />
    </div>
  </OnboardingProvider>
);

export const StepCard = () => (
  <OnboardingProvider steps={steps}>
    <OnboardingStep
      title="Welcome to Nexus"
      description="This is your dashboard. Let's explore the main features."
      showBack={false}
    />
  </OnboardingProvider>
);

export const StepWithSkip = () => (
  <OnboardingProvider steps={steps}>
    <OnboardingStep
      title="Create a Contact"
      description="Click the add button to create your first contact."
      action="skip"
      skipLabel="Skip tour"
      showBack
    />
  </OnboardingProvider>
);
