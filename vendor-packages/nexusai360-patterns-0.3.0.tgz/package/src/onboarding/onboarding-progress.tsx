"use client";

import type { CSSProperties } from "react";
import { useOnboardingPattern } from "./onboarding-provider";

export interface OnboardingProgressProps {
  /** Override total steps (defaults to context totalSteps) */
  totalSteps?: number;
  /** Override current step index (defaults to context currentStepIndex) */
  currentStep?: number;
  /** Visual variant: "bar" for progress bar, "dots" for dot indicators */
  variant?: "bar" | "dots";
  /** Custom class name */
  className?: string;
}

export function OnboardingProgress({
  totalSteps: totalOverride,
  currentStep: currentOverride,
  variant = "bar",
  className,
}: OnboardingProgressProps) {
  const ctx = useOnboardingPattern();
  const total = totalOverride ?? ctx.totalSteps;
  const current = currentOverride ?? ctx.currentStepIndex;
  const pct = total === 0 ? 0 : Math.round((current / total) * 100);

  if (ctx.isComplete) return null;

  if (variant === "dots") {
    return (
      <div
        data-testid="onboarding-progress-dots"
        className={className}
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={total}
        aria-valuenow={current}
        style={{ display: "flex", gap: 6, alignItems: "center" }}
      >
        {Array.from({ length: total }, (_, i) => {
          const isActive = i === current;
          const isDone = i < current;
          const dotStyle: CSSProperties = {
            width: isActive ? 10 : 8,
            height: isActive ? 10 : 8,
            borderRadius: "50%",
            background: isDone || isActive
              ? "var(--primary, #3b82f6)"
              : "rgba(0,0,0,0.15)",
            transition: "all 200ms ease",
          };
          return <div key={i} data-testid={`onboarding-dot-${i}`} style={dotStyle} />;
        })}
      </div>
    );
  }

  return (
    <div
      data-testid="onboarding-progress-bar"
      className={className}
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={pct}
      style={{
        width: "100%",
        height: 4,
        background: "rgba(0,0,0,0.08)",
        borderRadius: 999,
        overflow: "hidden",
      }}
    >
      <div
        style={{
          width: `${pct}%`,
          height: "100%",
          background: "var(--primary, #3b82f6)",
          transition: "width 200ms ease",
        }}
      />
    </div>
  );
}
OnboardingProgress.displayName = "OnboardingProgress";
