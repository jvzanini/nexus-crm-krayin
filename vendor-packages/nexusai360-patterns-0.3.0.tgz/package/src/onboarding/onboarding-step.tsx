"use client";

import { useOnboardingPattern } from "./onboarding-provider";

export interface OnboardingStepProps {
  /** Step title */
  title: string;
  /** Step description */
  description: string;
  /** Action type: "next" advances, "skip" skips all */
  action?: "next" | "skip";
  /** Image URL */
  image?: string;
  /** Custom action label */
  actionLabel?: string;
  /** Custom skip label */
  skipLabel?: string;
  /** Whether to show a back button */
  showBack?: boolean;
}

export function OnboardingStep({
  title,
  description,
  action = "next",
  image,
  actionLabel,
  skipLabel = "Skip",
  showBack = false,
}: OnboardingStepProps) {
  const { nextStep, prevStep, skipAll, currentStepIndex } =
    useOnboardingPattern();

  const defaultLabel = action === "next" ? "Next" : "Skip";
  const label = actionLabel ?? defaultLabel;

  const handleAction = () => {
    if (action === "skip") {
      skipAll();
    } else {
      nextStep();
    }
  };

  return (
    <div
      data-testid="onboarding-step"
      style={{
        background: "var(--background, #fff)",
        color: "var(--foreground, #000)",
        padding: 16,
        borderRadius: 8,
        boxShadow: "0 10px 30px rgba(0,0,0,0.2)",
        maxWidth: 360,
      }}
    >
      {image && (
        <img
          src={image}
          alt={title}
          data-testid="onboarding-step-image"
          style={{
            width: "100%",
            borderRadius: 6,
            marginBottom: 12,
            objectFit: "cover",
          }}
        />
      )}
      <h3 style={{ margin: 0, fontSize: 16, fontWeight: 600 }}>{title}</h3>
      <p style={{ margin: "8px 0 0", fontSize: 14, opacity: 0.8 }}>
        {description}
      </p>
      <div
        style={{
          marginTop: 12,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          gap: 8,
        }}
      >
        <div style={{ display: "flex", gap: 8 }}>
          {showBack && currentStepIndex > 0 && (
            <button
              type="button"
              data-testid="onboarding-step-back"
              onClick={prevStep}
              style={{
                padding: "6px 12px",
                borderRadius: 6,
                border: "1px solid rgba(0,0,0,0.15)",
                background: "transparent",
                cursor: "pointer",
              }}
            >
              Back
            </button>
          )}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {action === "next" && (
            <button
              type="button"
              data-testid="onboarding-step-skip"
              onClick={skipAll}
              style={{
                padding: "6px 12px",
                borderRadius: 6,
                border: 0,
                background: "transparent",
                cursor: "pointer",
                opacity: 0.6,
              }}
            >
              {skipLabel}
            </button>
          )}
          <button
            type="button"
            data-testid="onboarding-step-action"
            onClick={handleAction}
            style={{
              padding: "6px 12px",
              borderRadius: 6,
              border: 0,
              background: "var(--primary, #3b82f6)",
              color: "#fff",
              cursor: "pointer",
            }}
          >
            {label}
          </button>
        </div>
      </div>
    </div>
  );
}
OnboardingStep.displayName = "OnboardingStep";
