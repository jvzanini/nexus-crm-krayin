export { CrmShell } from "./crm-shell";
export type {
  CrmShellProps,
  CrmShellSidebarSlots,
  CrmShellTopbarSlots,
  CrmShellLabels,
} from "./crm-shell";
