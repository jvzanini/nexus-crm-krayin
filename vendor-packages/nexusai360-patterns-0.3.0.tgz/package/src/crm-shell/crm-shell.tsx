"use client";

import * as React from "react";

export interface CrmShellSidebarSlots {
  logo: React.ReactNode;
  search?: React.ReactNode;
  nav: React.ReactNode;
  themeCycler?: React.ReactNode;
  userMenu: React.ReactNode;
  footer?: React.ReactNode;
}

export interface CrmShellTopbarSlots {
  breadcrumbs?: React.ReactNode;
  notifications?: React.ReactNode;
  actions?: React.ReactNode;
}

export interface CrmShellLabels {
  skipLink?: string;
  expandSidebar?: string;
  collapseSidebar?: string;
  openMobileMenu?: string;
  closeMobileMenu?: string;
}

export interface CrmShellProps {
  sidebar: CrmShellSidebarSlots;
  topbar?: CrmShellTopbarSlots;
  labels?: CrmShellLabels;
  children: React.ReactNode;
}

const DEFAULT_LABELS: Required<CrmShellLabels> = {
  skipLink: "Pular para o conteúdo",
  expandSidebar: "Expandir menu",
  collapseSidebar: "Recolher menu",
  openMobileMenu: "Abrir menu",
  closeMobileMenu: "Fechar menu",
};

function SidebarInner({ slots }: { slots: CrmShellSidebarSlots }) {
  return (
    <div className="flex h-full flex-col">
      <div className="px-4 py-4 border-b border-border">{slots.logo}</div>
      {slots.search && (
        <div className="px-3 py-2 border-b border-border">{slots.search}</div>
      )}
      <div className="flex-1 overflow-y-auto px-2 py-3">{slots.nav}</div>
      <div className="mt-auto border-t border-border">
        {slots.themeCycler && (
          <div className="px-3 py-2 border-b border-border">
            {slots.themeCycler}
          </div>
        )}
        <div className="px-3 py-2 border-b border-border">{slots.userMenu}</div>
        {slots.footer && <div className="px-3 py-2">{slots.footer}</div>}
      </div>
    </div>
  );
}

/**
 * CrmShell — shell admin standalone.
 * Implementa skip link canônico (#main), landmark único (role=banner em header),
 * nav com aria-label="Primária", main id=main (para skip link), mobile drawer
 * com Esc/backdrop close. Sem dep externa de design-system — blueprint
 * autossuficiente.
 */
export function CrmShell({
  sidebar,
  topbar,
  labels,
  children,
}: CrmShellProps) {
  const L = { ...DEFAULT_LABELS, ...labels };
  const [mobileOpen, setMobileOpen] = React.useState(false);

  React.useEffect(() => {
    if (!mobileOpen) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setMobileOpen(false);
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobileOpen]);

  return (
    <div
      data-slot="crm-shell"
      className="grid min-h-screen grid-cols-1 lg:grid-cols-[var(--sidebar-expanded-width,260px)_1fr] bg-background text-foreground"
      style={
        {
          "--topbar-height": "62px",
          "--sidebar-expanded-width": "260px",
          "--sidebar-collapsed-width": "85px",
        } as React.CSSProperties
      }
    >
      <a
        href="#main"
        data-slot="crm-shell-skiplink"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-[100] focus:rounded-md focus:bg-primary focus:px-3 focus:py-2 focus:text-sm focus:text-primary-foreground"
      >
        {L.skipLink}
      </a>

      <nav
        data-slot="crm-shell-sidebar"
        aria-label="Primária"
        className="hidden border-r border-border bg-card text-foreground lg:block"
      >
        <SidebarInner slots={sidebar} />
      </nav>

      <div
        data-slot="crm-shell-content"
        className="flex min-h-screen flex-col"
      >
        <header
          data-slot="crm-shell-header"
          role="banner"
          className="sticky top-0 z-30 flex h-[var(--topbar-height)] items-center gap-3 border-b border-border bg-card px-4"
        >
          <button
            type="button"
            onClick={() => setMobileOpen(true)}
            aria-label={L.openMobileMenu}
            className="lg:hidden inline-flex h-9 w-9 items-center justify-center rounded-md border border-border bg-card text-foreground hover:bg-muted/50"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <line x1="4" y1="6" x2="20" y2="6" />
              <line x1="4" y1="12" x2="20" y2="12" />
              <line x1="4" y1="18" x2="20" y2="18" />
            </svg>
          </button>
          {topbar?.breadcrumbs && (
            <div className="flex-1 min-w-0">{topbar.breadcrumbs}</div>
          )}
          {topbar?.notifications && (
            <div className="ml-auto">{topbar.notifications}</div>
          )}
          {topbar?.actions && <div>{topbar.actions}</div>}
        </header>

        <main
          id="main"
          data-slot="crm-shell-main"
          tabIndex={-1}
          className="flex-1 p-4 md:p-6 outline-none"
        >
          {children}
        </main>
      </div>

      {mobileOpen && (
        <div
          data-slot="crm-shell-mobile-drawer"
          className="fixed inset-0 z-50 lg:hidden"
          role="dialog"
          aria-modal="true"
        >
          <button
            type="button"
            aria-label={L.closeMobileMenu}
            className="absolute inset-0 bg-background/60 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside
            className="absolute inset-y-0 left-0 w-[280px] max-w-[85vw] bg-card border-r border-border shadow-lg"
            aria-label="Menu móvel"
          >
            <SidebarInner slots={sidebar} />
          </aside>
        </div>
      )}
    </div>
  );
}
