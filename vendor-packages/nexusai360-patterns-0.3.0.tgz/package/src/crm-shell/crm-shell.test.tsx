import { describe, it, expect } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { CrmShell } from "./crm-shell";

const baseSlots = {
  logo: <div data-testid="logo">logo</div>,
  nav: <nav data-testid="nav">nav</nav>,
  userMenu: <div data-testid="user">user</div>,
};

describe("CrmShell — estrutura base", () => {
  it("renderiza logo, nav, userMenu", () => {
    render(<CrmShell sidebar={baseSlots}>content</CrmShell>);
    expect(screen.getByTestId("logo")).toBeInTheDocument();
    expect(screen.getByTestId("nav")).toBeInTheDocument();
    expect(screen.getByTestId("user")).toBeInTheDocument();
  });

  it("renderiza slots opcionais (search/themeCycler/footer)", () => {
    render(
      <CrmShell
        sidebar={{
          ...baseSlots,
          search: <div data-testid="search">s</div>,
          themeCycler: <div data-testid="cycler">c</div>,
          footer: <div data-testid="footer">f</div>,
        }}
      >
        x
      </CrmShell>
    );
    expect(screen.getByTestId("search")).toBeInTheDocument();
    expect(screen.getByTestId("cycler")).toBeInTheDocument();
    expect(screen.getByTestId("footer")).toBeInTheDocument();
  });

  it("renderiza topbar quando fornecido", () => {
    render(
      <CrmShell
        sidebar={baseSlots}
        topbar={{
          breadcrumbs: <div data-testid="bc">b</div>,
          notifications: <div data-testid="notif">n</div>,
          actions: <div data-testid="act">a</div>,
        }}
      >
        x
      </CrmShell>
    );
    expect(screen.getByTestId("bc")).toBeInTheDocument();
    expect(screen.getByTestId("notif")).toBeInTheDocument();
    expect(screen.getByTestId("act")).toBeInTheDocument();
  });

  it("preserva skip link do AppShell (#main)", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    const skip = screen.getByText("Pular para o conteúdo");
    expect(skip.getAttribute("href")).toBe("#main");
  });

  it("main id=main presente", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    expect(document.querySelector('main[id="main"]')).toBeInTheDocument();
  });

  it("role=banner único", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    expect(document.querySelectorAll('[role="banner"]').length).toBe(1);
  });

  it("nav com aria-label='Primária'", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    expect(
      document.querySelector('nav[aria-label="Primária"]')
    ).toBeInTheDocument();
  });

  it("children rendered no main", () => {
    render(
      <CrmShell sidebar={baseSlots}>
        <div data-testid="child">content</div>
      </CrmShell>
    );
    expect(screen.getByTestId("child")).toHaveTextContent("content");
  });

  it("aplica CSS var --topbar-height default 62px", () => {
    const { container } = render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    const root = container.firstChild as HTMLElement;
    expect(root.style.getPropertyValue("--topbar-height")).toBe("62px");
  });
});

describe("CrmShell — mobile drawer", () => {
  it("expõe botão 'Abrir menu' em mobile", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    expect(
      screen.getByRole("button", { name: /abrir menu/i })
    ).toBeInTheDocument();
  });

  it("abrir drawer renderiza slots duplicados", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    fireEvent.click(screen.getByRole("button", { name: /abrir menu/i }));
    expect(screen.getAllByTestId("logo")).toHaveLength(2);
  });

  it("Esc fecha drawer", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    fireEvent.click(screen.getByRole("button", { name: /abrir menu/i }));
    expect(screen.getAllByTestId("logo")).toHaveLength(2);
    fireEvent.keyDown(document, { key: "Escape" });
    expect(screen.getAllByTestId("logo")).toHaveLength(1);
  });

  it("clicar backdrop fecha drawer", () => {
    render(<CrmShell sidebar={baseSlots}>x</CrmShell>);
    fireEvent.click(screen.getByRole("button", { name: /abrir menu/i }));
    const close = screen.getByRole("button", { name: /fechar menu/i });
    fireEvent.click(close);
    expect(screen.getAllByTestId("logo")).toHaveLength(1);
  });

  it("aceita labels customizados", () => {
    render(
      <CrmShell
        sidebar={baseSlots}
        labels={{ openMobileMenu: "Menu principal" }}
      >
        x
      </CrmShell>
    );
    expect(
      screen.getByRole("button", { name: "Menu principal" })
    ).toBeInTheDocument();
  });
});
