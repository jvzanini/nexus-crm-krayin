import { PageShell } from "./index";

export default { title: "Patterns/PageShell" };

export const Default = () => (
  <div style={{ height: 400 }}>
    <PageShell
      sidebar={<div className="p-4 text-zinc-400 text-sm">Sidebar</div>}
      header={<div className="p-4 border-b border-zinc-800 text-zinc-100 text-sm">Header</div>}
    >
      <div className="p-6 text-zinc-300 text-sm">Main content area</div>
    </PageShell>
  </div>
);

export const WithoutSidebar = () => (
  <div style={{ height: 400 }}>
    <PageShell sidebarCollapsed>
      <div className="p-6 text-zinc-300 text-sm">Full-width content</div>
    </PageShell>
  </div>
);
