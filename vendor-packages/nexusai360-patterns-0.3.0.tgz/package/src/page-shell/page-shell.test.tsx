import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { PageShell } from "./index";

describe("PageShell", () => {
  it("renders main content", () => {
    render(<PageShell>Main Content</PageShell>);
    expect(screen.getByText("Main Content")).toBeInTheDocument();
  });

  it("renders sidebar when provided", () => {
    render(<PageShell sidebar={<div>Sidebar</div>}>Content</PageShell>);
    expect(screen.getByText("Sidebar")).toBeInTheDocument();
    expect(screen.getByTestId("page-shell-sidebar")).toBeInTheDocument();
  });

  it("renders header when provided", () => {
    render(<PageShell header={<div>Header</div>}>Content</PageShell>);
    expect(screen.getByText("Header")).toBeInTheDocument();
    expect(screen.getByTestId("page-shell-header")).toBeInTheDocument();
  });

  it("hides sidebar when collapsed", () => {
    render(
      <PageShell sidebar={<div>Sidebar</div>} sidebarCollapsed>
        Content
      </PageShell>
    );
    expect(screen.queryByTestId("page-shell-sidebar")).toBeNull();
  });

  it("applies custom sidebar width", () => {
    render(
      <PageShell sidebar={<div>Sidebar</div>} sidebarWidth={320}>
        Content
      </PageShell>
    );
    const sidebar = screen.getByTestId("page-shell-sidebar");
    expect(sidebar).toHaveStyle({ width: "320px" });
  });

  it("uses CSS grid for layout", () => {
    const { container } = render(
      <PageShell sidebar={<div>Sidebar</div>}>Content</PageShell>
    );
    const grid = container.firstElementChild;
    expect(grid).toHaveStyle({ gridTemplateColumns: "280px 1fr" });
  });

  it("renders without sidebar (single column)", () => {
    const { container } = render(<PageShell>Content</PageShell>);
    const grid = container.firstElementChild;
    expect(grid).toHaveStyle({ gridTemplateColumns: "1fr" });
  });

  it("forwards className", () => {
    const { container } = render(
      <PageShell className="custom">Content</PageShell>
    );
    expect(container.firstElementChild).toHaveClass("custom");
  });
});
