import * as React from "react";

export interface PageShellProps extends React.HTMLAttributes<HTMLDivElement> {
  sidebar?: React.ReactNode;
  header?: React.ReactNode;
  topbar?: React.ReactNode;
  children: React.ReactNode;
  sidebarWidth?: number;
  collapsedSidebarWidth?: number;
  sidebarCollapsed?: boolean;
}

const PageShell = React.forwardRef<HTMLDivElement, PageShellProps>(
  (
    {
      className,
      sidebar,
      header,
      topbar,
      children,
      sidebarWidth = 280,
      collapsedSidebarWidth = 85,
      sidebarCollapsed = false,
      style,
      ...props
    },
    ref
  ) => {
    const showSidebar = sidebar && !sidebarCollapsed;
    const rowsParts: string[] = [];
    if (header) rowsParts.push("auto");
    if (topbar) rowsParts.push("auto");
    rowsParts.push("1fr");

    return (
      <div
        ref={ref}
        data-collapsed-width={collapsedSidebarWidth}
        className={[
          "grid min-h-screen w-full bg-background text-foreground",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        style={{
          gridTemplateColumns: showSidebar ? `${sidebarWidth}px 1fr` : "1fr",
          gridTemplateRows: rowsParts.join(" "),
          ...style,
        }}
        {...props}
      >
        {showSidebar && (
          <aside
            className="row-span-full border-r border-border bg-card"
            style={{ width: sidebarWidth }}
            data-testid="page-shell-sidebar"
          >
            {sidebar}
          </aside>
        )}

        {header && (
          <header
            className="border-b border-border bg-card px-6 py-4"
            data-testid="page-shell-header"
          >
            {header}
          </header>
        )}

        {topbar && (
          <div
            className="border-b border-border bg-card px-6 py-3"
            data-testid="page-shell-topbar"
          >
            {topbar}
          </div>
        )}

        <main
          className="overflow-auto bg-background p-6"
          data-testid="page-shell-main"
        >
          {children}
        </main>
      </div>
    );
  }
);

PageShell.displayName = "PageShell";

export { PageShell };
