import * as React from "react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuSeparator,
  Avatar,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface UserInfo {
  /** Full name */
  name: string;
  /** Email */
  email: string;
  /** Avatar image URL */
  avatar?: string;
  /** Role label */
  role?: string;
}

export interface ProfileMenuItem {
  /** Display label */
  label: string;
  /** Icon */
  icon?: React.ReactNode;
  /** Click handler */
  onClick: () => void;
  /** Whether this item is destructive */
  destructive?: boolean;
}

export interface ProfileMenuProps {
  /** User information */
  user: UserInfo;
  /** Menu items */
  menuItems?: ProfileMenuItem[];
  /** Logout callback */
  onLogout?: () => void;
  /** Additional className for trigger */
  triggerClassName?: string;
}

/* ------------------------------------------------------------------ */
/*  Logout icon                                                        */
/* ------------------------------------------------------------------ */
const LogoutIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M6 14H3a1 1 0 01-1-1V3a1 1 0 011-1h3M11 11l3-3-3-3M14 8H6"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const ProfileMenu: React.FC<ProfileMenuProps> = ({
  user,
  menuItems = [],
  onLogout,
  triggerClassName,
}) => {
  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        className={[
          "flex items-center gap-2 rounded-lg p-1.5 transition-colors hover:bg-zinc-800 outline-none",
          "focus-visible:ring-2 focus-visible:ring-violet-500/50",
          triggerClassName,
        ]
          .filter(Boolean)
          .join(" ")}
        aria-label="Open profile menu"
      >
        <Avatar
          src={user.avatar}
          alt={user.name}
          fallback={initials}
          size="sm"
        />
        <div className="hidden sm:flex sm:flex-col sm:items-start">
          <span className="text-sm font-medium text-zinc-100">
            {user.name}
          </span>
          {user.role && (
            <span className="text-xs text-zinc-500">{user.role}</span>
          )}
        </div>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <div className="flex flex-col gap-0.5">
            <span className="text-sm font-medium text-zinc-100">
              {user.name}
            </span>
            <span className="text-xs text-zinc-500">{user.email}</span>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />

        {menuItems.map((item) => (
          <DropdownMenuItem
            key={item.label}
            onSelect={item.onClick}
            className={
              item.destructive ? "text-red-400 focus:text-red-300" : undefined
            }
          >
            {item.icon && (
              <span className="mr-2 text-zinc-400">{item.icon}</span>
            )}
            {item.label}
          </DropdownMenuItem>
        ))}

        {onLogout && (
          <>
            {menuItems.length > 0 && <DropdownMenuSeparator />}
            <DropdownMenuItem
              onSelect={onLogout}
              className="text-red-400 focus:text-red-300"
            >
              <span className="mr-2">
                <LogoutIcon />
              </span>
              Sign out
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

ProfileMenu.displayName = "ProfileMenu";

export { ProfileMenu };
