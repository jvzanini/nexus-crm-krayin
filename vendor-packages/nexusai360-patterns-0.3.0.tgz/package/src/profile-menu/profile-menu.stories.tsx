import { ProfileMenu } from "./index";

export default { title: "Patterns/ProfileMenu" };

const user = {
  name: "Joao Zanini",
  email: "joao@nexusai.com",
  avatar: "https://i.pravatar.cc/150?u=joao",
  role: "Admin",
};

const menuItems = [
  { label: "Profile", onClick: () => console.log("Profile") },
  { label: "Settings", onClick: () => console.log("Settings") },
  { label: "Billing", onClick: () => console.log("Billing") },
];

export const Default = () => (
  <ProfileMenu user={user} menuItems={menuItems} onLogout={() => console.log("Logout")} />
);

export const WithoutAvatar = () => (
  <ProfileMenu
    user={{ name: "Jane Doe", email: "jane@example.com", role: "Editor" }}
    onLogout={() => {}}
  />
);
