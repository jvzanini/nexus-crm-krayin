import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { ProfileMenu, type UserInfo, type ProfileMenuItem } from "./index";

const user: UserInfo = {
  name: "John Doe",
  email: "john@example.com",
  role: "Admin",
};

const menuItems: ProfileMenuItem[] = [
  { label: "Profile", onClick: vi.fn() },
  { label: "Settings", onClick: vi.fn() },
];

describe("ProfileMenu", () => {
  it("renders trigger with user name", () => {
    render(<ProfileMenu user={user} />);
    expect(screen.getByText("John Doe")).toBeInTheDocument();
  });

  it("renders trigger with role", () => {
    render(<ProfileMenu user={user} />);
    expect(screen.getByText("Admin")).toBeInTheDocument();
  });

  it("renders avatar with initials", () => {
    render(<ProfileMenu user={user} />);
    expect(screen.getByText("JD")).toBeInTheDocument();
  });

  it("opens menu on click", () => {
    render(<ProfileMenu user={user} menuItems={menuItems} />);
    fireEvent.click(screen.getByLabelText("Open profile menu"));
    expect(screen.getByText("john@example.com")).toBeInTheDocument();
  });

  it("renders menu items", () => {
    render(<ProfileMenu user={user} menuItems={menuItems} />);
    fireEvent.click(screen.getByLabelText("Open profile menu"));
    expect(screen.getByText("Profile")).toBeInTheDocument();
    expect(screen.getByText("Settings")).toBeInTheDocument();
  });

  it("renders sign out button", () => {
    const onLogout = vi.fn();
    render(<ProfileMenu user={user} onLogout={onLogout} />);
    fireEvent.click(screen.getByLabelText("Open profile menu"));
    expect(screen.getByText("Sign out")).toBeInTheDocument();
  });

  it("renders without role", () => {
    const noRole = { ...user, role: undefined };
    render(<ProfileMenu user={noRole} />);
    expect(screen.queryByText("Admin")).toBeNull();
  });
});
