import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { CrmDetailShell } from "./crm-detail-shell";

describe("CrmDetailShell", () => {
  it("renderiza slots left e right", () => {
    render(
      <CrmDetailShell
        left={<div data-testid="l">L</div>}
        right={<div data-testid="r">R</div>}
      />
    );
    expect(screen.getByTestId("l")).toBeInTheDocument();
    expect(screen.getByTestId("r")).toBeInTheDocument();
  });

  it("left usa <aside> com aria-label", () => {
    render(<CrmDetailShell left={<span>L</span>} right={<span>R</span>} />);
    const aside = document.querySelector(
      'aside[aria-label="Informações do registro"]'
    );
    expect(aside).toBeInTheDocument();
  });

  it("left sticky com top calc --topbar-height", () => {
    const { container } = render(
      <CrmDetailShell left={<span />} right={<span />} />
    );
    const aside = container.querySelector("aside");
    expect(aside?.className).toContain("lg:sticky");
    expect(aside?.getAttribute("style") || "").toMatch(/var\(--topbar-height/);
  });

  it("leftWidth default 394px", () => {
    const { container } = render(
      <CrmDetailShell left={<span />} right={<span />} />
    );
    const root = container.firstChild as HTMLElement;
    expect(root.style.getPropertyValue("--left-width")).toBe("394px");
  });

  it("leftWidth custom aplicado", () => {
    const { container } = render(
      <CrmDetailShell left={<span />} right={<span />} leftWidth={320} />
    );
    const root = container.firstChild as HTMLElement;
    expect(root.style.getPropertyValue("--left-width")).toBe("320px");
  });

  it("mobile reorder — flex-col em <lg", () => {
    const { container } = render(
      <CrmDetailShell left={<span />} right={<span />} />
    );
    const root = container.firstChild as HTMLElement;
    expect(root.className).toContain("flex-col");
    expect(root.className).toContain("lg:grid");
  });

  it("left panel não hardcoda bg-white", () => {
    const { container } = render(
      <CrmDetailShell left={<span />} right={<span />} />
    );
    const aside = container.querySelector(
      'aside[data-slot="crm-detail-left"]'
    );
    expect(aside?.className).toMatch(/bg-card/);
    expect(aside?.className).not.toMatch(/\bbg-white\b/);
  });
});
