import * as React from "react";

export interface CrmDetailShellProps {
  left: React.ReactNode;
  right: React.ReactNode;
  leftWidth?: number;
}

export function CrmDetailShell({
  left,
  right,
  leftWidth = 394,
}: CrmDetailShellProps) {
  return (
    <div
      data-slot="crm-detail-shell"
      className="flex flex-col gap-4 lg:grid lg:grid-cols-[var(--left-width,394px)_1fr]"
      style={
        {
          "--left-width": `${leftWidth}px`,
        } as React.CSSProperties
      }
    >
      <aside
        data-slot="crm-detail-left"
        aria-label="Informações do registro"
        className="self-start rounded-lg border border-border bg-card lg:sticky"
        style={{ top: "calc(var(--topbar-height, 62px) + 0.75rem)" }}
      >
        {left}
      </aside>
      <div data-slot="crm-detail-right" className="flex flex-col gap-4">
        {right}
      </div>
    </div>
  );
}
