export { CrmDetailShell } from "./crm-detail-shell";
export type { CrmDetailShellProps } from "./crm-detail-shell";
