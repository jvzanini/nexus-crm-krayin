import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { CrmDashboardGrid } from "./crm-dashboard-grid";

describe("CrmDashboardGrid", () => {
  it("renderiza children como main", () => {
    render(
      <CrmDashboardGrid>
        <div data-testid="m">main</div>
      </CrmDashboardGrid>
    );
    expect(screen.getByTestId("m")).toBeInTheDocument();
  });

  it("renderiza side quando fornecido", () => {
    render(
      <CrmDashboardGrid side={<div data-testid="s">side</div>}>
        main
      </CrmDashboardGrid>
    );
    expect(screen.getByTestId("s")).toBeInTheDocument();
  });

  it("side undefined → grid single-column", () => {
    const { container } = render(<CrmDashboardGrid>main</CrmDashboardGrid>);
    expect(
      container.querySelector('[data-slot="crm-dashboard-side"]')
    ).toBeNull();
    const root = container.firstChild as HTMLElement;
    expect(root.className).toContain("xl:grid-cols-1");
  });

  it("side fornecido → grid 1fr / 378px em xl+", () => {
    const { container } = render(
      <CrmDashboardGrid side={<span />}>main</CrmDashboardGrid>
    );
    const root = container.firstChild as HTMLElement;
    expect(root.className).toContain(
      "xl:grid-cols-[1fr_var(--side-width,378px)]"
    );
  });

  it("sideWidth custom aplicado como CSS var", () => {
    const { container } = render(
      <CrmDashboardGrid side={<span />} sideWidth={320}>
        main
      </CrmDashboardGrid>
    );
    const root = container.firstChild as HTMLElement;
    expect(root.style.getPropertyValue("--side-width")).toBe("320px");
  });

  it("mobile empilha (flex-col)", () => {
    const { container } = render(
      <CrmDashboardGrid side={<span />}>main</CrmDashboardGrid>
    );
    const root = container.firstChild as HTMLElement;
    expect(root.className).toContain("flex-col");
    expect(root.className).toContain("xl:grid");
  });

  it("não hardcoda cores brancas", () => {
    const { container } = render(<CrmDashboardGrid>x</CrmDashboardGrid>);
    expect(container.innerHTML).not.toMatch(/\bbg-white\b/);
  });
});
