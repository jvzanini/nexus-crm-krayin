import * as React from "react";

export interface CrmDashboardGridProps {
  children: React.ReactNode;
  side?: React.ReactNode;
  sideWidth?: number;
}

export function CrmDashboardGrid({
  children,
  side,
  sideWidth = 378,
}: CrmDashboardGridProps) {
  const gridCols = side
    ? "xl:grid-cols-[1fr_var(--side-width,378px)]"
    : "xl:grid-cols-1";

  return (
    <div
      data-slot="crm-dashboard-grid"
      className={`flex flex-col gap-4 xl:grid ${gridCols}`}
      style={
        side
          ? ({ "--side-width": `${sideWidth}px` } as React.CSSProperties)
          : undefined
      }
    >
      <div
        data-slot="crm-dashboard-main"
        className="flex flex-1 flex-col gap-4"
      >
        {children}
      </div>
      {side && (
        <aside
          data-slot="crm-dashboard-side"
          aria-label="Painel lateral"
          className="flex flex-col gap-4"
        >
          {side}
        </aside>
      )}
    </div>
  );
}
