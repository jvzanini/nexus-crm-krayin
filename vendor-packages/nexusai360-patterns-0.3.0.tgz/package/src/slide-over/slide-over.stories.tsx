import { SlideOver } from "./index";

export default { title: "Patterns/SlideOver" };

export const Default = () => (
  <SlideOver
    title="Contact Details"
    description="View and edit contact information."
    trigger={<button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Panel</button>}
    footer={<button className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm">Save</button>}
  >
    <div className="text-sm text-zinc-300 space-y-2">
      <p>Name: Alice Johnson</p>
      <p>Email: alice@example.com</p>
      <p>Phone: +1 555-0123</p>
    </div>
  </SlideOver>
);

export const LeftSide = () => (
  <SlideOver
    title="Navigation"
    side="left"
    trigger={<button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Left</button>}
  >
    <div className="text-sm text-zinc-300">Left panel content</div>
  </SlideOver>
);

export const Large = () => (
  <SlideOver
    title="Large Panel"
    size="lg"
    trigger={<button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Open Large</button>}
  >
    <div className="text-sm text-zinc-300">Large panel content with more space.</div>
  </SlideOver>
);
