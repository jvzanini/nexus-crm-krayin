import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { SlideOver } from "./index";

describe("SlideOver", () => {
  const defaultProps = {
    title: "User Details",
    trigger: <button>Open</button>,
    children: <div>Panel content</div>,
  };

  it("renders trigger", () => {
    render(<SlideOver {...defaultProps} />);
    expect(screen.getByRole("button", { name: "Open" })).toBeInTheDocument();
  });

  it("opens panel on trigger click", () => {
    render(<SlideOver {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByText("User Details")).toBeInTheDocument();
    expect(screen.getByText("Panel content")).toBeInTheDocument();
  });

  it("renders description when provided", () => {
    render(
      <SlideOver {...defaultProps} description="View and edit user info" />
    );
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByText("View and edit user info")).toBeInTheDocument();
  });

  it("renders close button", () => {
    render(<SlideOver {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(
      screen.getByRole("button", { name: "Close panel" })
    ).toBeInTheDocument();
  });

  it("renders footer when provided", () => {
    render(
      <SlideOver {...defaultProps} footer={<button>Save</button>} />
    );
    fireEvent.click(screen.getByRole("button", { name: "Open" }));
    expect(screen.getByRole("button", { name: "Save" })).toBeInTheDocument();
  });

  it("renders with controlled open state", () => {
    render(<SlideOver {...defaultProps} open />);
    expect(screen.getByText("User Details")).toBeInTheDocument();
  });
});
