import * as React from "react";
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
  Button,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export type SlideOverSide = "right" | "left";
export type SlideOverSize = "sm" | "md" | "lg";

const sizeClasses: Record<SlideOverSize, string> = {
  sm: "max-w-sm",
  md: "max-w-lg",
  lg: "max-w-2xl",
};

export interface SlideOverProps {
  /** Panel title */
  title: string;
  /** Panel description */
  description?: string;
  /** Trigger element */
  trigger: React.ReactNode;
  /** Content */
  children: React.ReactNode;
  /** Which side the panel opens from */
  side?: SlideOverSide;
  /** Width preset */
  size?: SlideOverSize;
  /** Controlled open */
  open?: boolean;
  /** Open change callback */
  onOpenChange?: (open: boolean) => void;
  /** Footer content */
  footer?: React.ReactNode;
  /** Additional className */
  className?: string;
}

/* ------------------------------------------------------------------ */
/*  Close Icon                                                         */
/* ------------------------------------------------------------------ */
const CloseIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M4 4l8 8M12 4l-8 8"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const SlideOver: React.FC<SlideOverProps> = ({
  title,
  description,
  trigger,
  children,
  side = "right",
  size = "md",
  open,
  onOpenChange,
  footer,
  className,
}) => {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent
        side={side}
        className={[sizeClasses[size], "flex flex-col", className]
          .filter(Boolean)
          .join(" ")}
      >
        <SheetHeader>
          <div className="flex items-start justify-between">
            <div className="flex flex-col gap-1">
              <SheetTitle>{title}</SheetTitle>
              {description && (
                <SheetDescription>{description}</SheetDescription>
              )}
            </div>
            <SheetClose asChild>
              <Button
                variant="ghost"
                size="sm"
                className="size-8 p-0"
                aria-label="Close panel"
              >
                <CloseIcon />
              </Button>
            </SheetClose>
          </div>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto p-6">{children}</div>

        {footer && (
          <div className="border-t border-zinc-800 p-6">{footer}</div>
        )}
      </SheetContent>
    </Sheet>
  );
};

SlideOver.displayName = "SlideOver";

export { SlideOver };
