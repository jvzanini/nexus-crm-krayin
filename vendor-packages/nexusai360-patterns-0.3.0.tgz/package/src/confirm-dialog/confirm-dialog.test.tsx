import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { ConfirmDialog } from "./index";

describe("ConfirmDialog", () => {
  const defaultProps = {
    title: "Delete item?",
    description: "This action cannot be undone.",
    trigger: <button>Delete</button>,
    onConfirm: vi.fn(),
  };

  it("renders trigger", () => {
    render(<ConfirmDialog {...defaultProps} />);
    expect(screen.getByRole("button", { name: "Delete" })).toBeInTheDocument();
  });

  it("opens dialog on trigger click", () => {
    render(<ConfirmDialog {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(screen.getByText("Delete item?")).toBeInTheDocument();
    expect(
      screen.getByText("This action cannot be undone.")
    ).toBeInTheDocument();
  });

  it("renders Confirm and Cancel buttons", () => {
    render(<ConfirmDialog {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(screen.getByRole("button", { name: "Confirm" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Cancel" })).toBeInTheDocument();
  });

  it("renders custom button text", () => {
    render(
      <ConfirmDialog
        {...defaultProps}
        confirmText="Yes, delete"
        cancelText="No, keep it"
      />
    );
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(
      screen.getByRole("button", { name: "Yes, delete" })
    ).toBeInTheDocument();
    expect(
      screen.getByRole("button", { name: "No, keep it" })
    ).toBeInTheDocument();
  });

  it("calls onConfirm on confirm click", () => {
    render(<ConfirmDialog {...defaultProps} />);
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    fireEvent.click(screen.getByRole("button", { name: "Confirm" }));
    expect(defaultProps.onConfirm).toHaveBeenCalledOnce();
  });

  it("applies danger variant (default red styling on action)", () => {
    render(<ConfirmDialog {...defaultProps} variant="danger" />);
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    const confirmBtn = screen.getByRole("button", { name: "Confirm" });
    // Danger variant uses default AlertDialogAction styling which is red
    expect(confirmBtn).toBeInTheDocument();
  });

  it("applies default variant with violet styling", () => {
    render(<ConfirmDialog {...defaultProps} variant="default" />);
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    const confirmBtn = screen.getByRole("button", { name: "Confirm" });
    expect(confirmBtn.className).toContain("bg-violet-600");
  });

  it("shows Loading text when loading", () => {
    render(<ConfirmDialog {...defaultProps} loading open />);
    expect(screen.getByText("Loading...")).toBeInTheDocument();
  });
});
