import { ConfirmDialog } from "./index";

export default { title: "Patterns/ConfirmDialog" };

export const Default = () => (
  <ConfirmDialog
    title="Confirm Action"
    description="Are you sure you want to proceed?"
    trigger={<button className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm">Confirm</button>}
    onConfirm={() => {}}
  />
);

export const Danger = () => (
  <ConfirmDialog
    title="Delete Item"
    description="This action cannot be undone. The item will be permanently deleted."
    variant="danger"
    confirmText="Delete"
    trigger={<button className="px-3 py-2 rounded-lg bg-red-600 text-white text-sm">Delete</button>}
    onConfirm={() => {}}
  />
);
