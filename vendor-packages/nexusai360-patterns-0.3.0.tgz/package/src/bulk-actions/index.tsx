import * as React from "react";
import { Button } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface BulkAction {
  /** Button label */
  label: string;
  /** Optional icon */
  icon?: React.ReactNode;
  /** Click handler */
  onClick: () => void;
  /** Button variant */
  variant?: "primary" | "secondary" | "ghost" | "danger";
}

export interface BulkActionsProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Number of selected items */
  selectedCount: number;
  /** Available actions */
  actions: BulkAction[];
  /** Callback to clear selection */
  onClear?: () => void;
  /** Whether the bar is visible (overrides automatic show/hide) */
  visible?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Close Icon                                                         */
/* ------------------------------------------------------------------ */
const CloseIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M4 4l8 8M12 4l-8 8"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const BulkActions = React.forwardRef<HTMLDivElement, BulkActionsProps>(
  (
    {
      className,
      selectedCount,
      actions,
      onClear,
      visible,
      ...props
    },
    ref
  ) => {
    const isVisible = visible ?? selectedCount > 0;

    if (!isVisible) return null;

    return (
      <div
        ref={ref}
        role="toolbar"
        aria-label="Bulk actions"
        className={[
          "fixed bottom-6 left-1/2 z-50 -translate-x-1/2",
          "flex items-center gap-3 rounded-xl border border-zinc-700 bg-zinc-900 px-4 py-3 shadow-2xl",
          "animate-in fade-in-0 slide-in-from-bottom-4",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        <span className="text-sm font-medium text-zinc-100">
          {selectedCount} selected
        </span>

        <div className="mx-2 h-5 w-px bg-zinc-700" aria-hidden="true" />

        {actions.map((action) => (
          <Button
            key={action.label}
            variant={action.variant ?? "secondary"}
            size="sm"
            onClick={action.onClick}
            leftIcon={action.icon}
          >
            {action.label}
          </Button>
        ))}

        {onClear && (
          <>
            <div className="mx-1 h-5 w-px bg-zinc-700" aria-hidden="true" />
            <Button
              variant="ghost"
              size="sm"
              onClick={onClear}
              aria-label="Clear selection"
              leftIcon={<CloseIcon />}
            >
              Clear
            </Button>
          </>
        )}
      </div>
    );
  }
);

BulkActions.displayName = "BulkActions";

export { BulkActions };
