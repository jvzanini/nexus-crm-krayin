import { BulkActions } from "./index";

export default { title: "Patterns/BulkActions" };

export const Default = () => (
  <BulkActions
    selectedCount={5}
    actions={[
      { label: "Delete", onClick: () => {}, variant: "danger" },
      { label: "Export", onClick: () => {}, variant: "secondary" },
      { label: "Archive", onClick: () => {}, variant: "ghost" },
    ]}
  />
);

export const SingleSelection = () => (
  <BulkActions
    selectedCount={1}
    actions={[
      { label: "Edit", onClick: () => {}, variant: "primary" },
      { label: "Delete", onClick: () => {}, variant: "danger" },
    ]}
  />
);
