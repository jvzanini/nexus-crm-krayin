import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { BulkActions, type BulkAction } from "./index";

const actions: BulkAction[] = [
  { label: "Delete", onClick: vi.fn(), variant: "danger" },
  { label: "Archive", onClick: vi.fn() },
];

describe("BulkActions", () => {
  it("renders when selectedCount > 0", () => {
    render(<BulkActions selectedCount={5} actions={actions} />);
    expect(screen.getByText("5 selected")).toBeInTheDocument();
  });

  it("does not render when selectedCount is 0", () => {
    const { container } = render(
      <BulkActions selectedCount={0} actions={actions} />
    );
    expect(container.innerHTML).toBe("");
  });

  it("renders action buttons", () => {
    render(<BulkActions selectedCount={2} actions={actions} />);
    expect(screen.getByRole("button", { name: "Delete" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Archive" })).toBeInTheDocument();
  });

  it("calls action onClick", () => {
    render(<BulkActions selectedCount={2} actions={actions} />);
    fireEvent.click(screen.getByRole("button", { name: "Delete" }));
    expect(actions[0].onClick).toHaveBeenCalledOnce();
  });

  it("renders clear button when onClear provided", () => {
    const onClear = vi.fn();
    render(
      <BulkActions selectedCount={2} actions={actions} onClear={onClear} />
    );
    expect(screen.getByLabelText("Clear selection")).toBeInTheDocument();
  });

  it("calls onClear when clear button clicked", () => {
    const onClear = vi.fn();
    render(
      <BulkActions selectedCount={2} actions={actions} onClear={onClear} />
    );
    fireEvent.click(screen.getByLabelText("Clear selection"));
    expect(onClear).toHaveBeenCalledOnce();
  });

  it("has role=toolbar", () => {
    render(<BulkActions selectedCount={1} actions={actions} />);
    expect(screen.getByRole("toolbar")).toBeInTheDocument();
  });

  it("respects visible prop override", () => {
    render(
      <BulkActions selectedCount={0} actions={actions} visible={true} />
    );
    expect(screen.getByText("0 selected")).toBeInTheDocument();
  });

  it("hides when visible=false even with selectedCount > 0", () => {
    const { container } = render(
      <BulkActions selectedCount={5} actions={actions} visible={false} />
    );
    expect(container.innerHTML).toBe("");
  });
});
