import { PageHeader } from "./index";

export default { title: "Patterns/PageHeader" };

export const Default = () => (
  <PageHeader title="Contacts" description="Manage your contacts and leads." />
);

export const WithBreadcrumbs = () => (
  <PageHeader
    title="Edit Contact"
    breadcrumbs={[
      { label: "Home", href: "#" },
      { label: "Contacts", href: "#" },
      { label: "Edit Contact" },
    ]}
  />
);

export const WithActions = () => (
  <PageHeader
    title="Companies"
    description="All registered companies."
    actions={
      <button className="px-3 py-2 rounded-lg bg-violet-600 text-white text-sm">Add Company</button>
    }
  />
);
