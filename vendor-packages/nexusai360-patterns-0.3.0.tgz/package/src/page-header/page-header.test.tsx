import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { PageHeader } from "./index";

describe("PageHeader", () => {
  it("renders the title", () => {
    render(<PageHeader title="Users" />);
    expect(screen.getByRole("heading", { name: "Users" })).toBeInTheDocument();
  });

  it("renders description when provided", () => {
    render(<PageHeader title="Users" description="Manage all users" />);
    expect(screen.getByText("Manage all users")).toBeInTheDocument();
  });

  it("does not render description when not provided", () => {
    const { container } = render(<PageHeader title="Users" />);
    expect(container.querySelector("p")).toBeNull();
  });

  it("renders breadcrumbs", () => {
    render(
      <PageHeader
        title="Edit User"
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Users", href: "/users" },
          { label: "Edit" },
        ]}
      />
    );
    expect(screen.getByText("Home")).toBeInTheDocument();
    // "Users" appears in breadcrumb and possibly h1
    const usersLinks = screen.getAllByText("Users");
    expect(usersLinks.length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText("Edit")).toBeInTheDocument();
  });

  it("renders actions", () => {
    render(
      <PageHeader
        title="Users"
        actions={<button>Add User</button>}
      />
    );
    expect(screen.getByRole("button", { name: "Add User" })).toBeInTheDocument();
  });

  it("renders breadcrumb links with href", () => {
    render(
      <PageHeader
        title="Detail"
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Detail" }]}
      />
    );
    const link = screen.getByText("Home").closest("a");
    expect(link).toHaveAttribute("href", "/");
  });

  it("renders last breadcrumb as current page", () => {
    render(
      <PageHeader
        title="User Detail Page"
        breadcrumbs={[{ label: "Home", href: "/" }, { label: "Detail" }]}
      />
    );
    const current = screen.getByText("Detail");
    expect(current).toHaveAttribute("aria-current", "page");
  });

  it("forwards ref and className", () => {
    const { container } = render(
      <PageHeader title="T" className="custom-class" />
    );
    expect(container.firstElementChild).toHaveClass("custom-class");
  });
});
