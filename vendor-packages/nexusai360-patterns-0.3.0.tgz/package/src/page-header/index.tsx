import * as React from "react";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
  BreadcrumbPage,
  Button,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface BreadcrumbEntry {
  /** Display label */
  label: string;
  /** Link href — if omitted, renders as current page */
  href?: string;
}

export interface PageHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Page title */
  title: string;
  /** Optional description below title */
  description?: string;
  /** Breadcrumb trail */
  breadcrumbs?: BreadcrumbEntry[];
  /** Action buttons rendered on the right */
  actions?: React.ReactNode;
  /** Show a back button before the title (calls history.back by default) */
  showBack?: boolean;
  /** Custom handler for the back button (override default history.back) */
  onBack?: () => void;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const PageHeader = React.forwardRef<HTMLDivElement, PageHeaderProps>(
  (
    { className, title, description, breadcrumbs, actions, showBack, onBack, ...props },
    ref,
  ) => {
    const handleBack = React.useCallback(() => {
      if (onBack) onBack();
      else if (typeof window !== "undefined") window.history.back();
    }, [onBack]);

    return (
      <div
        ref={ref}
        className={[
          "flex flex-col gap-4",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        {/* Breadcrumbs */}
        {breadcrumbs && breadcrumbs.length > 0 && (
          <Breadcrumb>
            <BreadcrumbList>
              {breadcrumbs.map((crumb, index) => {
                const isLast = index === breadcrumbs.length - 1;
                return (
                  <React.Fragment key={crumb.label}>
                    <BreadcrumbItem>
                      {isLast || !crumb.href ? (
                        <BreadcrumbPage>{crumb.label}</BreadcrumbPage>
                      ) : (
                        <BreadcrumbLink href={crumb.href}>
                          {crumb.label}
                        </BreadcrumbLink>
                      )}
                    </BreadcrumbItem>
                    {!isLast && <BreadcrumbSeparator />}
                  </React.Fragment>
                );
              })}
            </BreadcrumbList>
          </Breadcrumb>
        )}

        {/* Title row */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 min-w-0">
            {showBack && (
              <Button
                variant="ghost"
                size="icon"
                onClick={handleBack}
                aria-label="Voltar"
                className="mt-1 shrink-0"
              >
                <svg
                  width="16"
                  height="16"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  aria-hidden="true"
                >
                  <line x1="19" y1="12" x2="5" y2="12" />
                  <polyline points="12 19 5 12 12 5" />
                </svg>
              </Button>
            )}
            <div className="flex flex-col gap-1 min-w-0">
              <h1 className="text-2xl font-bold tracking-tight text-foreground truncate">
                {title}
              </h1>
              {description && (
                <p className="text-sm text-muted-foreground">{description}</p>
              )}
            </div>
          </div>
          {actions && (
            <div className="flex shrink-0 items-center gap-2">{actions}</div>
          )}
        </div>
      </div>
    );
  },
);

PageHeader.displayName = "PageHeader";

export { PageHeader };
