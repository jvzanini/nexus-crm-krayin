import * as React from "react";
import { Button } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Defaults per status code                                           */
/* ------------------------------------------------------------------ */
type StatusCode = 403 | 404 | 500;

const statusDefaults: Record<
  StatusCode,
  { title: string; description: string; icon: React.ReactNode }
> = {
  404: {
    title: "Page not found",
    description: "The page you are looking for does not exist or has been moved.",
    icon: (
      <svg viewBox="0 0 64 64" fill="none" className="size-16" aria-hidden="true">
        <circle cx="32" cy="32" r="24" stroke="currentColor" strokeWidth="2" />
        <text x="32" y="38" textAnchor="middle" fill="currentColor" fontSize="16" fontWeight="bold">
          404
        </text>
      </svg>
    ),
  },
  500: {
    title: "Server error",
    description: "An unexpected error occurred on our servers. Please try again later.",
    icon: (
      <svg viewBox="0 0 64 64" fill="none" className="size-16" aria-hidden="true">
        <circle cx="32" cy="32" r="24" stroke="currentColor" strokeWidth="2" />
        <path d="M32 20v14M32 40v2" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
      </svg>
    ),
  },
  403: {
    title: "Access forbidden",
    description: "You don't have permission to access this resource.",
    icon: (
      <svg viewBox="0 0 64 64" fill="none" className="size-16" aria-hidden="true">
        <rect x="20" y="28" width="24" height="18" rx="3" stroke="currentColor" strokeWidth="2" />
        <path d="M26 28v-6a6 6 0 0112 0v6" stroke="currentColor" strokeWidth="2" />
        <circle cx="32" cy="37" r="2" fill="currentColor" />
      </svg>
    ),
  },
};

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface ErrorStateProps extends React.HTMLAttributes<HTMLDivElement> {
  /** HTTP-like status code */
  statusCode?: StatusCode;
  /** Override title */
  title?: string;
  /** Override description */
  description?: string;
  /** Action element — "retry" renders a retry Button, "go-home" renders a go home Button */
  action?: "retry" | "go-home" | React.ReactNode;
  /** Callback for retry action */
  onRetry?: () => void;
  /** Href for go-home action (default: "/") */
  homeHref?: string;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const ErrorState = React.forwardRef<HTMLDivElement, ErrorStateProps>(
  (
    {
      className,
      statusCode = 500,
      title,
      description,
      action = "retry",
      onRetry,
      homeHref = "/",
      ...props
    },
    ref
  ) => {
    const defaults = statusDefaults[statusCode] ?? statusDefaults[500];
    const resolvedTitle = title ?? defaults.title;
    const resolvedDescription = description ?? defaults.description;

    let resolvedAction: React.ReactNode = null;
    if (action === "retry") {
      resolvedAction = (
        <Button variant="primary" size="sm" onClick={onRetry}>
          Try again
        </Button>
      );
    } else if (action === "go-home") {
      resolvedAction = (
        <Button variant="secondary" size="sm" asChild>
          <a href={homeHref}>Go home</a>
        </Button>
      );
    } else {
      resolvedAction = action;
    }

    return (
      <div
        ref={ref}
        role="alert"
        className={[
          "flex min-h-[400px] flex-col items-center justify-center gap-6 text-center",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        <div className="text-zinc-500">{defaults.icon}</div>
        <div className="flex flex-col gap-2">
          <h1 className="text-2xl font-bold text-zinc-50">{resolvedTitle}</h1>
          <p className="max-w-md text-sm text-zinc-400">
            {resolvedDescription}
          </p>
        </div>
        {resolvedAction && <div className="mt-2">{resolvedAction}</div>}
      </div>
    );
  }
);

ErrorState.displayName = "ErrorState";

export { ErrorState };
