import { ErrorState } from "./index";

export default { title: "Patterns/ErrorState" };

export const NotFound = () => <ErrorState statusCode={404} />;
export const ServerError = () => <ErrorState statusCode={500} />;
export const Forbidden = () => <ErrorState statusCode={403} />;

export const WithRetry = () => (
  <ErrorState statusCode={500} action="retry" onRetry={() => {}} />
);

export const WithGoHome = () => (
  <ErrorState statusCode={404} action="go-home" homeHref="#" />
);

export const CustomMessage = () => (
  <ErrorState
    title="Something went wrong"
    description="We're working on fixing this issue."
    action="retry"
    onRetry={() => {}}
  />
);
