import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { ErrorState } from "./index";

describe("ErrorState", () => {
  it("renders 500 defaults", () => {
    render(<ErrorState />);
    expect(screen.getByText("Server error")).toBeInTheDocument();
    expect(screen.getByRole("alert")).toBeInTheDocument();
  });

  it("renders 404 defaults", () => {
    render(<ErrorState statusCode={404} />);
    expect(screen.getByText("Page not found")).toBeInTheDocument();
  });

  it("renders 403 defaults", () => {
    render(<ErrorState statusCode={403} />);
    expect(screen.getByText("Access forbidden")).toBeInTheDocument();
  });

  it("renders retry button by default", () => {
    const onRetry = vi.fn();
    render(<ErrorState onRetry={onRetry} />);
    const btn = screen.getByRole("button", { name: "Try again" });
    fireEvent.click(btn);
    expect(onRetry).toHaveBeenCalledOnce();
  });

  it("renders go-home link", () => {
    render(<ErrorState action="go-home" />);
    expect(screen.getByText("Go home")).toBeInTheDocument();
  });

  it("renders custom action element", () => {
    render(<ErrorState action={<button>Custom</button>} />);
    expect(screen.getByRole("button", { name: "Custom" })).toBeInTheDocument();
  });

  it("overrides title and description", () => {
    render(
      <ErrorState title="Oops" description="Something custom" />
    );
    expect(screen.getByText("Oops")).toBeInTheDocument();
    expect(screen.getByText("Something custom")).toBeInTheDocument();
  });

  it("applies custom homeHref", () => {
    render(<ErrorState action="go-home" homeHref="/dashboard" />);
    const link = screen.getByText("Go home").closest("a");
    expect(link).toHaveAttribute("href", "/dashboard");
  });
});
