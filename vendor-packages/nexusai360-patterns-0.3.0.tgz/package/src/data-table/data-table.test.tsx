import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, within } from "@testing-library/react";
import { DataTable, type ColumnDef } from "./index";

type Row = { id: number; name: string; email: string; role: string };

const columns: ColumnDef<Row>[] = [
  { id: "name", header: "Name" },
  { id: "email", header: "Email" },
  { id: "role", header: "Role" },
];

const data: Row[] = [
  { id: 1, name: "Alice", email: "alice@test.com", role: "Admin" },
  { id: 2, name: "Bob", email: "bob@test.com", role: "User" },
  { id: 3, name: "Carol", email: "carol@test.com", role: "Editor" },
];

describe("DataTable", () => {
  // --- Rendering ---
  it("renders column headers", () => {
    render(<DataTable columns={columns} data={data} />);
    expect(screen.getByText("Name")).toBeInTheDocument();
    expect(screen.getByText("Email")).toBeInTheDocument();
    expect(screen.getByText("Role")).toBeInTheDocument();
  });

  it("renders data rows", () => {
    render(<DataTable columns={columns} data={data} />);
    expect(screen.getByText("Alice")).toBeInTheDocument();
    expect(screen.getByText("bob@test.com")).toBeInTheDocument();
    expect(screen.getByText("Editor")).toBeInTheDocument();
  });

  it("renders correct number of rows", () => {
    render(<DataTable columns={columns} data={data} />);
    const rows = screen.getAllByRole("row");
    // 1 header + 3 data rows
    expect(rows.length).toBe(4);
  });

  it("renders empty state when no data", () => {
    render(<DataTable columns={columns} data={[]} />);
    expect(screen.getByText("No data available")).toBeInTheDocument();
  });

  it("renders custom empty state", () => {
    render(
      <DataTable
        columns={columns}
        data={[]}
        emptyState={<div>Nothing here</div>}
      />
    );
    expect(screen.getByText("Nothing here")).toBeInTheDocument();
  });

  it("renders loading state", () => {
    render(<DataTable columns={columns} data={[]} loading />);
    expect(screen.getByText("Loading...")).toBeInTheDocument();
  });

  // --- Custom cell renderer ---
  it("uses custom cell renderer", () => {
    const cols: ColumnDef<Row>[] = [
      {
        id: "name",
        header: "Name",
        cell: (row) => <strong>{row.name.toUpperCase()}</strong>,
      },
    ];
    render(<DataTable columns={cols} data={data} />);
    expect(screen.getByText("ALICE")).toBeInTheDocument();
  });

  // --- Sorting ---
  it("renders sort buttons when sortable", () => {
    render(
      <DataTable columns={columns} data={data} sortable onSortChange={() => {}} />
    );
    expect(screen.getByLabelText("Sort by Name")).toBeInTheDocument();
  });

  it("calls onSortChange when sort button clicked", () => {
    const onSort = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        sortable
        onSortChange={onSort}
      />
    );
    fireEvent.click(screen.getByLabelText("Sort by Name"));
    expect(onSort).toHaveBeenCalledWith({ columnId: "name", direction: "asc" });
  });

  it("toggles sort direction", () => {
    const onSort = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        sortable
        sort={{ columnId: "name", direction: "asc" }}
        onSortChange={onSort}
      />
    );
    fireEvent.click(screen.getByLabelText("Sort by Name"));
    expect(onSort).toHaveBeenCalledWith({
      columnId: "name",
      direction: "desc",
    });
  });

  it("sets aria-sort on sorted column header", () => {
    render(
      <DataTable
        columns={columns}
        data={data}
        sortable
        sort={{ columnId: "name", direction: "asc" }}
        onSortChange={() => {}}
      />
    );
    const th = screen.getByLabelText("Sort by Name").closest("th");
    expect(th).toHaveAttribute("aria-sort", "ascending");
  });

  it("does not render sort button when column.sortable=false", () => {
    const cols: ColumnDef<Row>[] = [
      { id: "name", header: "Name", sortable: false },
      { id: "email", header: "Email" },
    ];
    render(
      <DataTable columns={cols} data={data} sortable onSortChange={() => {}} />
    );
    expect(screen.queryByLabelText("Sort by Name")).toBeNull();
    expect(screen.getByLabelText("Sort by Email")).toBeInTheDocument();
  });

  // --- Selection ---
  it("renders checkboxes when selectable", () => {
    render(
      <DataTable
        columns={columns}
        data={data}
        selectable
        onSelectionChange={() => {}}
      />
    );
    const checkboxes = screen.getAllByRole("checkbox");
    // 1 header + 3 rows
    expect(checkboxes.length).toBe(4);
  });

  it("calls onSelectionChange when row checkbox clicked", () => {
    const onChange = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        selectable
        onSelectionChange={onChange}
      />
    );
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[1]); // first data row
    expect(onChange).toHaveBeenCalledWith(new Set([0]));
  });

  it("selects all when header checkbox clicked", () => {
    const onChange = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        selectable
        onSelectionChange={onChange}
      />
    );
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[0]); // header
    expect(onChange).toHaveBeenCalledWith(new Set([0, 1, 2]));
  });

  it("deselects all when header checkbox clicked while all selected", () => {
    const onChange = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        selectable
        selectedRows={new Set([0, 1, 2])}
        onSelectionChange={onChange}
      />
    );
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[0]);
    expect(onChange).toHaveBeenCalledWith(new Set());
  });

  it("removes row from selection when already selected", () => {
    const onChange = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        selectable
        selectedRows={new Set([0, 1])}
        onSelectionChange={onChange}
      />
    );
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[1]); // first data row (index 0)
    expect(onChange).toHaveBeenCalledWith(new Set([1]));
  });

  // --- Row click ---
  it("calls onRowClick when row is clicked", () => {
    const onClick = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        onRowClick={onClick}
      />
    );
    const rows = screen.getAllByRole("row");
    fireEvent.click(rows[1]); // first data row
    expect(onClick).toHaveBeenCalledWith(data[0], 0);
  });

  it("adds cursor-pointer class when onRowClick is set", () => {
    render(
      <DataTable
        columns={columns}
        data={data}
        onRowClick={() => {}}
      />
    );
    const rows = screen.getAllByRole("row");
    expect(rows[1]).toHaveClass("cursor-pointer");
  });

  // --- Pagination ---
  it("renders pagination when configured and totalPages > 1", () => {
    render(
      <DataTable
        columns={columns}
        data={data}
        pagination={{
          page: 1,
          pageSize: 2,
          total: 10,
          onPageChange: () => {},
        }}
      />
    );
    expect(screen.getByRole("navigation", { name: "pagination" })).toBeInTheDocument();
  });

  it("does not render pagination when totalPages is 1", () => {
    render(
      <DataTable
        columns={columns}
        data={data}
        pagination={{
          page: 1,
          pageSize: 10,
          total: 3,
          onPageChange: () => {},
        }}
      />
    );
    expect(screen.queryByRole("navigation")).toBeNull();
  });

  // --- Row key ---
  it("uses custom rowKey", () => {
    const { container } = render(
      <DataTable
        columns={columns}
        data={data}
        rowKey={(row) => row.id}
      />
    );
    const rows = container.querySelectorAll("tbody tr");
    expect(rows.length).toBe(3);
  });

  // --- Column width and alignment ---
  it("applies column width style", () => {
    const cols: ColumnDef<Row>[] = [
      { id: "name", header: "Name", width: "200px" },
    ];
    render(<DataTable columns={cols} data={data} />);
    const th = screen.getByText("Name").closest("th");
    expect(th).toHaveStyle({ width: "200px" });
  });

  it("applies column alignment", () => {
    const cols: ColumnDef<Row>[] = [
      { id: "name", header: "Name", align: "center" },
    ];
    render(<DataTable columns={cols} data={data} />);
    const td = screen.getByText("Alice").closest("td");
    expect(td).toHaveStyle({ textAlign: "center" });
  });

  // --- Selection with row click ---
  it("stops propagation on checkbox click (no row click)", () => {
    const onRowClick = vi.fn();
    const onSelection = vi.fn();
    render(
      <DataTable
        columns={columns}
        data={data}
        selectable
        onSelectionChange={onSelection}
        onRowClick={onRowClick}
      />
    );
    const checkboxes = screen.getAllByRole("checkbox");
    fireEvent.click(checkboxes[1]);
    expect(onSelection).toHaveBeenCalled();
    // row click should NOT fire when clicking checkbox
    // (stopPropagation is on the parent div wrapping checkbox)
  });
});
