import * as React from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
  Checkbox,
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationPrevious,
  PaginationNext,
  PaginationLink,
  PaginationEllipsis,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Sort icon                                                          */
/* ------------------------------------------------------------------ */
const SortIcon: React.FC<{ direction?: "asc" | "desc" | null }> = ({
  direction,
}) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    className="ml-1 inline-block size-4 text-zinc-500"
    aria-hidden="true"
  >
    <path
      d="M8 3v10M5 6l3-3 3 3M5 10l3 3 3-3"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      opacity={direction ? 1 : 0.4}
      transform={
        direction === "asc"
          ? "translate(0, -2)"
          : direction === "desc"
            ? "translate(0, 2)"
            : undefined
      }
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface ColumnDef<T = Record<string, unknown>> {
  /** Unique key matching a property of T */
  id: string;
  /** Column header label */
  header: string;
  /** Custom cell renderer */
  cell?: (row: T, rowIndex: number) => React.ReactNode;
  /** Whether this column is sortable */
  sortable?: boolean;
  /** Column width (CSS value) */
  width?: string;
  /** Text alignment */
  align?: "left" | "center" | "right";
}

export interface DataTablePagination {
  /** Current page (1-indexed) */
  page: number;
  /** Items per page */
  pageSize: number;
  /** Total item count (for computing total pages) */
  total: number;
  /** Callback on page change */
  onPageChange: (page: number) => void;
}

export interface SortState {
  columnId: string;
  direction: "asc" | "desc";
}

export interface DataTableProps<T = Record<string, unknown>>
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "children"> {
  /** Column definitions */
  columns: ColumnDef<T>[];
  /** Data rows */
  data: T[];
  /** Sort configuration */
  sortable?: boolean;
  /** Current sort state */
  sort?: SortState | null;
  /** Sort change callback */
  onSortChange?: (sort: SortState) => void;
  /** Enable row selection */
  selectable?: boolean;
  /** Currently selected row indices */
  selectedRows?: Set<number>;
  /** Selection change callback */
  onSelectionChange?: (selected: Set<number>) => void;
  /** Pagination configuration */
  pagination?: DataTablePagination;
  /** Row click handler */
  onRowClick?: (row: T, index: number) => void;
  /** Empty state content */
  emptyState?: React.ReactNode;
  /** Unique row key extractor (default: index) */
  rowKey?: (row: T, index: number) => string | number;
  /** Loading state */
  loading?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
function DataTableInner<T extends Record<string, unknown>>(
  props: DataTableProps<T> & { ref?: React.Ref<HTMLDivElement> }
) {
  const {
    ref,
    className,
    columns,
    data,
    sortable = false,
    sort = null,
    onSortChange,
    selectable = false,
    selectedRows = new Set<number>(),
    onSelectionChange,
    pagination,
    onRowClick,
    emptyState,
    rowKey,
    loading = false,
    ...rest
  } = props;

  /* Selection helpers */
  const allSelected = data.length > 0 && selectedRows.size === data.length;
  const someSelected = selectedRows.size > 0 && !allSelected;

  const toggleAll = React.useCallback(() => {
    if (!onSelectionChange) return;
    if (allSelected) {
      onSelectionChange(new Set());
    } else {
      onSelectionChange(new Set(data.map((_, i) => i)));
    }
  }, [allSelected, data, onSelectionChange]);

  const toggleRow = React.useCallback(
    (index: number) => {
      if (!onSelectionChange) return;
      const next = new Set(selectedRows);
      if (next.has(index)) {
        next.delete(index);
      } else {
        next.add(index);
      }
      onSelectionChange(next);
    },
    [selectedRows, onSelectionChange]
  );

  /* Sort handler */
  const handleSort = React.useCallback(
    (columnId: string) => {
      if (!onSortChange) return;
      const direction: "asc" | "desc" =
        sort?.columnId === columnId && sort.direction === "asc"
          ? "desc"
          : "asc";
      onSortChange({ columnId, direction });
    },
    [sort, onSortChange]
  );

  /* Pagination */
  const totalPages = pagination
    ? Math.max(1, Math.ceil(pagination.total / pagination.pageSize))
    : 1;

  const getKey = (row: T, index: number) =>
    rowKey ? rowKey(row, index) : index;

  return (
    <div
      ref={ref}
      className={["flex flex-col gap-4", className].filter(Boolean).join(" ")}
      {...rest}
    >
      <div className="overflow-auto rounded-lg border border-zinc-800">
        <Table>
          <TableHeader>
            <TableRow>
              {selectable && (
                <TableHead style={{ width: 48 }}>
                  <Checkbox
                    checked={allSelected}
                    indeterminate={someSelected}
                    onCheckedChange={toggleAll}
                    aria-label="Select all rows"
                  />
                </TableHead>
              )}
              {columns.map((col) => {
                const isSortable = sortable && col.sortable !== false;
                const sortDir =
                  sort?.columnId === col.id ? sort.direction : null;

                return (
                  <TableHead
                    key={col.id}
                    style={{ width: col.width, textAlign: col.align }}
                    aria-sort={
                      sortDir === "asc"
                        ? "ascending"
                        : sortDir === "desc"
                          ? "descending"
                          : undefined
                    }
                  >
                    {isSortable ? (
                      <button
                        type="button"
                        className="inline-flex items-center gap-1 text-left font-medium text-zinc-400 hover:text-zinc-100 transition-colors"
                        onClick={() => handleSort(col.id)}
                        aria-label={`Sort by ${col.header}`}
                      >
                        {col.header}
                        <SortIcon direction={sortDir} />
                      </button>
                    ) : (
                      col.header
                    )}
                  </TableHead>
                );
              })}
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell
                  colSpan={columns.length + (selectable ? 1 : 0)}
                  className="h-32 text-center text-zinc-500"
                >
                  Loading...
                </TableCell>
              </TableRow>
            ) : data.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={columns.length + (selectable ? 1 : 0)}
                  className="h-32"
                >
                  {emptyState ?? (
                    <div className="flex items-center justify-center text-zinc-500">
                      No data available
                    </div>
                  )}
                </TableCell>
              </TableRow>
            ) : (
              data.map((row, rowIndex) => {
                const isSelected = selectedRows.has(rowIndex);
                return (
                  <TableRow
                    key={getKey(row, rowIndex)}
                    data-state={isSelected ? "selected" : undefined}
                    className={onRowClick ? "cursor-pointer" : undefined}
                    onClick={
                      onRowClick
                        ? () => onRowClick(row, rowIndex)
                        : undefined
                    }
                  >
                    {selectable && (
                      <TableCell>
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleRow(rowIndex)}
                          aria-label={`Select row ${rowIndex + 1}`}
                          onClick={(e: React.MouseEvent) => e.stopPropagation()}
                        />
                      </TableCell>
                    )}
                    {columns.map((col) => (
                      <TableCell
                        key={col.id}
                        style={{ textAlign: col.align }}
                      >
                        {col.cell
                          ? col.cell(row, rowIndex)
                          : String(row[col.id] ?? "")}
                      </TableCell>
                    ))}
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {pagination && totalPages > 1 && (
        <Pagination
          currentPage={pagination.page}
          totalPages={totalPages}
          onPageChange={pagination.onPageChange}
        >
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious />
            </PaginationItem>
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 7) {
                pageNum = i + 1;
              } else if (pagination.page <= 4) {
                pageNum = i + 1;
              } else if (pagination.page >= totalPages - 3) {
                pageNum = totalPages - 6 + i;
              } else {
                pageNum = pagination.page - 3 + i;
              }

              if (pageNum < 1 || pageNum > totalPages) return null;

              return (
                <PaginationItem key={pageNum}>
                  <PaginationLink
                    page={pageNum}
                    isActive={pageNum === pagination.page}
                  />
                </PaginationItem>
              );
            })}
            {totalPages > 7 && pagination.page < totalPages - 3 && (
              <PaginationItem>
                <PaginationEllipsis />
              </PaginationItem>
            )}
            <PaginationItem>
              <PaginationNext />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      )}
    </div>
  );
}

/* Wrap for forwardRef with generics */
const DataTable = React.forwardRef(function DataTableRef<
  T extends Record<string, unknown>,
>(props: DataTableProps<T>, ref: React.Ref<HTMLDivElement>) {
  return <DataTableInner {...props} ref={ref} />;
}) as <T extends Record<string, unknown>>(
  props: DataTableProps<T> & { ref?: React.Ref<HTMLDivElement> }
) => React.ReactElement;

(DataTable as { displayName?: string }).displayName = "DataTable";

export { DataTable };
export type { ColumnDef as DataTableColumnDef };
