import { useState } from "react";
import type { ColumnDef } from "./index";
import { DataTable } from "./index";

export default { title: "Patterns/DataTable" };

interface User {
  name: string;
  email: string;
  role: string;
  status: string;
}

const columns: ColumnDef<User>[] = [
  { id: "name", header: "Name", sortable: true },
  { id: "email", header: "Email", sortable: true },
  { id: "role", header: "Role" },
  { id: "status", header: "Status", cell: (row) => (
    <span className={row.status === "Active" ? "text-emerald-400" : "text-zinc-500"}>
      {row.status}
    </span>
  )},
];

const data: User[] = [
  { name: "Alice Johnson", email: "alice@example.com", role: "Admin", status: "Active" },
  { name: "Bob Smith", email: "bob@example.com", role: "Editor", status: "Active" },
  { name: "Carol White", email: "carol@example.com", role: "Viewer", status: "Inactive" },
  { name: "Dave Brown", email: "dave@example.com", role: "Editor", status: "Active" },
  { name: "Eve Davis", email: "eve@example.com", role: "Admin", status: "Inactive" },
];

export const Default = () => <DataTable columns={columns} data={data} />;

export const Sortable = () => {
  const [sort, setSort] = useState<{ column: string; direction: "asc" | "desc" } | null>(null);
  return <DataTable columns={columns} data={data} sortable sort={sort} onSortChange={setSort} />;
};

export const Selectable = () => {
  const [selected, setSelected] = useState<Set<number>>(new Set());
  return (
    <DataTable
      columns={columns}
      data={data}
      selectable
      selectedRows={selected}
      onSelectionChange={setSelected}
    />
  );
};

export const Empty = () => <DataTable columns={columns} data={[]} />;
export const Loading = () => <DataTable columns={columns} data={[]} loading />;
