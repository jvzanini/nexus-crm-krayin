import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import type { ReactNode } from "react";
import { OnboardingProvider } from "../onboarding/onboarding-provider";
import { OnboardingStep } from "../onboarding/onboarding-step";
import { OnboardingProgress } from "../onboarding/onboarding-progress";
import { OnboardingOverlay } from "../onboarding/onboarding-overlay";
import type { OnboardingStepConfig } from "../onboarding/types";

const STEPS: OnboardingStepConfig[] = [
  { id: "s1", title: "Step 1", description: "Desc 1", targetSelector: "#a", position: "bottom" },
  { id: "s2", title: "Step 2", description: "Desc 2", targetSelector: "#b", position: "top" },
];

function Wrapper({ children }: { children: ReactNode }) {
  return <OnboardingProvider steps={STEPS}>{children}</OnboardingProvider>;
}

describe("OnboardingStep", () => {
  it("renders title and description", () => {
    render(
      <Wrapper>
        <OnboardingStep title="Hello" description="World" />
      </Wrapper>,
    );
    expect(screen.getByText("Hello")).toBeInTheDocument();
    expect(screen.getByText("World")).toBeInTheDocument();
  });

  it("renders image when provided", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" image="/img.png" />
      </Wrapper>,
    );
    expect(screen.getByTestId("onboarding-step-image")).toHaveAttribute("src", "/img.png");
  });

  it("does not render image when not provided", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" />
      </Wrapper>,
    );
    expect(screen.queryByTestId("onboarding-step-image")).not.toBeInTheDocument();
  });

  it("action button advances step on click (action=next)", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" action="next" />
      </Wrapper>,
    );
    const btn = screen.getByTestId("onboarding-step-action");
    expect(btn).toHaveTextContent("Next");
    fireEvent.click(btn);
    // just verifying no error and click works
  });

  it("action=skip calls skipAll", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" action="skip" />
      </Wrapper>,
    );
    const btn = screen.getByTestId("onboarding-step-action");
    expect(btn).toHaveTextContent("Skip");
  });

  it("uses custom actionLabel", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" actionLabel="Go!" />
      </Wrapper>,
    );
    expect(screen.getByTestId("onboarding-step-action")).toHaveTextContent("Go!");
  });

  it("shows skip button when action=next", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" action="next" />
      </Wrapper>,
    );
    expect(screen.getByTestId("onboarding-step-skip")).toBeInTheDocument();
  });

  it("hides skip button when action=skip", () => {
    render(
      <Wrapper>
        <OnboardingStep title="T" description="D" action="skip" />
      </Wrapper>,
    );
    expect(screen.queryByTestId("onboarding-step-skip")).not.toBeInTheDocument();
  });
});

describe("OnboardingProgress", () => {
  it("renders progress bar variant by default", () => {
    render(
      <Wrapper>
        <OnboardingProgress />
      </Wrapper>,
    );
    expect(screen.getByTestId("onboarding-progress-bar")).toBeInTheDocument();
  });

  it("renders dots variant", () => {
    render(
      <Wrapper>
        <OnboardingProgress variant="dots" />
      </Wrapper>,
    );
    expect(screen.getByTestId("onboarding-progress-dots")).toBeInTheDocument();
    expect(screen.getByTestId("onboarding-dot-0")).toBeInTheDocument();
    expect(screen.getByTestId("onboarding-dot-1")).toBeInTheDocument();
  });

  it("respects override props", () => {
    render(
      <Wrapper>
        <OnboardingProgress totalSteps={5} currentStep={3} />
      </Wrapper>,
    );
    const bar = screen.getByTestId("onboarding-progress-bar");
    expect(bar).toHaveAttribute("aria-valuenow", "60");
  });
});

describe("OnboardingOverlay", () => {
  it("renders overlay when onboarding is active", () => {
    render(
      <Wrapper>
        <OnboardingOverlay />
      </Wrapper>,
    );
    expect(screen.getByTestId("onboarding-overlay")).toBeInTheDocument();
  });

  it("renders children as tooltip content", () => {
    render(
      <Wrapper>
        <OnboardingOverlay>
          <span data-testid="custom-content">Tooltip</span>
        </OnboardingOverlay>
      </Wrapper>,
    );
    expect(screen.getByTestId("custom-content")).toBeInTheDocument();
  });
});
