import { describe, it, expect } from "vitest";
import { renderHook, act } from "@testing-library/react";
import { useNotifications } from "../notification-center/use-notifications";
import type { Notification } from "../notification-center/types";

function makeNotif(overrides: Partial<Notification> = {}): Notification {
  return {
    id: "n1",
    title: "Test",
    type: "info",
    read: false,
    createdAt: new Date(),
    ...overrides,
  };
}

describe("useNotifications", () => {
  it("starts with empty array by default", () => {
    const { result } = renderHook(() => useNotifications());
    expect(result.current.notifications).toHaveLength(0);
    expect(result.current.unreadCount).toBe(0);
  });

  it("accepts initial notifications", () => {
    const initial = [makeNotif({ id: "a" }), makeNotif({ id: "b", read: true })];
    const { result } = renderHook(() => useNotifications(initial));
    expect(result.current.notifications).toHaveLength(2);
    expect(result.current.unreadCount).toBe(1);
  });

  it("add() prepends a new notification", () => {
    const { result } = renderHook(() => useNotifications());
    act(() => result.current.add({ title: "New", type: "success" }));
    expect(result.current.notifications).toHaveLength(1);
    expect(result.current.notifications[0]!.title).toBe("New");
    expect(result.current.notifications[0]!.read).toBe(false);
    expect(result.current.unreadCount).toBe(1);
  });

  it("add() generates unique IDs", () => {
    const { result } = renderHook(() => useNotifications());
    act(() => result.current.add({ title: "A", type: "info" }));
    act(() => result.current.add({ title: "B", type: "info" }));
    const ids = result.current.notifications.map((n) => n.id);
    expect(new Set(ids).size).toBe(2);
  });

  it("add() respects custom id", () => {
    const { result } = renderHook(() => useNotifications());
    act(() => result.current.add({ id: "custom-1", title: "A", type: "info" }));
    expect(result.current.notifications[0]!.id).toBe("custom-1");
  });

  it("markRead() marks a single notification as read", () => {
    const initial = [makeNotif({ id: "a" }), makeNotif({ id: "b" })];
    const { result } = renderHook(() => useNotifications(initial));
    act(() => result.current.markRead("a"));
    expect(result.current.notifications.find((n) => n.id === "a")!.read).toBe(true);
    expect(result.current.notifications.find((n) => n.id === "b")!.read).toBe(false);
    expect(result.current.unreadCount).toBe(1);
  });

  it("markAllRead() marks all as read", () => {
    const initial = [makeNotif({ id: "a" }), makeNotif({ id: "b" })];
    const { result } = renderHook(() => useNotifications(initial));
    act(() => result.current.markAllRead());
    expect(result.current.unreadCount).toBe(0);
    expect(result.current.notifications.every((n) => n.read)).toBe(true);
  });

  it("dismiss() removes a notification", () => {
    const initial = [makeNotif({ id: "a" }), makeNotif({ id: "b" })];
    const { result } = renderHook(() => useNotifications(initial));
    act(() => result.current.dismiss("a"));
    expect(result.current.notifications).toHaveLength(1);
    expect(result.current.notifications[0]!.id).toBe("b");
  });

  it("clearAll() removes all notifications", () => {
    const initial = [makeNotif({ id: "a" }), makeNotif({ id: "b" })];
    const { result } = renderHook(() => useNotifications(initial));
    act(() => result.current.clearAll());
    expect(result.current.notifications).toHaveLength(0);
    expect(result.current.unreadCount).toBe(0);
  });

  it("dismiss() on non-existent id is a no-op", () => {
    const initial = [makeNotif({ id: "a" })];
    const { result } = renderHook(() => useNotifications(initial));
    act(() => result.current.dismiss("zzz"));
    expect(result.current.notifications).toHaveLength(1);
  });

  it("markRead() on non-existent id is a no-op", () => {
    const initial = [makeNotif({ id: "a" })];
    const { result } = renderHook(() => useNotifications(initial));
    act(() => result.current.markRead("zzz"));
    expect(result.current.notifications[0]!.read).toBe(false);
  });

  it("add() sets createdAt to current date", () => {
    const before = Date.now();
    const { result } = renderHook(() => useNotifications());
    act(() => result.current.add({ title: "T", type: "info" }));
    const after = Date.now();
    const ts = result.current.notifications[0]!.createdAt.getTime();
    expect(ts).toBeGreaterThanOrEqual(before);
    expect(ts).toBeLessThanOrEqual(after);
  });
});
