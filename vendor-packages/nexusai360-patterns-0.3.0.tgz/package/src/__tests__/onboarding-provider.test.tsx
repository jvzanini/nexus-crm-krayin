import { describe, it, expect, vi, beforeEach } from "vitest";
import { renderHook, act } from "@testing-library/react";
import type { ReactNode } from "react";
import {
  OnboardingProvider,
  useOnboardingPattern,
} from "../onboarding/onboarding-provider";
import type { OnboardingStepConfig } from "../onboarding/types";

const STEPS: OnboardingStepConfig[] = [
  { id: "s1", title: "Step 1", description: "Desc 1", targetSelector: "#a", position: "bottom" },
  { id: "s2", title: "Step 2", description: "Desc 2", targetSelector: "#b", position: "top" },
  { id: "s3", title: "Step 3", description: "Desc 3", targetSelector: "#c", position: "right" },
];

function makeWrapper(steps = STEPS, props: Record<string, unknown> = {}) {
  return function Wrapper({ children }: { children: ReactNode }) {
    return (
      <OnboardingProvider steps={steps} {...props}>
        {children}
      </OnboardingProvider>
    );
  };
}

describe("OnboardingProvider", () => {
  it("throws when useOnboardingPattern is used outside provider", () => {
    expect(() => renderHook(() => useOnboardingPattern())).toThrow(
      "useOnboardingPattern must be used within <OnboardingProvider>",
    );
  });

  it("starts at step 0 with correct currentStep", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.currentStepIndex).toBe(0);
    expect(result.current.currentStep?.id).toBe("s1");
    expect(result.current.isComplete).toBe(false);
  });

  it("exposes totalSteps correctly", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.totalSteps).toBe(3);
  });

  it("progress starts at 0", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    expect(result.current.progress).toBe(0);
  });

  it("nextStep advances to next step", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.nextStep());
    expect(result.current.currentStepIndex).toBe(1);
    expect(result.current.currentStep?.id).toBe("s2");
  });

  it("progress updates after nextStep", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.nextStep());
    expect(result.current.progress).toBeCloseTo(1 / 3);
  });

  it("nextStep on last step completes onboarding", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.nextStep()); // s1 -> s2
    act(() => result.current.nextStep()); // s2 -> s3
    act(() => result.current.nextStep()); // s3 -> complete
    expect(result.current.isComplete).toBe(true);
    expect(result.current.currentStep).toBeNull();
  });

  it("calls onComplete when finishing all steps", () => {
    const onComplete = vi.fn();
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(STEPS, { onComplete }),
    });
    act(() => result.current.nextStep());
    act(() => result.current.nextStep());
    act(() => result.current.nextStep());
    expect(onComplete).toHaveBeenCalledTimes(1);
  });

  it("prevStep goes to previous step", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.nextStep());
    expect(result.current.currentStepIndex).toBe(1);
    act(() => result.current.prevStep());
    expect(result.current.currentStepIndex).toBe(0);
    expect(result.current.currentStep?.id).toBe("s1");
  });

  it("prevStep does nothing at step 0", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.prevStep());
    expect(result.current.currentStepIndex).toBe(0);
  });

  it("skipAll marks as complete immediately", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.skipAll());
    expect(result.current.isComplete).toBe(true);
    expect(result.current.currentStep).toBeNull();
  });

  it("nextStep is no-op after completion", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.skipAll());
    act(() => result.current.nextStep());
    expect(result.current.isComplete).toBe(true);
  });

  it("prevStep is no-op after completion", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(),
    });
    act(() => result.current.skipAll());
    act(() => result.current.prevStep());
    expect(result.current.isComplete).toBe(true);
  });

  it("handles empty steps array", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper([]),
    });
    expect(result.current.totalSteps).toBe(0);
    expect(result.current.currentStep).toBeNull();
    expect(result.current.progress).toBe(1);
  });
});

describe("OnboardingProvider persistence", () => {
  let store: Record<string, string>;

  beforeEach(() => {
    store = {};
  });

  const mockStorage = {
    get: (key: string) => store[key] ?? null,
    set: (key: string, value: string) => { store[key] = value; },
    remove: (key: string) => { delete store[key]; },
  };

  it("persists state to storage on nextStep", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(STEPS, { storageKey: "ob-test", storage: mockStorage }),
    });
    act(() => result.current.nextStep());
    const saved = JSON.parse(store["ob-test"] ?? "{}");
    expect(saved.currentStepIndex).toBe(1);
  });

  it("restores state from storage on mount", () => {
    store["ob-test"] = JSON.stringify({ currentStepIndex: 2, isComplete: false, skipped: false });
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(STEPS, { storageKey: "ob-test", storage: mockStorage }),
    });
    expect(result.current.currentStepIndex).toBe(2);
    expect(result.current.currentStep?.id).toBe("s3");
  });

  it("persists completed state", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(STEPS, { storageKey: "ob-test", storage: mockStorage }),
    });
    act(() => result.current.skipAll());
    const saved = JSON.parse(store["ob-test"] ?? "{}");
    expect(saved.isComplete).toBe(true);
  });

  it("handles corrupt storage gracefully", () => {
    store["ob-test"] = "not-json";
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(STEPS, { storageKey: "ob-test", storage: mockStorage }),
    });
    expect(result.current.currentStepIndex).toBe(0);
  });

  it("does not persist when storageKey is omitted", () => {
    const { result } = renderHook(() => useOnboardingPattern(), {
      wrapper: makeWrapper(STEPS, { storage: mockStorage }),
    });
    act(() => result.current.nextStep());
    expect(Object.keys(store)).toHaveLength(0);
  });
});
