import { describe, it, expect } from "vitest";
import { render } from "@testing-library/react";
import { PageHeader } from "../page-header";

describe("PageHeader — tokens semânticos", () => {
  it("título usa text-foreground (não text-zinc-50)", () => {
    const { container } = render(<PageHeader title="Test" />);
    const h1 = container.querySelector("h1");
    expect(h1?.className).toContain("text-foreground");
    expect(h1?.className).not.toContain("text-zinc-50");
  });

  it("description usa text-muted-foreground (não text-zinc-400)", () => {
    const { container } = render(
      <PageHeader title="Test" description="desc" />
    );
    const p = container.querySelector("p");
    expect(p?.className).toContain("text-muted-foreground");
    expect(p?.className).not.toContain("text-zinc-400");
  });

  it("backwards-compat: breadcrumbs undefined não crasha", () => {
    const { container } = render(<PageHeader title="Test" />);
    expect(container.querySelector("h1")?.textContent).toBe("Test");
  });
});
