import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { PageShell } from "../page-shell";

describe("PageShell — backwards-compat", () => {
  it("renderiza sem props novas", () => {
    render(
      <PageShell sidebar={<nav>nav</nav>} header={<h1>header</h1>}>
        <div>content</div>
      </PageShell>
    );
    expect(screen.getByTestId("page-shell-sidebar")).toBeInTheDocument();
    expect(screen.getByTestId("page-shell-header")).toBeInTheDocument();
    expect(screen.getByTestId("page-shell-main")).toBeInTheDocument();
    expect(screen.getByText("content")).toBeInTheDocument();
  });

  it("default sidebarWidth 280 preservado", () => {
    const { container } = render(
      <PageShell sidebar={<nav />}>x</PageShell>
    );
    const grid = container.firstChild as HTMLElement;
    expect(grid.style.gridTemplateColumns).toContain("280px");
  });
});

describe("PageShell — extensões v3", () => {
  it("renderiza topbar quando fornecido", () => {
    render(
      <PageShell topbar={<div data-testid="topbar">t</div>}>x</PageShell>
    );
    expect(screen.getByTestId("topbar")).toBeInTheDocument();
  });

  it("collapsedSidebarWidth exposto como data-attr", () => {
    const { container } = render(
      <PageShell sidebar={<nav />} collapsedSidebarWidth={85}>
        x
      </PageShell>
    );
    const root = container.firstChild as HTMLElement;
    expect(root.getAttribute("data-collapsed-width")).toBe("85");
  });

  it("sidebarCollapsed=true oculta sidebar", () => {
    const { container } = render(
      <PageShell sidebar={<nav />} sidebarCollapsed>
        x
      </PageShell>
    );
    const grid = container.firstChild as HTMLElement;
    expect(grid.style.gridTemplateColumns).toBe("1fr");
  });

  it("usa tokens semânticos (bg-background/bg-card/border-border)", () => {
    const { container } = render(
      <PageShell sidebar={<nav />} header={<h1 />}>
        x
      </PageShell>
    );
    const sidebar = container.querySelector('[data-testid="page-shell-sidebar"]');
    const header = container.querySelector('[data-testid="page-shell-header"]');
    const main = container.querySelector('[data-testid="page-shell-main"]');
    expect(sidebar?.className).toMatch(/bg-card|bg-sidebar/);
    expect(sidebar?.className).toContain("border-border");
    expect(header?.className).toMatch(/bg-card|bg-background/);
    expect(main?.className).toContain("bg-background");
    expect(sidebar?.className).not.toMatch(/zinc-\d+/);
    expect(header?.className).not.toMatch(/zinc-\d+/);
    expect(main?.className).not.toMatch(/zinc-\d+/);
  });
});
