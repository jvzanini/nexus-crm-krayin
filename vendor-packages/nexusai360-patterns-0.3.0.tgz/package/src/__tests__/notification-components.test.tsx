import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { NotificationItem } from "../notification-center/notification-item";
import { NotificationList } from "../notification-center/notification-list";
import { NotificationBadge } from "../notification-center/notification-badge";
import type { Notification } from "../notification-center/types";

function makeNotif(overrides: Partial<Notification> = {}): Notification {
  return {
    id: "n1",
    title: "Test Notification",
    description: "Some description",
    type: "info",
    read: false,
    createdAt: new Date(),
    ...overrides,
  };
}

describe("NotificationItem", () => {
  it("renders title and description", () => {
    render(<NotificationItem notification={makeNotif()} />);
    expect(screen.getByText("Test Notification")).toBeInTheDocument();
    expect(screen.getByText("Some description")).toBeInTheDocument();
  });

  it("calls onRead when clicked and unread", () => {
    const onRead = vi.fn();
    render(<NotificationItem notification={makeNotif()} onRead={onRead} />);
    fireEvent.click(screen.getByTestId("notification-item-n1"));
    expect(onRead).toHaveBeenCalledWith("n1");
  });

  it("does not call onRead when already read", () => {
    const onRead = vi.fn();
    render(
      <NotificationItem notification={makeNotif({ read: true })} onRead={onRead} />,
    );
    fireEvent.click(screen.getByTestId("notification-item-n1"));
    expect(onRead).not.toHaveBeenCalled();
  });

  it("calls onDismiss when dismiss button clicked", () => {
    const onDismiss = vi.fn();
    render(
      <NotificationItem notification={makeNotif()} onDismiss={onDismiss} />,
    );
    fireEvent.click(screen.getByTestId("notification-dismiss-n1"));
    expect(onDismiss).toHaveBeenCalledWith("n1");
  });

  it("does not show dismiss button when onDismiss not provided", () => {
    render(<NotificationItem notification={makeNotif()} />);
    expect(screen.queryByTestId("notification-dismiss-n1")).not.toBeInTheDocument();
  });

  it("renders action link when action.href is provided", () => {
    const notif = makeNotif({
      action: { label: "View", href: "/details" },
    });
    render(<NotificationItem notification={notif} />);
    expect(screen.getByTestId("notification-action-n1")).toHaveAttribute("href", "/details");
  });

  it("calls action.onClick on click", () => {
    const onClick = vi.fn();
    const notif = makeNotif({ action: { label: "Act", onClick } });
    render(<NotificationItem notification={notif} />);
    fireEvent.click(screen.getByTestId("notification-item-n1"));
    expect(onClick).toHaveBeenCalled();
  });
});

describe("NotificationList", () => {
  it("renders notifications", () => {
    const notifications = [makeNotif({ id: "a" }), makeNotif({ id: "b" })];
    render(<NotificationList notifications={notifications} />);
    expect(screen.getByTestId("notification-list")).toBeInTheDocument();
    expect(screen.getByTestId("notification-item-a")).toBeInTheDocument();
    expect(screen.getByTestId("notification-item-b")).toBeInTheDocument();
  });

  it("shows empty message when no notifications", () => {
    render(<NotificationList notifications={[]} />);
    expect(screen.getByTestId("notification-list-empty")).toBeInTheDocument();
    expect(screen.getByText("No notifications")).toBeInTheDocument();
  });

  it("shows custom empty message", () => {
    render(<NotificationList notifications={[]} emptyMessage="Nothing here" />);
    expect(screen.getByText("Nothing here")).toBeInTheDocument();
  });

  it("shows loading state", () => {
    render(<NotificationList notifications={[]} loading />);
    expect(screen.getByTestId("notification-list-loading")).toBeInTheDocument();
  });
});

describe("NotificationBadge", () => {
  it("renders bell icon", () => {
    render(<NotificationBadge count={3} />);
    expect(screen.getByTestId("notification-bell-icon")).toBeInTheDocument();
  });

  it("shows count when > 0", () => {
    render(<NotificationBadge count={5} />);
    const badge = screen.getByTestId("notification-badge-count");
    expect(badge).toHaveTextContent("5");
    expect(badge).toHaveStyle({ display: "flex" });
  });

  it("hides badge when count is 0", () => {
    render(<NotificationBadge count={0} />);
    const badge = screen.getByTestId("notification-badge-count");
    expect(badge).toHaveStyle({ display: "none" });
  });

  it("shows N+ when exceeding max", () => {
    render(<NotificationBadge count={150} max={99} />);
    expect(screen.getByTestId("notification-badge-count")).toHaveTextContent("99+");
  });

  it("calls onClick", () => {
    const onClick = vi.fn();
    render(<NotificationBadge count={1} onClick={onClick} />);
    fireEvent.click(screen.getByTestId("notification-badge"));
    expect(onClick).toHaveBeenCalled();
  });

  it("has accessible aria-label", () => {
    render(<NotificationBadge count={3} />);
    expect(screen.getByTestId("notification-badge")).toHaveAttribute(
      "aria-label",
      "3 unread notifications",
    );
  });

  it("singular label for count=1", () => {
    render(<NotificationBadge count={1} />);
    expect(screen.getByTestId("notification-badge")).toHaveAttribute(
      "aria-label",
      "1 unread notification",
    );
  });
});

describe("NotificationBadge additional", () => {
  it("uses custom aria-label when provided", () => {
    render(<NotificationBadge count={3} aria-label="Custom label" />);
    expect(screen.getByTestId("notification-badge")).toHaveAttribute(
      "aria-label",
      "Custom label",
    );
  });

  it("renders count as string", () => {
    render(<NotificationBadge count={42} />);
    expect(screen.getByTestId("notification-badge-count")).toHaveTextContent("42");
  });
});
