import * as React from "react";
import { PageHeader, type BreadcrumbEntry } from "../page-header";

export interface CrmListShellProps {
  title: string;
  description?: string;
  breadcrumbs?: BreadcrumbEntry[];
  actions?: React.ReactNode;
  toolbar?: React.ReactNode;
  /** Opcional: slot de ícone renderizado à esquerda do título (ex: IconTile). */
  icon?: React.ReactNode;
  children: React.ReactNode;
}

export function CrmListShell({
  title,
  description,
  breadcrumbs,
  actions,
  toolbar,
  icon,
  children,
}: CrmListShellProps) {
  return (
    <div className="flex flex-col gap-4" data-slot="crm-list-shell">
      <div
        data-slot="crm-list-header"
        className="rounded-lg border border-border bg-card px-4 py-3"
      >
        {icon ? (
          <div className="flex flex-col gap-4">
            {breadcrumbs && breadcrumbs.length > 0 && (
              <PageHeader
                title=""
                breadcrumbs={breadcrumbs}
                aria-hidden={false}
              />
            )}
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <div data-slot="crm-list-icon" className="shrink-0">
                  {icon}
                </div>
                <div className="flex flex-col gap-1">
                  <h1 className="text-2xl font-bold tracking-tight text-foreground">
                    {title}
                  </h1>
                  {description && (
                    <p className="text-sm text-muted-foreground">
                      {description}
                    </p>
                  )}
                </div>
              </div>
              {actions && (
                <div className="flex shrink-0 items-center gap-2">
                  {actions}
                </div>
              )}
            </div>
          </div>
        ) : (
          <PageHeader
            title={title}
            description={description}
            breadcrumbs={breadcrumbs}
            actions={actions}
          />
        )}
      </div>
      {toolbar && <div data-slot="crm-list-toolbar">{toolbar}</div>}
      <div data-slot="crm-list-content">{children}</div>
    </div>
  );
}
