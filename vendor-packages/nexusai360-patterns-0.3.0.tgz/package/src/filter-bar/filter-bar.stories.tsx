import { useState } from "react";
import type { FilterDefinition, FilterValues } from "./index";
import { FilterBar } from "./index";

export default { title: "Patterns/FilterBar" };

const filters: FilterDefinition[] = [
  { id: "search", label: "Search", type: "text", placeholder: "Search by name..." },
  {
    id: "status",
    label: "Status",
    type: "select",
    options: [
      { label: "Active", value: "active" },
      { label: "Inactive", value: "inactive" },
    ],
  },
  { id: "created", label: "Created", type: "date" },
];

export const Default = () => {
  const [values, setValues] = useState<FilterValues>({});
  return <FilterBar filters={filters} values={values} onFilterChange={setValues} showReset />;
};
