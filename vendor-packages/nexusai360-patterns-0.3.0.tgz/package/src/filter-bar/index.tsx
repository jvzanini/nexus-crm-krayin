import * as React from "react";
import { Button, Input } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface FilterDefinition {
  /** Unique filter key */
  id: string;
  /** Display label */
  label: string;
  /** Filter input type */
  type: "text" | "select" | "date";
  /** Placeholder text */
  placeholder?: string;
  /** Options for select type */
  options?: { label: string; value: string }[];
}

export interface FilterValues {
  [key: string]: string;
}

export interface FilterBarProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Filter definitions */
  filters: FilterDefinition[];
  /** Current filter values */
  values?: FilterValues;
  /** Callback on any filter change */
  onFilterChange?: (values: FilterValues) => void;
  /** Callback to clear all filters */
  onReset?: () => void;
  /** Show reset button */
  showReset?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const FilterBar = React.forwardRef<HTMLDivElement, FilterBarProps>(
  (
    {
      className,
      filters,
      values: controlledValues,
      onFilterChange,
      onReset,
      showReset = true,
      ...props
    },
    ref
  ) => {
    const [internalValues, setInternalValues] = React.useState<FilterValues>(
      {}
    );
    const values = controlledValues ?? internalValues;

    const handleChange = React.useCallback(
      (id: string, value: string) => {
        const next = { ...values, [id]: value };
        setInternalValues(next);
        onFilterChange?.(next);
      },
      [values, onFilterChange]
    );

    const handleReset = React.useCallback(() => {
      const empty: FilterValues = {};
      filters.forEach((f) => {
        empty[f.id] = "";
      });
      setInternalValues(empty);
      onFilterChange?.(empty);
      onReset?.();
    }, [filters, onFilterChange, onReset]);

    const hasActiveFilters = Object.values(values).some(
      (v) => v !== undefined && v !== ""
    );

    return (
      <div
        ref={ref}
        className={[
          "flex flex-wrap items-end gap-3",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        role="search"
        aria-label="Filters"
        {...props}
      >
        {filters.map((filter) => {
          const currentValue = values[filter.id] ?? "";

          if (filter.type === "select" && filter.options) {
            return (
              <div key={filter.id} className="flex flex-col gap-1">
                <label
                  className="text-xs font-medium text-zinc-400"
                  htmlFor={`filter-${filter.id}`}
                >
                  {filter.label}
                </label>
                <select
                  id={`filter-${filter.id}`}
                  value={currentValue}
                  onChange={(e) => handleChange(filter.id, e.target.value)}
                  className="h-9 rounded-md border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus-visible:border-violet-500 focus-visible:ring-2 focus-visible:ring-violet-500/50"
                >
                  <option value="">
                    {filter.placeholder ?? `All ${filter.label}`}
                  </option>
                  {filter.options.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            );
          }

          if (filter.type === "date") {
            return (
              <div key={filter.id} className="flex flex-col gap-1">
                <label
                  className="text-xs font-medium text-zinc-400"
                  htmlFor={`filter-${filter.id}`}
                >
                  {filter.label}
                </label>
                <input
                  id={`filter-${filter.id}`}
                  type="date"
                  value={currentValue}
                  onChange={(e) => handleChange(filter.id, e.target.value)}
                  className="h-9 rounded-md border border-zinc-700 bg-zinc-900 px-3 text-sm text-zinc-100 outline-none focus-visible:border-violet-500 focus-visible:ring-2 focus-visible:ring-violet-500/50"
                />
              </div>
            );
          }

          // Default: text
          return (
            <div key={filter.id} className="flex flex-col gap-1">
              <label
                className="text-xs font-medium text-zinc-400"
                htmlFor={`filter-${filter.id}`}
              >
                {filter.label}
              </label>
              <Input
                id={`filter-${filter.id}`}
                size="sm"
                value={currentValue}
                onChange={(e) => handleChange(filter.id, e.target.value)}
                placeholder={filter.placeholder ?? `Filter by ${filter.label.toLowerCase()}`}
              />
            </div>
          );
        })}

        {showReset && hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleReset}
            aria-label="Reset all filters"
          >
            Reset
          </Button>
        )}
      </div>
    );
  }
);

FilterBar.displayName = "FilterBar";

export { FilterBar };
