import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { FilterBar, type FilterDefinition } from "./index";

const filters: FilterDefinition[] = [
  { id: "name", label: "Name", type: "text", placeholder: "Search name" },
  {
    id: "role",
    label: "Role",
    type: "select",
    options: [
      { label: "Admin", value: "admin" },
      { label: "User", value: "user" },
    ],
  },
  { id: "date", label: "Date", type: "date" },
];

describe("FilterBar", () => {
  it("renders all filter inputs", () => {
    render(<FilterBar filters={filters} />);
    expect(screen.getByLabelText("Name")).toBeInTheDocument();
    expect(screen.getByLabelText("Role")).toBeInTheDocument();
    expect(screen.getByLabelText("Date")).toBeInTheDocument();
  });

  it("renders text input with placeholder", () => {
    render(<FilterBar filters={filters} />);
    expect(screen.getByPlaceholderText("Search name")).toBeInTheDocument();
  });

  it("renders select options", () => {
    render(<FilterBar filters={filters} />);
    const select = screen.getByLabelText("Role") as HTMLSelectElement;
    expect(select.options.length).toBe(3); // All + Admin + User
  });

  it("calls onFilterChange when text changes", () => {
    const onChange = vi.fn();
    render(<FilterBar filters={filters} onFilterChange={onChange} />);
    fireEvent.change(screen.getByLabelText("Name"), {
      target: { value: "Alice" },
    });
    expect(onChange).toHaveBeenCalledWith(
      expect.objectContaining({ name: "Alice" })
    );
  });

  it("calls onFilterChange when select changes", () => {
    const onChange = vi.fn();
    render(<FilterBar filters={filters} onFilterChange={onChange} />);
    fireEvent.change(screen.getByLabelText("Role"), {
      target: { value: "admin" },
    });
    expect(onChange).toHaveBeenCalledWith(
      expect.objectContaining({ role: "admin" })
    );
  });

  it("shows reset button when filters have values", () => {
    render(
      <FilterBar
        filters={filters}
        values={{ name: "test", role: "", date: "" }}
      />
    );
    expect(screen.getByLabelText("Reset all filters")).toBeInTheDocument();
  });

  it("does not show reset button when no active filters", () => {
    render(<FilterBar filters={filters} values={{}} />);
    expect(screen.queryByLabelText("Reset all filters")).toBeNull();
  });

  it("calls onReset when reset button clicked", () => {
    const onReset = vi.fn();
    const onChange = vi.fn();
    render(
      <FilterBar
        filters={filters}
        values={{ name: "test" }}
        onFilterChange={onChange}
        onReset={onReset}
      />
    );
    fireEvent.click(screen.getByLabelText("Reset all filters"));
    expect(onReset).toHaveBeenCalledOnce();
    expect(onChange).toHaveBeenCalledWith(
      expect.objectContaining({ name: "", role: "", date: "" })
    );
  });

  it("renders with role=search", () => {
    render(<FilterBar filters={filters} />);
    expect(screen.getByRole("search")).toBeInTheDocument();
  });
});
