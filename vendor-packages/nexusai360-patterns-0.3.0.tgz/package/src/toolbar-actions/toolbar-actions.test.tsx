import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { ToolbarActions, type ToolbarAction } from "./index";

describe("ToolbarActions", () => {
  const actions: ToolbarAction[] = [
    { label: "Add", onClick: vi.fn(), variant: "primary" },
    { label: "Export", onClick: vi.fn(), variant: "secondary" },
  ];

  it("renders action buttons", () => {
    render(<ToolbarActions actions={actions} />);
    expect(screen.getByRole("button", { name: "Add" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Export" })).toBeInTheDocument();
  });

  it("calls onClick when action button clicked", () => {
    render(<ToolbarActions actions={actions} />);
    fireEvent.click(screen.getByRole("button", { name: "Add" }));
    expect(actions[0].onClick).toHaveBeenCalledOnce();
  });

  it("shows selected count", () => {
    render(<ToolbarActions selectedCount={3} />);
    expect(screen.getByText("3 selected")).toBeInTheDocument();
  });

  it("does not show selected count when 0", () => {
    render(<ToolbarActions selectedCount={0} />);
    expect(screen.queryByText("0 selected")).toBeNull();
  });

  it("renders search input when search=true", () => {
    render(<ToolbarActions search />);
    expect(screen.getByLabelText("Search")).toBeInTheDocument();
  });

  it("calls onSearchChange when typing", () => {
    const onSearch = vi.fn();
    render(<ToolbarActions search onSearchChange={onSearch} />);
    fireEvent.change(screen.getByLabelText("Search"), {
      target: { value: "hello" },
    });
    expect(onSearch).toHaveBeenCalledWith("hello");
  });

  it("renders with role=toolbar", () => {
    render(<ToolbarActions />);
    expect(screen.getByRole("toolbar")).toBeInTheDocument();
  });

  it("disables action when disabled=true", () => {
    const disabled: ToolbarAction[] = [
      { label: "Disabled", onClick: vi.fn(), disabled: true },
    ];
    render(<ToolbarActions actions={disabled} />);
    expect(screen.getByRole("button", { name: "Disabled" })).toBeDisabled();
  });
});
