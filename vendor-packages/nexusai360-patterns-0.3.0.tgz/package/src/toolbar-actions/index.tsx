import * as React from "react";
import { Button, Input } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface ToolbarAction {
  /** Button label */
  label: string;
  /** Optional icon rendered before label */
  icon?: React.ReactNode;
  /** Click handler */
  onClick: () => void;
  /** Button variant */
  variant?: "primary" | "secondary" | "ghost" | "danger" | "outline";
  /** Whether the action is disabled */
  disabled?: boolean;
}

export interface ToolbarActionsProps
  extends React.HTMLAttributes<HTMLDivElement> {
  /** Number of currently selected items (shown as text) */
  selectedCount?: number;
  /** Action buttons */
  actions?: ToolbarAction[];
  /** Whether to show a search input */
  search?: boolean;
  /** Current search value */
  searchValue?: string;
  /** Search input placeholder */
  searchPlaceholder?: string;
  /** Search change callback */
  onSearchChange?: (value: string) => void;
}

/* ------------------------------------------------------------------ */
/*  Search Icon                                                        */
/* ------------------------------------------------------------------ */
const SearchIcon: React.FC = () => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    className="size-4"
    aria-hidden="true"
  >
    <circle cx="7" cy="7" r="4.5" stroke="currentColor" strokeWidth="1.5" />
    <path
      d="M10.5 10.5L14 14"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const ToolbarActions = React.forwardRef<HTMLDivElement, ToolbarActionsProps>(
  (
    {
      className,
      selectedCount = 0,
      actions = [],
      search = false,
      searchValue = "",
      searchPlaceholder = "Search...",
      onSearchChange,
      ...props
    },
    ref
  ) => {
    return (
      <div
        ref={ref}
        className={[
          "flex items-center justify-between gap-3",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        role="toolbar"
        aria-label="Table actions"
        {...props}
      >
        <div className="flex items-center gap-3">
          {search && (
            <Input
              size="sm"
              value={searchValue}
              onChange={(e) => onSearchChange?.(e.target.value)}
              placeholder={searchPlaceholder}
              leftAddon={<SearchIcon />}
              aria-label="Search"
              className="w-64"
            />
          )}
          {selectedCount > 0 && (
            <span className="text-sm text-zinc-400">
              {selectedCount} selected
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          {actions.map((action) => (
            <Button
              key={action.label}
              variant={action.variant ?? "secondary"}
              size="sm"
              onClick={action.onClick}
              disabled={action.disabled}
              leftIcon={action.icon}
            >
              {action.label}
            </Button>
          ))}
        </div>
      </div>
    );
  }
);

ToolbarActions.displayName = "ToolbarActions";

export { ToolbarActions };
