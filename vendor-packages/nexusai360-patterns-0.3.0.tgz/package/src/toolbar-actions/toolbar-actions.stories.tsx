import { ToolbarActions } from "./index";

export default { title: "Patterns/ToolbarActions" };

export const Default = () => (
  <ToolbarActions
    actions={[
      { label: "Add", onClick: () => {}, variant: "primary" },
      { label: "Export", onClick: () => {}, variant: "secondary" },
      { label: "Delete", onClick: () => {}, variant: "danger", disabled: true },
    ]}
  />
);

export const WithSearch = () => (
  <ToolbarActions
    search
    searchPlaceholder="Search contacts..."
    onSearchChange={() => {}}
    actions={[{ label: "Add Contact", onClick: () => {}, variant: "primary" }]}
  />
);

export const WithSelection = () => (
  <ToolbarActions
    selectedCount={3}
    actions={[
      { label: "Delete Selected", onClick: () => {}, variant: "danger" },
      { label: "Export Selected", onClick: () => {}, variant: "ghost" },
    ]}
  />
);
