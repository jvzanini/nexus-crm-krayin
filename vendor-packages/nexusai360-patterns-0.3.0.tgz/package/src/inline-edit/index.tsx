import * as React from "react";
import { Input } from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface InlineEditProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, "onSubmit"> {
  /** Current display value */
  value: string;
  /** Save callback — receives the new value */
  onSave: (value: string) => void | Promise<void>;
  /** Input type */
  type?: "text" | "number";
  /** Validation function — return error string or undefined */
  validation?: (value: string) => string | undefined;
  /** Placeholder when editing */
  placeholder?: string;
  /** Whether the component is disabled */
  disabled?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Icons                                                              */
/* ------------------------------------------------------------------ */
const CheckIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M3 8l4 4 6-7"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const CloseIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-4" aria-hidden="true">
    <path
      d="M4 4l8 8M12 4l-8 8"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
  </svg>
);

const PencilIcon: React.FC = () => (
  <svg viewBox="0 0 16 16" fill="none" className="size-3.5" aria-hidden="true">
    <path
      d="M11.5 2.5l2 2-8 8H3.5v-2l8-8z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const InlineEdit = React.forwardRef<HTMLDivElement, InlineEditProps>(
  (
    {
      className,
      value,
      onSave,
      type = "text",
      validation,
      placeholder,
      disabled = false,
      ...props
    },
    ref
  ) => {
    const [editing, setEditing] = React.useState(false);
    const [draft, setDraft] = React.useState(value);
    const [saving, setSaving] = React.useState(false);
    const [error, setError] = React.useState<string | undefined>();
    const inputRef = React.useRef<HTMLInputElement>(null);

    // Sync draft when value changes externally
    React.useEffect(() => {
      if (!editing) setDraft(value);
    }, [value, editing]);

    // Focus input when entering edit mode
    React.useEffect(() => {
      if (editing) inputRef.current?.focus();
    }, [editing]);

    const startEditing = React.useCallback(() => {
      if (disabled) return;
      setDraft(value);
      setError(undefined);
      setEditing(true);
    }, [disabled, value]);

    const cancel = React.useCallback(() => {
      setEditing(false);
      setDraft(value);
      setError(undefined);
    }, [value]);

    const save = React.useCallback(async () => {
      if (validation) {
        const err = validation(draft);
        if (err) {
          setError(err);
          return;
        }
      }

      if (draft === value) {
        setEditing(false);
        return;
      }

      setSaving(true);
      try {
        await onSave(draft);
        setEditing(false);
      } finally {
        setSaving(false);
      }
    }, [draft, value, validation, onSave]);

    const handleKeyDown = React.useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter") {
          e.preventDefault();
          save();
        } else if (e.key === "Escape") {
          cancel();
        }
      },
      [save, cancel]
    );

    /* Display mode */
    if (!editing) {
      return (
        <div
          ref={ref}
          className={[
            "group inline-flex items-center gap-1.5 cursor-pointer rounded-md px-1 py-0.5",
            "hover:bg-zinc-800 transition-colors",
            disabled && "opacity-50 cursor-not-allowed",
            className,
          ]
            .filter(Boolean)
            .join(" ")}
          role="button"
          tabIndex={disabled ? -1 : 0}
          onClick={startEditing}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") startEditing();
          }}
          aria-label={`Edit: ${value}`}
          {...props}
        >
          <span className="text-sm text-zinc-100">{value || placeholder}</span>
          <span className="text-zinc-500 opacity-0 group-hover:opacity-100 transition-opacity">
            <PencilIcon />
          </span>
        </div>
      );
    }

    /* Editing mode */
    return (
      <div
        ref={ref}
        className={[
          "inline-flex items-center gap-1.5",
          className,
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        <div className="flex flex-col">
          <Input
            ref={inputRef}
            size="sm"
            type={type}
            value={draft}
            onChange={(e) => {
              setDraft(e.target.value);
              if (error) setError(undefined);
            }}
            onKeyDown={handleKeyDown}
            placeholder={placeholder}
            error={!!error}
            errorMessage={error}
            disabled={saving}
            aria-label="Edit value"
          />
        </div>
        <button
          type="button"
          className="inline-flex size-7 items-center justify-center rounded-md text-green-500 hover:bg-zinc-800 transition-colors disabled:opacity-50"
          onClick={save}
          disabled={saving}
          aria-label="Save"
        >
          <CheckIcon />
        </button>
        <button
          type="button"
          className="inline-flex size-7 items-center justify-center rounded-md text-zinc-400 hover:bg-zinc-800 transition-colors"
          onClick={cancel}
          disabled={saving}
          aria-label="Cancel"
        >
          <CloseIcon />
        </button>
      </div>
    );
  }
);

InlineEdit.displayName = "InlineEdit";

export { InlineEdit };
