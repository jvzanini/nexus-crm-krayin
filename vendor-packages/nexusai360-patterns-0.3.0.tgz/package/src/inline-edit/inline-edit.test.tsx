import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { InlineEdit } from "./index";

describe("InlineEdit", () => {
  it("renders display value", () => {
    render(<InlineEdit value="Hello" onSave={vi.fn()} />);
    expect(screen.getByText("Hello")).toBeInTheDocument();
  });

  it("enters edit mode on click", () => {
    render(<InlineEdit value="Hello" onSave={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    expect(screen.getByLabelText("Edit value")).toBeInTheDocument();
  });

  it("enters edit mode on Enter key", () => {
    render(<InlineEdit value="Hello" onSave={vi.fn()} />);
    fireEvent.keyDown(screen.getByRole("button", { name: /edit/i }), {
      key: "Enter",
    });
    expect(screen.getByLabelText("Edit value")).toBeInTheDocument();
  });

  it("populates input with current value", () => {
    render(<InlineEdit value="World" onSave={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    expect(screen.getByLabelText("Edit value")).toHaveValue("World");
  });

  it("cancels on Escape", () => {
    render(<InlineEdit value="Test" onSave={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    fireEvent.keyDown(screen.getByLabelText("Edit value"), {
      key: "Escape",
    });
    expect(screen.queryByLabelText("Edit value")).toBeNull();
    expect(screen.getByText("Test")).toBeInTheDocument();
  });

  it("cancels on Cancel button click", () => {
    render(<InlineEdit value="Test" onSave={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    fireEvent.click(screen.getByLabelText("Cancel"));
    expect(screen.queryByLabelText("Edit value")).toBeNull();
  });

  it("saves on Enter key", async () => {
    const onSave = vi.fn();
    render(<InlineEdit value="Old" onSave={onSave} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    fireEvent.change(screen.getByLabelText("Edit value"), {
      target: { value: "New" },
    });
    fireEvent.keyDown(screen.getByLabelText("Edit value"), { key: "Enter" });
    await waitFor(() => {
      expect(onSave).toHaveBeenCalledWith("New");
    });
  });

  it("saves on Save button click", async () => {
    const onSave = vi.fn();
    render(<InlineEdit value="Old" onSave={onSave} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    fireEvent.change(screen.getByLabelText("Edit value"), {
      target: { value: "New" },
    });
    fireEvent.click(screen.getByLabelText("Save"));
    await waitFor(() => {
      expect(onSave).toHaveBeenCalledWith("New");
    });
  });

  it("does not save when value unchanged", async () => {
    const onSave = vi.fn();
    render(<InlineEdit value="Same" onSave={onSave} />);
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    fireEvent.keyDown(screen.getByLabelText("Edit value"), { key: "Enter" });
    await waitFor(() => {
      expect(onSave).not.toHaveBeenCalled();
    });
  });

  it("shows validation error", () => {
    const validation = (v: string) =>
      v.length < 3 ? "Min 3 chars" : undefined;
    render(
      <InlineEdit value="Hi" onSave={vi.fn()} validation={validation} />
    );
    fireEvent.click(screen.getByRole("button", { name: /edit/i }));
    fireEvent.keyDown(screen.getByLabelText("Edit value"), { key: "Enter" });
    expect(screen.getByText("Min 3 chars")).toBeInTheDocument();
  });

  it("is disabled when disabled=true", () => {
    render(<InlineEdit value="Test" onSave={vi.fn()} disabled />);
    const btn = screen.getByRole("button", { name: /edit/i });
    expect(btn).toHaveAttribute("tabindex", "-1");
  });

  it("renders placeholder when value is empty", () => {
    render(
      <InlineEdit value="" onSave={vi.fn()} placeholder="Enter value" />
    );
    expect(screen.getByText("Enter value")).toBeInTheDocument();
  });
});
