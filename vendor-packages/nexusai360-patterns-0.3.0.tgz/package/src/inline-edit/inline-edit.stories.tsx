import { InlineEdit } from "./index";

export default { title: "Patterns/InlineEdit" };

export const Default = () => (
  <InlineEdit value="Click to edit" onSave={(v) => console.log("Saved:", v)} />
);

export const WithValidation = () => (
  <InlineEdit
    value="Required field"
    onSave={(v) => console.log("Saved:", v)}
    validation={(v) => (v.trim() === "" ? "Cannot be empty" : undefined)}
  />
);

export const NumberType = () => (
  <InlineEdit value="42" type="number" onSave={(v) => console.log("Saved:", v)} />
);

export const Disabled = () => (
  <InlineEdit value="Cannot edit" onSave={() => {}} disabled />
);
