import { useState } from "react";
import { SearchPalette } from "./index";

export default { title: "Patterns/SearchPalette" };

const mockResults = [
  { id: "1", label: "Alice Johnson", description: "Contact", category: "Contacts" },
  { id: "2", label: "Bob Smith", description: "Contact", category: "Contacts" },
  { id: "3", label: "Acme Corp", description: "Company", category: "Companies" },
  { id: "4", label: "Settings", description: "General settings", category: "Pages" },
];

export const Default = () => {
  const [open, setOpen] = useState(true);
  return (
    <>
      <button
        className="px-3 py-2 rounded-lg bg-zinc-800 text-zinc-100 text-sm"
        onClick={() => setOpen(true)}
      >
        Open Search
      </button>
      <SearchPalette
        results={mockResults}
        onSearch={(q) => console.log("Search:", q)}
        onSelect={(id) => console.log("Selected:", id)}
        open={open}
        onOpenChange={setOpen}
      />
    </>
  );
};
