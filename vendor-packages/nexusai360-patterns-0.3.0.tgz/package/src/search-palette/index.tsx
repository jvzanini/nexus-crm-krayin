import * as React from "react";
import {
  Dialog,
  DialogContent,
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from "@nexusai360/ui";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
export interface SearchResult {
  /** Unique id */
  id: string;
  /** Display label */
  label: string;
  /** Subtitle/description */
  description?: string;
  /** Icon */
  icon?: React.ReactNode;
  /** Category for grouping */
  category?: string;
}

export interface SearchPaletteProps {
  /** Callback when user types a query */
  onSearch: (query: string) => void;
  /** Search results */
  results: SearchResult[];
  /** Recent search entries */
  recentSearches?: SearchResult[];
  /** Placeholder for search input */
  placeholder?: string;
  /** Callback when a result is selected */
  onSelect: (id: string) => void;
  /** Controlled open state */
  open?: boolean;
  /** Open change callback */
  onOpenChange?: (open: boolean) => void;
  /** Empty message */
  emptyMessage?: string;
  /** Loading state */
  loading?: boolean;
}

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */
const SearchPalette: React.FC<SearchPaletteProps> = ({
  onSearch,
  results,
  recentSearches = [],
  placeholder = "Search...",
  onSelect,
  open: controlledOpen,
  onOpenChange,
  emptyMessage = "No results found.",
  loading = false,
}) => {
  const [internalOpen, setInternalOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const open = controlledOpen ?? internalOpen;

  const setOpen = React.useCallback(
    (v: boolean) => {
      setInternalOpen(v);
      onOpenChange?.(v);
      if (!v) setQuery("");
    },
    [onOpenChange]
  );

  const handleSearchChange = React.useCallback(
    (value: string) => {
      setQuery(value);
      onSearch(value);
    },
    [onSearch]
  );

  const handleSelect = React.useCallback(
    (id: string) => {
      onSelect(id);
      setOpen(false);
    },
    [onSelect, setOpen]
  );

  // Group results by category
  const groupedResults = React.useMemo(() => {
    const groups = new Map<string, SearchResult[]>();
    for (const result of results) {
      const category = result.category ?? "Results";
      const existing = groups.get(category) ?? [];
      existing.push(result);
      groups.set(category, existing);
    }
    return groups;
  }, [results]);

  const showRecent = query.length === 0 && recentSearches.length > 0;
  const showResults = query.length > 0;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden p-0 shadow-lg">
        <Command
          label="Search"
          search={query}
          onSearchChange={handleSearchChange}
        >
          <CommandInput placeholder={placeholder} />
          <CommandList>
            {loading ? (
              <div className="py-6 text-center text-sm text-zinc-500">
                Searching...
              </div>
            ) : (
              <>
                {showRecent && (
                  <CommandGroup heading="Recent">
                    {recentSearches.map((item) => (
                      <CommandItem
                        key={item.id}
                        value={item.id}
                        onSelect={handleSelect}
                      >
                        {item.icon && (
                          <span className="mr-2 text-zinc-400">
                            {item.icon}
                          </span>
                        )}
                        <div className="flex flex-col">
                          <span>{item.label}</span>
                          {item.description && (
                            <span className="text-xs text-zinc-500">
                              {item.description}
                            </span>
                          )}
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                )}

                {showResults && (
                  <>
                    {Array.from(groupedResults.entries()).map(
                      ([category, items]) => (
                        <CommandGroup key={category} heading={category}>
                          {items.map((item) => (
                            <CommandItem
                              key={item.id}
                              value={item.id}
                              onSelect={handleSelect}
                              keywords={[
                                item.label,
                                item.description ?? "",
                              ].filter(Boolean)}
                            >
                              {item.icon && (
                                <span className="mr-2 text-zinc-400">
                                  {item.icon}
                                </span>
                              )}
                              <div className="flex flex-col">
                                <span>{item.label}</span>
                                {item.description && (
                                  <span className="text-xs text-zinc-500">
                                    {item.description}
                                  </span>
                                )}
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      )
                    )}
                    {results.length === 0 && (
                      <CommandEmpty>{emptyMessage}</CommandEmpty>
                    )}
                  </>
                )}

                {!showRecent && !showResults && (
                  <div className="py-6 text-center text-sm text-zinc-500">
                    Start typing to search...
                  </div>
                )}
              </>
            )}
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
};

SearchPalette.displayName = "SearchPalette";

export { SearchPalette };
