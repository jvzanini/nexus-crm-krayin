import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { SearchPalette, type SearchResult } from "./index";

const results: SearchResult[] = [
  { id: "1", label: "Alice", description: "Admin", category: "Users" },
  { id: "2", label: "Bob", description: "Editor", category: "Users" },
  { id: "3", label: "Dashboard", category: "Pages" },
];

describe("SearchPalette", () => {
  const defaultProps = {
    onSearch: vi.fn(),
    results: [] as SearchResult[],
    onSelect: vi.fn(),
  };

  it("renders when open", () => {
    render(<SearchPalette {...defaultProps} open />);
    expect(screen.getByPlaceholderText("Search...")).toBeInTheDocument();
  });

  it("renders custom placeholder", () => {
    render(
      <SearchPalette {...defaultProps} open placeholder="Find anything..." />
    );
    expect(
      screen.getByPlaceholderText("Find anything...")
    ).toBeInTheDocument();
  });

  it("renders initial state message", () => {
    render(<SearchPalette {...defaultProps} open />);
    expect(screen.getByText("Start typing to search...")).toBeInTheDocument();
  });

  it("renders recent searches when query is empty", () => {
    const recent: SearchResult[] = [
      { id: "r1", label: "Recent search 1" },
    ];
    render(
      <SearchPalette {...defaultProps} open recentSearches={recent} />
    );
    expect(screen.getByText("Recent")).toBeInTheDocument();
    expect(screen.getByText("Recent search 1")).toBeInTheDocument();
  });

  it("calls onSearch when typing", () => {
    const onSearch = vi.fn();
    render(<SearchPalette {...defaultProps} onSearch={onSearch} open />);
    fireEvent.change(screen.getByPlaceholderText("Search..."), {
      target: { value: "hello" },
    });
    expect(onSearch).toHaveBeenCalledWith("hello");
  });

  it("renders loading state", () => {
    render(<SearchPalette {...defaultProps} open loading />);
    expect(screen.getByText("Searching...")).toBeInTheDocument();
  });

  it("renders results grouped by category", () => {
    // Use a broad search that CommandItem will match
    render(<SearchPalette {...defaultProps} results={results} open />);
    fireEvent.change(screen.getByPlaceholderText("Search..."), {
      target: { value: "a" },
    });
    expect(screen.getByText("Users")).toBeInTheDocument();
    expect(screen.getByText("Pages")).toBeInTheDocument();
  });

  it("renders result descriptions", () => {
    render(<SearchPalette {...defaultProps} results={results} open />);
    fireEvent.change(screen.getByPlaceholderText("Search..."), {
      target: { value: "Alice" },
    });
    expect(screen.getByText("Admin")).toBeInTheDocument();
  });
});
