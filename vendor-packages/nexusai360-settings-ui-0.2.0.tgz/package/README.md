# @nexusai360/settings-ui

Páginas de Settings + Feature Flags (admin platform). Client components que recebem server actions via props.

## Install

```bash
pnpm add @nexusai360/settings-ui
```

Peers: `@nexusai360/design-system ^0.3`, `@nexusai360/types ^0.2`, React 19, Next 16 (opcional), framer-motion, lucide-react, sonner, date-fns.

## Uso

```tsx
import { SettingsContent } from "@nexusai360/settings-ui";
import { toSettingsDTO } from "@nexusai360/settings-ui/server-helpers";

const raw = await settingsAdapter.getAllSettings();
return <SettingsContent initialSettings={toSettingsDTO(raw)} onSave={saveAction} canEdit={canEditSettings(user.role)} />;
```

## Adapters

Implemente `SettingsAdapter` e `FlagsAdapter` (ex.: com Prisma) e use em suas server actions.

## Permissions

`setPermissionResolver(fn)` — **chame UMA ÚNICA VEZ no boot** (e.g., Next `instrumentation.ts`). NÃO chame por request.
