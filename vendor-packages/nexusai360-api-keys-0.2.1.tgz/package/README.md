# @nexusai360/api-keys

API keys com hash SHA256, scopes, IP allowlist (CIDR) e expiracao. Sem Prisma — voce injeta o adapter.

## Instalacao

```bash
pnpm add @nexusai360/api-keys @nexusai360/multi-tenant nanoid
```

## Uso

```ts
import {
  configureApiKeys,
  createApiKey,
  validateApiKey,
  revokeApiKey,
  listApiKeys,
} from "@nexusai360/api-keys";
import { createPrismaApiKeyAdapter } from "@/lib/api-keys/adapter";

configureApiKeys(createPrismaApiKeyAdapter());

// 1) Criar — rawKey so aparece aqui
const { record, rawKey } = await createApiKey({
  companyId,
  createdBy: userId,
  name: "Integration A",
  scopes: ["webhooks:read"],
  allowedIps: ["10.0.0.0/8", "2001:db8::/32"],
});

// 2) Validar (middleware)
const r = await validateApiKey({ rawKey, ip: "10.0.0.5", requiredScopes: ["webhooks:read"] });
if (!r.valid) return 401;
```

## Erros

`validateApiKey` sempre retorna `invalid_api_key` em falha (evita oracle).
Outros builders lancam:

- `api_keys_not_configured`
- `invalid_api_key_name` / `invalid_scopes` / `invalid_api_key_prefix`
