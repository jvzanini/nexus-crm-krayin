import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { CrmListShell } from "./crm-list-shell";

describe("CrmListShell", () => {
  it("renderiza título e children", () => {
    render(
      <CrmListShell title="Leads">
        <div data-testid="content">rows</div>
      </CrmListShell>
    );
    expect(screen.getByRole("heading", { name: "Leads" })).toBeInTheDocument();
    expect(screen.getByTestId("content")).toBeInTheDocument();
  });

  it("renderiza breadcrumbs opcional", () => {
    render(
      <CrmListShell
        title="Leads"
        breadcrumbs={[
          { label: "Home", href: "/" },
          { label: "Leads" },
        ]}
      >
        x
      </CrmListShell>
    );
    expect(screen.getByText("Home")).toBeInTheDocument();
  });

  it("breadcrumbs undefined não crasha", () => {
    render(<CrmListShell title="Leads">x</CrmListShell>);
    expect(screen.getByRole("heading", { name: "Leads" })).toBeInTheDocument();
  });

  it("actions à direita do header", () => {
    render(
      <CrmListShell title="Leads" actions={<button>Novo</button>}>
        x
      </CrmListShell>
    );
    expect(screen.getByRole("button", { name: "Novo" })).toBeInTheDocument();
  });

  it("toolbar slot renderiza", () => {
    render(
      <CrmListShell title="Leads" toolbar={<div data-testid="bar">bar</div>}>
        x
      </CrmListShell>
    );
    expect(screen.getByTestId("bar")).toBeInTheDocument();
  });

  it("header tem classes rounded-lg border bg-card", () => {
    const { container } = render(<CrmListShell title="Leads">x</CrmListShell>);
    const card = container.querySelector('[data-slot="crm-list-header"]');
    expect(card?.className).toContain("rounded-lg");
    expect(card?.className).toContain("border");
    expect(card?.className).toContain("bg-card");
  });

  it("header card não hardcoda bg-white", () => {
    const { container } = render(<CrmListShell title="Leads">x</CrmListShell>);
    const card = container.querySelector('[data-slot="crm-list-header"]');
    expect(card?.className).toMatch(/bg-card|bg-background/);
    expect(card?.className).not.toMatch(/\bbg-white\b/);
  });

  it("zero gray-XXX hardcoded", () => {
    const { container } = render(
      <CrmListShell title="Leads" description="d">
        x
      </CrmListShell>
    );
    expect(container.innerHTML).not.toMatch(/gray-\d{2,3}/);
  });
});
