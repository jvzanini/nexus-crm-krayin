import * as React from "react";
import { PageHeader, type BreadcrumbEntry } from "../page-header";

export interface CrmListShellProps {
  title: string;
  description?: string;
  breadcrumbs?: BreadcrumbEntry[];
  actions?: React.ReactNode;
  toolbar?: React.ReactNode;
  children: React.ReactNode;
}

export function CrmListShell({
  title,
  description,
  breadcrumbs,
  actions,
  toolbar,
  children,
}: CrmListShellProps) {
  return (
    <div className="flex flex-col gap-4" data-slot="crm-list-shell">
      <div
        data-slot="crm-list-header"
        className="rounded-lg border border-border bg-card px-4 py-3"
      >
        <PageHeader
          title={title}
          description={description}
          breadcrumbs={breadcrumbs}
          actions={actions}
        />
      </div>
      {toolbar && <div data-slot="crm-list-toolbar">{toolbar}</div>}
      <div data-slot="crm-list-content">{children}</div>
    </div>
  );
}
